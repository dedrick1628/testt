import React, {useState} from "react";
import "./ChannelLayout.css"

const ChannelLayoutTemp1 = (props) => {
    console.log("DBBBBB ==>", props?.entityChannel)
    return(
        <div className="grid-container">
            {props?.entityChannel?.map((item, index) => (
                <div key={item.ENTITY_ID}>
                    {
                        Object.entries(item).map(([key,value]) =>(
                            <div key={key} onClick={()=>{props.getChannel(key)}} style={{"cursor": value != 'grey'?'pointer':''}}>
                            <div className="circle" style={{backgroundColor: value}}></div><div className="circleTxt">{key}</div>
                            </div>
                        ))
                        
                    }
                    {/* <div className='grid-item'>
                        <div className="text-wrapper">
                            {item.ENTITY_NAME}
                        </div>
                    </div> */}
                    
                            
                </div>
            ))}
        </div>
    )
}
export default ChannelLayoutTemp1;