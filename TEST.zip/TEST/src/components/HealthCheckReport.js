import React, { useEffect, useState} from 'react';

import axios from 'axios';
import { DatePicker } from '@vds/date-pickers';
import moment from 'moment';
const HealthCheckReport = () => {
  const [htmlContent, setHtmlContent] = useState()
  useEffect(() => {
           
           const currentDate = new Date(); // Creates a new Date object representing the current date and time

           const year = currentDate.getFullYear();
           const month = String(currentDate.getMonth() + 1).padStart(2, '0');
           const day = String(currentDate.getDate()).padStart(2, '0');
           let finalDate = year+"-"+month+"-"+day
           axios.get(`http://localhost:8000/getHealthCheckReport1/`+finalDate)
            .then(res => {
                setHtmlContent(res.data)
            })   
    },[]);
  const handleDateChange = val => {
    let splitDate = val.split("/")
    let finalDate = splitDate[2]+"-"+splitDate[0]+"-"+splitDate[1]
    axios.get(`http://localhost:8000/getHealthCheckReport1/`+finalDate)
            .then(res => {
                if (res.data == false) {
                  alert("No Report Found")
                } else {
                  setHtmlContent(res.data)
                }
                
            })  
    console.log("Values ===>", finalDate)
  };
  return(
    <div>
      <DatePicker
          name='fromDate'
          dateFormat='MM/DD/YYYY'
          alwaysOpen={false}
          readOnly={false}
          disabled={false}
          surface='light'
          minDate={new Date('2025-08-07')}
          maxDate={new Date()}
          helperText=''
          helperTextPlacement='bottom'
          onChange={handleDateChange}
                />
    <div dangerouslySetInnerHTML={{ __html: htmlContent }} /> 
    </div>
  );
}

export default HealthCheckReport;
