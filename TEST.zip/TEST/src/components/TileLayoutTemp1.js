import React, {useState} from "react";
import "./TileLayout.css"

const TileLayoutTemp1 = (props) => {
    const [selectedTile, setSelectedTile] = useState(0)
    const [isModalOpen, setIsModalOpen] = useState(false)
    const [modalContent, setModalContent] = useState("")
    console.log("props?.transactionData DB ==>", props?.transactionData)
    const openModal =(transaction_id) => {
        
        localStorage.setItem('transactionId',transaction_id)
        props.callAPIAfterTransaction()
    }
    const closeModal = () => {
       
    }
    
    return(
        <div className="tile-container-wrapper">
        <div className="tile-container" >
            {(props?.transactionData?.map((tile, index) => (
                tile['BG_COLOR'] != 'grey' ? <div className={`tile ${selectedTile === index ? "selected": ""}`} key={tile.TRANSACTION_ID}
                style={{"backgroundColor" : tile['BG_COLOR'], "color": tile['TEXT_COLOR']}} onClick={() => openModal(tile.TRANSACTION_ID)}>
                    <div className="tile-content">
                        {tile.TRANSACTION_NAME}
                    </div>

                </div>: ''
            )))}
        </div>
        
        </div>
        
    )
}
export default TileLayoutTemp1;