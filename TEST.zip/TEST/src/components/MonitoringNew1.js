import React, { useState, useEffect, useMemo, Suspense } from 'react';


import '../App.css';
import Box from '@mui/material/Box';
import Paper from '@mui/material/Paper';
import { experimentalStyled as styled } from '@mui/material/styles';
import Grid from '@mui/material/Grid';
import Table from '@mui/material/Table';
import { TableCell, TableHead, TableRow } from '@mui/material';
import { makeStyles } from '@mui/styles';
import axios from 'axios';

const userStyles = makeStyles({
  table: {
    backgroundColor: 'rgb(246, 246, 246) !important',
    borderCollapse: 'separate !important'
  },
  thead: {
    backgroundColor: 'rgb(246, 246, 246)',
  },
  category: {
    color: 'black',
    fontSize: '1.1rem !important',
    fontWeight: 'bold !important'
  },
  categoryTD: {
   borderRadius: '6px',
   padding: '20px',
   border: '1px solid #000',
   marginTop: '5px'
  },
  categorythreshold: {
    fontWeight: 'bold',
    fontSize: '1.1rem',
    
  }
});

const MonitoringNew1 = () => {
  const classes = userStyles();

  const [confData, setconfData] = useState({})
  const [textColor, setTextcolor] = useState('red')
  const [isLoading, setisLoading] = useState(false)
  
  useEffect(() => {
    axios
      .get("http://localhost:8000/getConfDetails")
      .then((res) => {
        setconfData(res.data);
        setisLoading(true);
       console.log("resresresresres ===>", res)
      })
  },[])

  const displayReport = () => {
    
    return (
      <Box sx={{ flexGrow: 1 }} style={{"width": '100%'}}>
        <Table aria-label="sticky table" className={classes.table}>
        <TableHead className={classes.thead}>
          <TableRow>
            {
              Object.keys(confData?.category).map((cat,i) => {
                return (
                    <>
                    <TableCell align='left' className={classes.category}>{cat.toUpperCase()}</TableCell>
                    </>
                )
              })
            }
          </TableRow>
          </TableHead>
          <TableRow>
            {
              Object.keys(confData?.category)?.map((cat,i) => {
                return (
                    <>
                    <TableCell style={{ verticalAlign: "top"}}>
                      {
                        confData?.category[cat]?.map((subCat,i) => {
                          if (Number(subCat['measured-value']) != 0) {
                            return (
                              <div className={classes.categoryTD} style={{"backgroundColor": subCat['bg-color'], "color": subCat['txt-color']}}>
                                <bold>{subCat.text.toUpperCase()}</bold> : <bold className={classes.categorythreshold} >{subCat['measured-value']}</bold><div style={{'backgroundColor': subCat['bg-color'],'height': '25px', 'width': '25px','borderRadius': '50%'}}></div>
                              </div>
                            )
                          }
                        })
                      }
                    </TableCell>
                    
                    </>
                )
              })
            }
          </TableRow>
        
        </Table>
      </Box>
    )
  }
  const Item = styled(Paper)(({ theme }) => ({
    backgroundColor: '#fff',
    ...theme.typography.body2,
    padding: theme.spacing(2),
    textAlign: 'center',
    color: theme.palette.text.secondary,
    ...theme.applyStyles('dark', {
      backgroundColor: '#FFF',
    }),
  }));
  return(
    <div className="app">
      <header className="header">

      </header>
      <main className="main">
     
      {(isLoading == true) ?
       displayReport() : ''
      }
      </main>
    </div>
  );
}

export default MonitoringNew1;
