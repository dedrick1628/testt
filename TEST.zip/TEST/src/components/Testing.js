import * as React from 'react';
import Stack from '@mui/material/Stack';
import FormControl from '@mui/material/FormControl';
import FormLabel from '@mui/material/FormLabel';
import RadioGroup from '@mui/material/RadioGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import Radio from '@mui/material/Radio';
import { BarChart } from '@mui/x-charts/BarChart';
import { axisClasses } from '@mui/x-charts/ChartsAxis';
import Table from '@mui/material/Table';
import { TableCell, TableHead, TableRow,TableContainer } from '@mui/material';
import TableBody from '@mui/material/TableBody';
import Paper from '@mui/material/Paper';
function TickParamsSelector({
  tickPlacement,
  tickLabelPlacement,
  setTickPlacement,
  setTickLabelPlacement,
}) {
  return (
    <Stack direction="column" justifyContent="space-between" sx={{ width: '100%' }}>
      
    </Stack>
  );
}

const chartSetting = {
  yAxis: [
    {
      label: 'Counts',
    },
  ],
  series: [{ dataKey: 'counts'}],
  height: 600,
  
};

export default function Testing() {
  const [tickPlacement, setTickPlacement] = React.useState('middle');
  const [tickLabelPlacement, setTickLabelPlacement] = React.useState('middle');
  const dataset = [
    {
        "call_reason": "Disconnect",
        "counts": 960
    },
    {
        "call_reason": "PortCenter",
        "counts": 240
    },
    {
        "call_reason": "CreditApp Business",
        "counts": 3
    },
    {
        "call_reason": "Disconnect within WFG",
        "counts": 3
    },
    {
        "call_reason": "TechSup Connected Device",
        "counts": 27
    },
    {
        "call_reason": "OverrideRequests",
        "counts": 20
    },
    {
        "call_reason": "CARE",
        "counts": 1844
    },
    {
        "call_reason": "Contract date Changes",
        "counts": 4
    },
    {
        "call_reason": "Fraud",
        "counts": 41
    },
    {
        "call_reason": "TechSup LTE Internet",
        "counts": 2
    },
    {
        "call_reason": "CreditApp Fraud",
        "counts": 103
    },
    {
        "call_reason": "Other",
        "counts": 5
    },
    {
        "call_reason": "TechSup NwkExtender",
        "counts": 10
    },
    {
        "call_reason": "Upgrade eligibility Correction",
        "counts": 4
    },
    {
        "call_reason": "Activation Failure",
        "counts": 404
    },
    {
        "call_reason": "CreditApp Consumer",
        "counts": 138
    },
    {
        "call_reason": "TechSup SmartPhone 4G",
        "counts": 188
    },
    {
        "call_reason": "TechSup TechGuru",
        "counts": 4
    }
];
  return (
    <div >
      <div style={{float: 'left'}}>
      <TableContainer component={Paper}>
      <Table sx={{ width: 500, height: 500 }} aria-label="simple table">
        <TableHead>
          <TableRow>
            <TableCell>CALL_REASON</TableCell>
            <TableCell align="center">COUNTS</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {dataset?.map((row,index) => (
            <TableRow
              key={index}
              sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
            >
              
              <TableCell align="center">{row.call_reason}</TableCell>
              <TableCell align="center">{row.counts}</TableCell>
            </TableRow>
          ))}
        </TableBody>
        </Table>
        </TableContainer>
        </div>
      <div style={{float: 'left'}}>
      <BarChart
      margin={{ top: 5, right: 100, bottom: 100 , left: 100 }}
        dataset={dataset}
        width={800}
        barLabel={(v) => `${v.value}`}
        xAxis={[
          { scaleType: 'band', dataKey: 'call_reason', tickLabelStyle: {
            angle: -75,
            fontSize: 15,
            textAnchor: 'end',
        }},
        ]}
        {...chartSetting}
      /></div>
    </div>
  );
}