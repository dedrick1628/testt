import React, { useState} from 'react';
import '../App.css';
import Paper from '@mui/material/Paper';
import Table from '@mui/material/Table';
import { TableCell, TableHead, TableRow,TableContainer } from '@mui/material';
import axios from 'axios';
import { Loader } from '@vds/loaders';
import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import Box from '@mui/material/Box';

const ESimAnalyser = () => {
 const [simData, setsimData] = useState()
 const [smdp_data, setSmdpData]=useState([])
 const [smdpKeys, setsmdpKeys] = useState([])
 const [loader, setLoader] = useState(false)
 const [remarks, setRemarks] = useState([])
 const [value, setValue] = React.useState(0);

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };
  const a11yProps = (index) =>{
    return {
      id: `simple-tab-${index}`,
      'aria-controls': `simple-tabpanel-${index}`,
    }
  }
  const CustomTabPanel = (props) => {
    const { children, value, index, ...other } = props;
  
    return (
      <div
        role="tabpanel"
        hidden={value !== index}
        id={`simple-tabpanel-${index}`}
        aria-labelledby={`simple-tab-${index}`}
        {...other}
      >
        {value === index && <Box sx={{ p: 3 }}>{children}</Box>}
      </div>
    );
  }
  const getESimData =(e) => {
    setLoader(true)
    const payload={}
    payload["mtn"] = simData;
    axios.get(`http://localhost:8000/esimAnalyser/`+simData)
    .then(res => {
        if (res.data['SMDP_DETAILS'].length > 0) {
          setSmdpData(res.data['SMDP_DETAILS'])
          setsmdpKeys(Object.keys(res.data['SMDP_DETAILS'][0]))
        }
        if(res.data['REMARKS'].length > 0) {
          setRemarks(res.data['REMARKS'])
        }  
        setLoader(false)
    })
    
  }
  return(
    <div >
       
     <br></br>
      <main >
      <div >
      {loader ? <Loader fullscreen={true} active={true} surface='dark' />: ""}
      <div style={{marginLeft: '500px'}}>MTN : <input type="text" className="form-control" placeholder="MTN..." aria-describedby="project-search-addon" onChange={(e)=>{setsimData(e.target.value)}}/>
      <button onClick={(e)=>getESimData()}>GO</button>
      </div>
       <div>
       <Box sx={{ width: '100%' }}>
          <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
            <Tabs value={value} onChange={handleChange} aria-label="basic tabs example">
              <Tab label="SMDP" {...a11yProps(0)} />
              <Tab label="REMARKS" {...a11yProps(1)} />
            </Tabs>
          </Box>
        <CustomTabPanel value={value} index={0}>
          <TableContainer component={Paper}>
        {smdp_data.length > 0 ?
        <Table sx={{ minWidth: 650 }} aria-label="simple table">
          <TableHead>
            <TableRow>
            <TableCell align="center">COLUMN NAME</TableCell>
            {smdp_data?.map((row,index) => (
              <TableCell >RECORD - {index+1}</TableCell>))}
            </TableRow>
          </TableHead>
          {
            smdpKeys?.map((key,index) => (
             <TableRow>
              <TableCell align="center">{key}</TableCell>
              {smdp_data?.map((row,index) => (
              <TableCell >{row[key]}</TableCell>))}
              </TableRow>))
          }
        </Table>: <div>No Records</div>}
        </TableContainer>
        </CustomTabPanel>
        <CustomTabPanel value={value} index={1}>
        <TableContainer component={Paper}>
          {remarks.length > 0 ?
          <Table sx={{ minWidth: 650 }} aria-label="simple table">
            <TableHead>
              <TableRow>
              <TableCell align="center">DATE TIME</TableCell>
                <TableCell >REMARKS</TableCell>
              </TableRow>
            </TableHead>
            {
              remarks?.map((row,index) => (
              <TableRow>
                <TableCell align="center">{row['TIME STAMP']}</TableCell>
                <TableCell >
                {row['REMARKS']?.map((row1,index1) => (
                 <div>{row1.toLowerCase().includes('fmi') || row1.toLowerCase().includes('find my iphone')?<span style={{backgroundColor: 'yellow'}}>{row1}</span>:<span>{row1}</span>}</div>
                ))}
                </TableCell>
                </TableRow>))
            }
          </Table>: ''}
        </TableContainer>
        </CustomTabPanel>
       </Box>
     
      
      </div>
    </div>
     
      </main>
    </div>
  );
}

export default ESimAnalyser;
