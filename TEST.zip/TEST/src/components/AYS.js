import React, { useState, useEffect, useMemo, Suspense } from 'react';

import { BrowserRouter as Router, Route, Routes } from 'react-router-dom'
import '../App.css';
import moment from "moment";
import Paper from '@mui/material/Paper';
import { experimentalStyled as styled } from '@mui/material/styles';
import Grid from '@mui/material/Grid';
import Table from '@mui/material/Table';
import { Box, TableCell, TableHead, TableRow } from '@mui/material';
import { makeStyles } from '@mui/styles';
import axios from 'axios';

import { DemoContainer } from '@mui/x-date-pickers/internals/demo';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import dayjs from 'dayjs';

import Input from '@mui/material/Input';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import ListItemText from '@mui/material/ListItemText';
import Select from '@mui/material/Select';
import FormControlLabel from '@mui/material/FormControlLabel';
import Chip from '@mui/material/Chip';
import Checkbox from '@mui/material/Checkbox';
import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';
import { Loader } from '@vds/loaders';
import SimpleDialog from './SimpleDialog';
const userStyles = makeStyles({
  table: {
    backgroundColor: '#81c784',
  },
  thead: {
    backgroundColor: '#4caf50',
  },
  SimpleDialog: {
    width: '500px'
  },
  clear: {
    clear: 'both'
  },
  float: {
    float: 'left'
  },
  leftDiv : {

  },
  rightDiv: {
    paddingLeft: '20px'
  }
});

const AYS = () => {
  const classes = userStyles();
  
  const [state, setState] = useState([]);
  const [loader, setLoader] = useState(false)
  const [createdOn, setCreatedon] = useState()
  const [createdupto, setCreatedupto] = useState()
  const [selectedState, setSelectedState] = useState()
  const [isGovernment, setIsgovernment] = useState(false)
  const [selectedGroups, setSelectedGroups] = useState()
  const [aysDateformate, setAYSDateformat] = useState('YYYY-MM-DD')
  const [pageCount, setPagecount] = useState([]);
  const [confData, setconfData] = useState({});
  const [isLoading, setisLoading] = useState(false);
  const [processData, setProcessData] = useState({});
  const [groups, setGroups] = useState([]);
  const [open, setOpen] = useState(false);
  const emails = ['username@gmail.com', 'user02@gmail.com'];
  const [selectedValue, setSelectedValue] = useState(emails[1]);

  const handleClickOpen = () => {
    setOpen(true);
  };
  const testing = {
    "processData": {
      "hello":"hai"
    }
  }
  const handleClose = (value) => {
    setOpen(false);
    setSelectedValue(value);
  };
  const stateCat = [
    'Active',
    'New',
    'Pending Internal',
    'Closed',
    'Resolved',
    'Pending Customer'
  ];
  const groupCat = [
    'VZW_MCS_SCM:VDSI',
    'VZW_ACSS_SUPPORT','VZW_ACSS_SUPPORT:VDSI','VCM_VISION_CUSTOMER_PRICING_SUPPORT','VZW_MCS_SCM','VZW_POS_SUPPORT','VZW_MCS_DVS_MW','VZW_DVS-PRE_SUPPORT:VDSI','VZW_CXP_VIP_SUPPORT','VZW_POS_SUPPORT:VZI','VZW_DEVICE_MANAGEMENT_DBA_SUPPORT:VDSI','VZW_MCS_DVS_MW:VDSI','VCM_VISION_CUSTOMER_PRICING_SUPPORT:VDSI','VZW_CXP_VIP_SUPPORT:VDSI','VZW_DVS-OR_WRITES_SUPPORT:VDSI','VZW_CXP_AGGREGATE_SERVICES','VZW_MCS_OPS:VDSI','VZW_MTAS_SUPPORT:VDSI','VZW_MTAS_SUPPORT:ONSHORE','VZW_MTAS_SUPPORT','VZW_MCS_OPS','VZW_DVS-OR_WRITES_SUPPORT','VZW_CXP_DOMAIN_SERVICES','VZW_DEVICE_MANAGEMENT_DBA_SUPPORT','VZW_ETNI_SUPPORT','VZW_ETNI_SUPPORT:VDSI','VZW_GN5V_CJCM_SUPPORT','VZW_OMP_SUPPORT','VZW_TIER2_SUPPORT','VZW_CASEMANAGEMENT_SUPPORT'
  ];
  const getEstimatedtime = () => {
    const payload = {};
    let createdon = moment(createdOn['$d']).format(aysDateformate)+" 00:00:00";
    let createdUpto = moment(createdupto['$d']).format(aysDateformate)+" 59:59:00";
    payload["sys_created_on"] = createdon;
    payload["sys_created_upto"] = createdUpto;
    if (isGovernment == true) {
      payload["is_government_account"] = "Yes";
    } else {
      payload["is_government_account"] = "No,Not Sure";
    }
    if (selectedState) {
      let stateVal = "";
      selectedState.map((state) => {
        stateVal += state + ","
      });
      payload["state"] = stateVal.slice(0, -1);
    }
    if (selectedGroups) {
      let groupVal = "";
      selectedGroups.map((state) => {
        groupVal += state + ","
      });
      payload["assignment_group"] = groupVal.slice(0, -1);
    }

    
    
    setLoader(true)
    let axiosConfig = {
      headers: {
          'Content-Type': 'application/json;charset=UTF-8',
          "Access-Control-Allow-Origin": "*",
      }
    };
    
    
    axios.post(`http://localhost:8000/getAYSPagecount`, payload, axiosConfig)
     .then(res => {
      let page_details=[];
      for (const [key, value] of Object.entries(res.data)) {
        page_details.push(value);
       
      }
      setProcessData({"processData":payload});
      setPagecount(page_details);
      setOpen(true);
      console.log('resresres ==>', res)
      setLoader(false)
     })
  }
  
  const govtSelect = (event) => {
    setIsgovernment(event.target.checked);
  };
  const groupChange = (event) => {
    const { options } = event.target;
    const value = [];
    for (let i = 0, l = options.length; i < l; i += 1) {
      if (options[i].selected) {
        value.push(options[i].value);
      }
    }
    setSelectedGroups(value);
  };
  const stateChange = (event) => {
    const { options } = event.target;
    const value = [];
    for (let i = 0, l = options.length; i < l; i += 1) {
      if (options[i].selected) {
        value.push(options[i].value);
      }
    }
    setSelectedState(value);
  };
  const Item = styled(Paper)(({ theme }) => ({
    backgroundColor: '#fff',
    ...theme.typography.body2,
    padding: theme.spacing(2),
    textAlign: 'center',
    color: theme.palette.text.secondary,
    ...theme.applyStyles('dark', {
      backgroundColor: '#FFF',
    }),
  }));
  return(
    <div className="Aysapp">
      {loader ? <Loader fullscreen={true} active={true} surface='dark' />: ""}
      <div className={classes.clear}>
      <LocalizationProvider dateAdapter={AdapterDayjs}>
      <DemoContainer components={['DatePicker', 'DatePicker']}>
        <div className={classes.left}>
        <DatePicker label="Created on" onChange={(newValue) => setCreatedon(newValue)} value={createdOn} 
        renderInput={(params) => <TextField {...params} required />}/></div>
        <div className={classes.rightDiv}><DatePicker
          label="Created upto"
          value={createdupto}
          onChange={(newValue) => setCreatedupto(newValue)}
          renderInput={(params) => <TextField {...params} required />}
        /></div>
      </DemoContainer>
    </LocalizationProvider>
    </div>
      <div className={classes.clear}>
          <div className={classes.float}>
          <InputLabel shrink htmlFor="select-multiple-native">
            State
          </InputLabel>
          <Select
            multiple
            native
            value={selectedState}
            onChange={stateChange}
            inputProps={{
              id: 'select-multiple-state',
            }}
          >
            {stateCat.map((state) => (
              <option key={state} value={state}>
                {state}
              </option>
            ))}
          </Select>
          </div>
          <div className={classes.rightDiv}>
          <InputLabel shrink htmlFor="select-multiple-native">
            Groups
          </InputLabel>
          <Select
            multiple
            native
            value={selectedGroups}
            onChange={groupChange}
            inputProps={{
              id: 'select-multiple-group',
            }}
          >
            {groupCat.map((group) => (
              <option key={group} value={group}>
                {group}
              </option>
            ))}
          </Select>
          </div>
      </div>
        <div className={classes.clear}>
             <div className={classes.float}>
              <FormControlLabel
              control={
                <Checkbox
                  checked={isGovernment}
                  onChange={govtSelect}
                  name="checkedB"
                  color="Government Account ?"
                />
              }
              label="Government Account ?"
            /></div>
            <div className={classes.float}><FormControlLabel
              control={
                <Checkbox
                  checked={isGovernment}
                  onChange={govtSelect}
                  name="checkedB"
                  color="Government Account ?"
                />
              }
              label="Swimlane categorization "
            /></div>
            <div className={classes.float}>
            <FormControlLabel
              control={
                <Checkbox
                  checked={isGovernment}
                  onChange={govtSelect}
                  name="checkedB"
                  color="Government Account ?"
                />
              }
              label="Semantic similarity"
            /></div>
        </div>
        <div className={classes.clear}>
<Button variant="contained" color="primary" onClick={() => getEstimatedtime()}>
        Submit
      </Button>
      </div>
     <SimpleDialog selectedValue={selectedValue} open={open} onClose={handleClose} data={pageCount} className={classes.SimpleDialog} processData={processData}>

     </SimpleDialog>
    </div>
  );
}

export default AYS;
