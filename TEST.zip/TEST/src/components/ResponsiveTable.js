import React, { useState, useEffect, useMemo, Suspense, useRef } from 'react';
import axios from 'axios';
import "../components/ResponsiveTable.css"

const ResponsiveTable = () => {
    const [data, setData] = useState([])
    const [prevData, setPrevData] = useState([])
    const [flip, setFlip] = useState(false)
    const prevDataRef = useRef();
    const fetchData = () => {
        
        axios
          .get("http://localhost:8000/getsogdetails")
          .then((res) => {
            if (res.data.length > 0) {
                setData(res.data);
                if (prevData != res.data) {
                    setFlip(prevFlip => !prevFlip);
                }
                
                
            }
            
          })
      }
    useEffect(() => {
        setPrevData(data)
        fetchData()
        const interval = setInterval(() => {
            fetchData();
        },10000);
        return () => clearInterval(interval)
      },[]);

     
    return (
        // <div className="grid-container">
        //     {data?.map((item, index) => (
        //         <div key={index} className={`grid-item ${flip ? 'flipped': ''}`} style={{"backgroundColor" : item['bg-color'], "color": item['txt-color']}}>
        //             <div className='grid-item'>
        //                 <div className="text-wrapper">
        //                     {item.text} : {item['measured-value']}
        //                 </div>
        //             </div>
                    
                            
        //         </div>
        //     ))}
        // </div>
        <div className="grid-container">
            {data?.map((item, index) => (
                <div key={index} className={`grid-item`} style={{"backgroundColor" : item['bg-color'], "color": item['txt-color']}}>
                    <div className='grid-item'>
                        <div className="text-wrapper">
                            {item['threshold-value']} <br/>
                            {item.text} : {item['measured-value']}
                        </div>
                    </div>
                    
                            
                </div>
            ))}
        </div>
    )
}

export default ResponsiveTable;