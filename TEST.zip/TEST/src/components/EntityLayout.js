import React, {useState} from "react";
import "./EntityLayout.css"

const EntityLayout = (props) => {
    console.log("propsprops11 ==>", props)
    return(
        <div className="grid-container">
            {props?.entityData?.map((item, index) => (
                <div key={item.ENTITY_ID} className={`grid-item`} style={{"backgroundColor" : item['ENTITY_BGCOLOR'], "color": item['ENTITY_TEXTCOLOR']}} onClick={()=>{props.onToggle(item.TRANSACTION_NAME,item.ENTITY_NAME)}}>
                    <div className='grid-item'>
                        <div className="text-wrapper">
                            {item.ENTITY_NAME}
                        </div>
                    </div>
                    
                            
                </div>
            ))}
        </div>
    )
}
export default EntityLayout;