import React, { useState, useEffect, useMemo, Suspense } from 'react';


import '../App.css';
import Box from '@mui/material/Box';
import Paper from '@mui/material/Paper';
import { experimentalStyled as styled } from '@mui/material/styles';
import Grid from '@mui/material/Grid';
import Table from '@mui/material/Table';
import { TableCell, TableHead, TableRow } from '@mui/material';
import { makeStyles } from '@mui/styles';
import axios from 'axios';
import Monitoring from './Monitoring';
import ResponsiveTable from './ResponsiveTable1';
// import ResponsiveTable from './ResponsiveTable';
const Monitoring2 = () => {
  

  const [confData, setconfData] = useState({})
  const [sogList, setsogList] = useState([
  ])
  const [textColor, setTextcolor] = useState('red')
  const [isLoading, setisLoading] = useState(false)
  
  const fetchData = () => {
    axios
      .get("http://localhost:8000/getsogdetails")
      .then((res) => {
        setsogList(res.data);
        setisLoading(true);
       console.log("resresresresres ===>", res)
      })
  }
  
  
  return(
    <div >
      
      {/* <ResponsiveTable /> */}
      <ResponsiveTable />
    </div>
  );
}

export default Monitoring2;
