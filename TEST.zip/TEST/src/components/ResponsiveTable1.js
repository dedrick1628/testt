import React, { useState, useEffect, useMemo, Suspense } from 'react';
import axios from 'axios';
import "../components/ResponsiveTable1.css"
import "../components/Slide.css"
import TileLayout from './TileLayout';
import EntityLayout from './EntityLayout';
import "./EntityStep.css"
const ResponsiveTable1 = () => {
    const [transactionData, setTransactionData] = useState([])
    const [entityStepData, setentityStepData] = useState([])
    const [entityData, setEntityData] = useState([])
    const [transactionId, setTransactionID] = useState(1)
    const [isSlideOpen, setIsSlideOpne] = useState(false)

    const handleToggle = (t_name,e_name) => {
        console.log("Transaction_id ==>", t_name)
        console.log("Entity_id ==>", e_name)
        axios
          .get("http://localhost:8000/getentitysteps/"+t_name+"/"+e_name)
          .then((res) => {
            console.log("DDDDD ==>", res.data)
            setentityStepData(res.data)
          })
        setIsSlideOpne(!isSlideOpen)
    }
    const fetchEntityData = () => {
        axios
          .get("http://localhost:8000/getentities/"+transactionId)
          .then((res) => {
            setEntityData(res.data)
            
          })
      
    }

    const fetchTransactionData = () => {
        axios
          .get("http://localhost:8000/gettransaction")
          .then((res) => {
            setTransactionData(res.data);
            fetchEntityData();
          })
      }
    useEffect(() => {
        fetchTransactionData()
        // const interval = setInterval(() => {
        //     fetchTransactionData();
        // },10000);
        // return () => clearInterval(interval)
      },[]);
    return (
            <div className='App'>
            <TileLayout transactionData={transactionData}></TileLayout>
            
            <EntityLayout entityData={entityData} onToggle={handleToggle}></EntityLayout>
            {isSlideOpen &&(
                <div className={`slide ${isSlideOpen? 'open': ''}`}>
                    <div className='close-button' onClick={handleToggle}>
                        Close11
                    </div><br/><br/><br/><br/>
                    <div className='grid-container'>
                        {entityStepData?.map((item, index) => (
                            <div key={item.ENTITY_STEP_NAME} className={`grid-item`} style={{"backgroundColor" : item['BG_COLOR'], "color": item['TEXT_COLOR']}} >
                                <div className='grid-item'>
                                    <div className="text-wrapper">
                                        API : {item.ENTITY_STEP_NAME}
                                    </div>
                                </div>
                                
                                        
                            </div>
                        ))}
                    </div>
                    {/* <div className="tile-container-wrapper">
                        <div className="tile-container" >
                            {(entityStepData?.map((tile, index) => (
                                <div className={`tile}`} key={tile.ENTITY_STEP_NAME}
                                style={{"backgroundColor" : tile['BG_COLOR'], "color": tile['TEXT_COLOR']}}>
                                    <div className="tile-content">
                                        {tile.ENTITY_STEP_NAME}
                                    </div>

                                </div>
                            )))}
                        </div>
                        </div> */}
                </div>
            )}
            </div>
    )
}

export default ResponsiveTable1;