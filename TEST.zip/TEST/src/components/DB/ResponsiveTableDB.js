import React, { useState, useEffect, useMemo, Suspense } from 'react';
import axios from 'axios';
import "../../components/ResponsiveTable1.css"
import "../../components/Slide.css"
import TileLayoutTemp1 from './../TileLayoutTemp1';
import EntityLayoutTemp1 from './../EntityLayoutTemp1';
import { SimpleTreeView } from '@mui/x-tree-view/SimpleTreeView';
import ChannelLayoutDB from './ChannelLayoutDB';

import { TreeItem } from '@mui/x-tree-view/TreeItem';
import Table from '@mui/material/Table';
import { TableCell, TableHead, TableRow } from '@mui/material';

// import TileLayout from './TileLayout';
// import EntityLayout from './EntityLayout';
import "./../EntityStep.css"
const ResponsiveTableDB = (props) => {
    console.log("Main props ====>", props)
    const [transactionData, setTransactionData] = useState([])
    const [channelData, setChannelData] = useState([])
    // const [entityStepData, setentityStepData] = useState([])
    const [channelDetails, setChannelDetails] = useState({})
    const [treeExpanded, settreeExpanded] = useState([])
    const [entityChannel, setentityChannel] = useState([])
    const [channelAPI, sethcannelAPI] = useState([])
    const [entityData, setEntityData] = useState([])
    const [transactionId, setTransactionID] = useState(1)
    const [isSlideOpen, setIsSlideOpne] = useState(false)
    const [isApiSlide, setisApiSlide] = useState(false)
    const [channelName, setchannelName] = useState('')
    
    const handleExpandedItemsChange = (event, itemIds) => {
      settreeExpanded(itemIds);
    };
  //   const getChannel = (channel_name) => {
  //     setchannelName(channel_name)
  //     axios
  //         .get("http://localhost:8000/getentity_channel1/"+transactionId+"/"+channel_name)
  //         .then((res) => {
  //           sethcannelAPI(res.data)
  //           setisApiSlide(!isApiSlide)
  //           console.log("DDDDD ==>", res.data)
  //           //setentityStepData(res.data)
  //         })
  //   }
  //   const handleToggle1 = (t_id,e_name) => {
  //     console.log("Transaction_id ==>", t_id)
  //     console.log("Entity_id ==>", e_name)
  //     if (setIsSlideOpne) {
  //     axios
  //       .get("http://localhost:8000/getentitysteps1/"+t_id+"/"+e_name)
  //       .then((res) => {
  //         console.log("DDDDD ==>", res.data)
  //         setChannelDetails(res.data)
  //         let data = Object.keys(res.data).map((key, index) => index)
  //         settreeExpanded(data)
          
  //       })
  //     }
  //     setIsSlideOpne(!isSlideOpen)
  // }
  //   const FetchChannelData = (payLoad) => {
  //       axios
  //       .post("http://localhost:8000/getchannel2",payLoad)
  //       .then((res) => {
  //         setentityChannel(res.data)
          
  //       })
  //   }
    const closeTreeSlide = () => {
      setIsSlideOpne(false)
    }
    const closeApiSlide = () => {
      setisApiSlide(false)
    }
    const getChannel = (channel_name) => {
      setchannelName(channel_name)
      axios
          .get("http://localhost:8000/getentity_channel_DB/"+transactionId+"/"+channel_name)
          .then((res) => {
            sethcannelAPI(res.data)
            setisApiSlide(!isApiSlide)
            console.log("DDDDD ==>", res.data)
            //setentityStepData(res.data)
          })
    }
    const handleToggle1 = (t_id,e_name) => {
      console.log("Transaction_id ==>", t_id)
      console.log("Entity_id ==>", e_name)
      if (setIsSlideOpne) {
      axios
        .get("http://localhost:8000/getentitysteps_DB/"+t_id+"/"+e_name)
        .then((res) => {
          console.log("DDDDD ==>", res.data)
          setChannelDetails(res.data)
          let data = Object.keys(res.data).map((key, index) => index)
          settreeExpanded(data)
          
        })
      }
      setIsSlideOpne(!isSlideOpen)
  }
    
    return (
            <div className='App'>
            <ChannelLayoutDB entityChannel={props.entityChannel} getChannel={getChannel}></ChannelLayoutDB>
            <TileLayoutTemp1 transactionData={props.transactionData}></TileLayoutTemp1>
            
            {/* <ChannelTemp1 channelData={channelData} ></ChannelTemp1> */}
            <EntityLayoutTemp1 entityData={props.entityData} handleToggle1={handleToggle1}></EntityLayoutTemp1>
            {isSlideOpen &&(
                <div className={`slide ${isSlideOpen? 'open': ''}`} >
                    <div className='close-button' onClick={closeTreeSlide}>
                        Close
                    </div><br/><br/><br/><br/>
                    <SimpleTreeView  style={{width: '50%'}} expandedItems={treeExpanded} onExpandedItemsChange={handleExpandedItemsChange}>
                     {
                      Object.keys(channelDetails).map((key, index) => (
                        <TreeItem itemId={index} label={key} >
                          {
                            channelDetails[key].map((key1, index1) => (
                              <TreeItem itemId={key+"_"+key1['ENTITY_API_NAME']} label={key1['ENTITY_API_NAME']}></TreeItem>
                            ))
                          }
                        </TreeItem>
                      ))
                     }
                          
                    </SimpleTreeView>
                </div>
            )}
            {
              isApiSlide &&(
                <div className={`slide ${isSlideOpen? 'open': ''}`}>
                    
                    <div className={`slide ${isSlideOpen? 'open': ''}`}>
                    <div className='close-button' onClick={closeApiSlide}>
                        Close
                    </div><br/><br/><br/><br/>
                    <div style={{marginLeft: '50%'}}> Channel Name : {channelName}</div>
                    <Table style={{width: '666px', marginLeft: '317px'}}>
                    <TableHead >
                      <TableRow>
                        <TableCell align='left'>API_NAME</TableCell>
                        <TableCell align='left'>COUNT</TableCell>
                      </TableRow>
                      </TableHead>
                      {
                        channelAPI?.map((key1, index1) => (
                          <TableRow>
                          <TableCell align='left'>{key1['ENTITY_API_NAME']}</TableCell>
                          <TableCell align='left'>{key1['MEASURED_VALUE']}</TableCell>
                          </TableRow>
                        ))
                      }
                    
                    </Table>
                    
                </div>
                </div>
            )
            }


            {/* {isSlideOpen &&(
                <div className={`slide ${isSlideOpen? 'open': ''}`}>
                    <div className='close-button' onClick={handleToggle}>
                        Close
                    </div><br/><br/><br/><br/>
                    <div className='grid-container'>
                        {entityStepData?.map((item, index) => (
                            <div key={item.ENTITY_STEP_NAME} className={`grid-item`} style={{"backgroundColor" : item['BG_COLOR'], "color": item['TEXT_COLOR']}} >
                                <div className='grid-item'>
                                    <div className="text-wrapper">
                                        API : {item.ENTITY_STEP_NAME}
                                    </div>
                                </div>
                                
                                        
                            </div>
                        ))}
                    </div>
                </div>
            )} */}
            </div>
    )
}

export default ResponsiveTableDB;