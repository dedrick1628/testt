import React, {useState} from "react";
import "./TileLayout.css"

const TileLayoutDB = (props) => {
    const [selectedTile, setSelectedTile] = useState(0)
    const [isModalOpen, setIsModalOpen] = useState(false)
    const [modalContent, setModalContent] = useState("")
    
    const openModal =(TRANSACTION_ID) => {
        
    }
    const closeModal = () => {
        setIsModalOpen(false);
        setModalContent("")
    }
    
    return(
        <div className="tile-container-wrapper">
        <div className="tile-container" >
            {(props?.transactionData?.map((tile, index) => (
                <div className={`tile ${selectedTile === index ? "selected": ""}`} key={tile.TRANSACTION_ID}
                style={{"backgroundColor" : tile['BG_COLOR'], "color": tile['TEXT_COLOR']}} onClick={() => openModal(tile.TRANSACTION_ID)}>
                    <div className="tile-content">
                        {tile.TRANSACTION_NAME}
                    </div>

                </div>
            )))}
        </div>
        
        </div>
        
    )
}
export default TileLayoutDB;