import React, {useState} from "react";
import "./EntityLayout.css"

const EntityLayoutTemp1 = (props) => {
    console.log("propsprops22 ==>", props)
    return(
        <div className="grid-container">
            {props?.entityData?.map((item, index) => (
               item['BG_COLOR'] != 'grey' ? <div key={item.ENTITY_ID} className={`grid-item`} style={{"backgroundColor" : item['BG_COLOR'], "color": item['TEXT_COLOR'], "cursor": item['BG_COLOR'] != 'grey'?'pointer':''}} onClick={()=>{props.handleToggle1(item.TRANSACTION_ID,item.ENTITY_NAME)}}>
                    <div className='grid-item'>
                        <div className="text-wrapper">
                            {item.ENTITY_NAME}
                        </div>
                    </div>
                    
                            
                </div>: ''
            ))}
        </div>
    )
}
export default EntityLayoutTemp1;