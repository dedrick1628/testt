import React, { useState, useEffect, useMemo, Suspense } from 'react';
import axios from 'axios';
import "../components/ResponsiveTable1.css"

const ResponsiveTable1 = () => {
    const [data, setData] = useState([])
    const [flip, setFlip] = useState(false)

    const fetchData = () => {
        axios
          .get("http://localhost:8000/getsogdetails")
          .then((res) => {
            
            setFlip(prevFlip => !prevFlip);
            
            //setisLoading(true);
           console.log("resresresresres ===>", res)
          })
      }
    useEffect(() => {
        fetchData()
        const interval = setInterval(() => {
            fetchData();
        },10000);
        return () => clearInterval(interval)
      },[]);
    return (
        <div className="grid-container">
            {data?.map((item, index) => (
                <div key={index} className={`grid-item ${flip ? 'flipped': ''}`} style={{"backgroundColor" : item['bg-color'], "color": item['txt-color']}}>
                    <div className='grid-item-content'>
                    
                        <div className='text-wrapper'>
                            {item.text}
                        </div>
                   
                    </div>
                            
                </div>
            ))}
        </div>
    )
}

export default ResponsiveTable1;