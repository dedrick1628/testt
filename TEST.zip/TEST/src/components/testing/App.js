import React, { useState, useEffect, useMemo, Suspense } from 'react';
import logo from './logo.svg';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom'
import { AppProvider } from '@toolpad/core/AppProvider';
import './App.css';
import Box from '@mui/material/Box';
import Paper from '@mui/material/Paper';
import { experimentalStyled as styled } from '@mui/material/styles';

import { makeStyles } from '@mui/styles';
import axios from 'axios';
import Monitoring from './components/Monitoring';

import Monitoring from './components/Monitoring2';

import Home from './Home';

const userStyles = makeStyles({
  table: {
    backgroundColor: '#81c784',
  },
  thead: {
    backgroundColor: '#4caf50',
  }
});

const App = () => {
  const classes = userStyles();
  const [confData, setconfData] = useState({})
  const [isLoading, setisLoading] = useState(false)
  const authSession = sessionStorage.getItem('auth')
  // useEffect(() => {
  //   axios
  //     .get("http://localhost:8000/getConfDetails")
  //     .then((res) => {
  //       setconfData(res.data);
  //       setisLoading(true);
  //      console.log("resresresresres ===>", res)
  //     })
  // },[])

 
  const Item = styled(Paper)(({ theme }) => ({
    backgroundColor: '#fff',
    ...theme.typography.body2,
    padding: theme.spacing(2),
    textAlign: 'center',
    color: theme.palette.text.secondary,
    ...theme.applyStyles('dark', {
      backgroundColor: '#FFF',
    }),
  }));
  return(
    <Router>
      <Routes>
        
         
        <Route exact path="/sog" element={<Monitoring/>}/>
       
      </Routes>
    </Router>
  
  );
}

export default App;
