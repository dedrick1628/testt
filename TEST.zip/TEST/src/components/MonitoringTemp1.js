import React, { useState, useEffect, useMemo, Suspense } from 'react';


import '../App.css';
import Box from '@mui/material/Box';
import Paper from '@mui/material/Paper';
import { experimentalStyled as styled } from '@mui/material/styles';
import Grid from '@mui/material/Grid';
import Table from '@mui/material/Table';
import { TableCell, TableHead, TableRow } from '@mui/material';
import { makeStyles } from '@mui/styles';
import axios from 'axios';
import Monitoring from './Monitoring';
import ResponsiveTable from './ResponsiveTable1';
import ResponsiveTableTemp1 from './ResponsiveTableTemp1';
import ToggleButton from '@mui/material/ToggleButton';
import ToggleButtonGroup from '@mui/material/ToggleButtonGroup';
import ResponsiveTableDB from './DB/ResponsiveTableDB';
import ResponsiveTableDBTabs from './DB/ResponsiveTableDBTabs';
// import ResponsiveTable from './ResponsiveTable';
const MonitoringTemp1 = () => {
  const [alignment, setAlignment] = useState('KIBANA');
  const locale = 'en';
  const handleChange = (event, newAlignment) => {
    setAlignment(newAlignment);
  };
 
  const [entityChannel, setentityChannel] = useState([])
  const [curr_time, setCurrentTime] = useState("")
  const [today, setDate] = React.useState(new Date());
  const [entityData, setEntityData] = useState([])
  const [transactionData, setTransactionData] = useState([])

  const [entityChannelDB, setentityChannelDB] = useState([])
  const [kibanacolor, setKibanacolor] = useState('')
  const [dbcolor, setdbColor] = useState('')
  const [entityDataDB, setEntityDataDB] = useState([])
  const [transactionDataDB, setTransactionDataDB] = useState([])
  const [kibanaSelection, setKibanaSelection] = useState(true)
  const [dbSelection, setDBSelection] = useState(false)
  const [confData, setconfData] = useState({})
  const [sogList, setsogList] = useState([
  ])
  const [textColor, setTextcolor] = useState('red')
  const [isLoading, setisLoading] = useState(false)
  const [channelName, setchannelName] = useState('')
  
  //const time = today.toLocaleTimeString(locale, { hour: 'numeric', hour12: true, minute: 'numeric' });
  //setCurrentTime(time)
      
      const fetchEntityData = () => {
        let channel_data={}
        axios
          .get("http://localhost:8000/getentities/"+localStorage.getItem('transactionId'))
          .then((res) => {
            setEntityData(res.data)
            let enity_details = []
            res.data?.map((data, index) => {
              if(data["BG_COLOR"] != 'grey') {
                channel_data["TRANSACTION_ID"] = data["TRANSACTION_ID"]
                enity_details.push(data["ENTITY_NAME"])
                
              }
            })
            channel_data["ENTITY_DETAILS"] = enity_details
          })
    }

    const fetchTransactionData = () => {
        axios
          .get("http://localhost:8000/gettransaction")
          .then((res) => {
            setTransactionData(res.data);
            const kibanColor = res.data.filter((data) => data['BG_COLOR'] == 'red')
            if (kibanColor.length > 0) {
              setKibanacolor('red')
            } else {
              setKibanacolor('green')
            }
            console.log("kibanColor ==>", kibanColor)
            fetchEntityData();
          })
      }


      

  
    const callAPIAfterTransaction = () => {
      fetchTransactionData()
      //fetchTransactionData_db()
    }
      useEffect(() => {
        var currentdate = new Date(); 
        var datetime = "Last Refresh: " + currentdate.getMonth()+1 + "-"
                + (currentdate.getDate()+1)  + "-" 
                + currentdate.getFullYear() + " @ "  
                + currentdate.getHours() + ":"  
                + currentdate.getMinutes() + ":" 
                + currentdate.getSeconds();
        setCurrentTime(datetime)

        fetchTransactionData()
        
      const interval = setInterval(() => {
        var currentdate = new Date(); 
        var datetime = "Last Refresh: " + currentdate.getMonth()+1 + "-"
                + (currentdate.getDate()+1)  + "-" 
                + currentdate.getFullYear() + " @ "  
                + currentdate.getHours() + ":"  
                + currentdate.getMinutes() + ":" 
                + currentdate.getSeconds();
          setCurrentTime(datetime)
          fetchTransactionData()
          //fetchTransactionData_db()
        },10000);
        return () => clearInterval(interval) 
      },[]);
  return(
    <div>
    
    <div >
    
      <br/>
      <div><span style={{backgroundColor:'black', color:'white', height: '30px', width: '20px', display: 'inline-block'}}>10</span>:<span style={{backgroundColor:'black', color:'white', height: '30px', width: '20px', display: 'inline-block'}}>10</span>:<span style={{bbackgroundColor:'black', color:'white', height: '30px', width: '20px', display: 'inline-block'}}>10</span> <span style={{backgroundColor:'black', color:'white', height: '30px', width: '20px', display: 'inline-block'}}>AM</span></div>
       {/* <ToggleButton value="KIBANA" style={{backgroundColor: kibanacolor, color: 'white', borderColor: 'white', opacity: alignment=='KIBANA'?'100%':'10%'}}><bold>KIBANA</bold></ToggleButton>
      <ToggleButton value="DATABASE" style={{backgroundColor: dbcolor, color: 'white', borderColor: 'white', opacity: alignment=='DATABASE'?'100%':'10%'}}><bold>DATABASE</bold></ToggleButton> */}
     
     
      {/* <ResponsiveTable /> */}
     {
      alignment == 'KIBANA' ? <ResponsiveTableTemp1 callAPIAfterTransaction={callAPIAfterTransaction} transactionData={transactionData} transactionName={localStorage.getItem('transactionId')} entityData={entityData} source='kibana'/> : <ResponsiveTableDBTabs callAPIAfterTransaction={callAPIAfterTransaction} transactionData={transactionDataDB} entityData={entityDataDB} source='database'/>
     } 
    
    </div>
    <div style={{width: '100%', height: '50px',backgroundColor: 'black', color: 'white'}}>
    <p style={{paddingLeft: '20rem'}}>Proprietary and Confidential. Not for disclosure outside of Verizon. <span style={{paddingLeft: '1rem'}}>© 2025 Verizon</span></p>
    </div>
    </div>
  );
}

export default MonitoringTemp1;
