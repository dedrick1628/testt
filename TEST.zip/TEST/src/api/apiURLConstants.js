const order360Journey = "http://localhost:8080/cxp-backoffice-services/";
//const order360Journey = 'https://tdcldjl8va001.ebiz.verizon.com/cxp-backoffice-services/'
const order360Service = 'https://order360-jl8v.verizon.com/order360-service/';
const order360Correction = 'https://order360-jl8v.verizon.com/order360-correction-services/';

const apiUrls = {
  orderSummary: `${order360Journey}order-summary`,
  journeyView: `${order360Journey}journeyView`,
  customerDetails: `${order360Journey}customer-details`,
  orderDetails: `${order360Journey}api/v1/orderDetails`,
  tableView: `${order360Journey}tableViews`,
  cardViews: `${order360Journey}cardViews`,
  getTemplates: `${order360Journey}getTemplate`,
  getSearchQueries: `${order360Journey}getSearchNormalize`,
  groupedTableView: `${order360Journey}api/decoded-search/details`,
  historyFilters: `${order360Journey}historyFilters`,
  graphicalView: `${order360Journey}graphicalView`,
  process: `${order360Journey}routing`,
  communications: `${order360Journey}communications`,
  dataIntegrityFilters :`${order360Journey}dataIntegrityFilters`,
  dataIntegrity: `${order360Journey}dataIntegrity`,
  orderCorrection: `${order360Journey}api/v1/reflows`,
  getReflowXml: `${order360Service}order-journey-payload`,
  searchCriteria: `${order360Journey}usage-metrics`,
  caseAi: `${order360Journey}caseAi`,
  orderType: `${order360Journey}dynamic-query`,
  reflowValidation: `${order360Journey}reflow-validation`,
  enableReflow: `${order360Journey}enable-reflow`,
  genericView: `${order360Journey}generic-view`,
  clickToCall: `${order360Journey}clicktocall`,
};

export default apiUrls;
