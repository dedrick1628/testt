import React, { useState, useEffect, useMemo, Suspense } from 'react';
import logo from './logo.svg';
import { Route, Switch, Link, useHistory, useLocation } from 'react-router-dom';
import './App.css';

import Paper from '@mui/material/Paper';
import { experimentalStyled as styled } from '@mui/material/styles';
import Grid from '@mui/material/Grid';
import Table from '@mui/material/Table';
import { TableCell, TableHead, TableRow } from '@mui/material';
import TextField from '@mui/material/TextField';
import MenuItem from '@mui/material/MenuItem';
import Box from '@mui/material/Box';
import { makeStyles } from '@mui/styles';
import axios from 'axios';

const userStyles = makeStyles({
  table: {
    backgroundColor: '#81c784',
  },
  thead: {
    backgroundColor: '#4caf50',
  }
});

const UpdateQuery = () => {
  const classes = userStyles();

  const [confData, setconfData] = useState({})
  const [isLoading, setisLoading] = useState(false)

  const category = [
    {
      value: 'Switch',
      label: 'Switch',
    },
    {
      value: 'Data Integrity',
      label: 'Data Integrity',
    },
    {
      value: 'Case Management',
      label: 'Case Management',
    },
    {
      value: 'NumberShare',
      label: 'NumberShare',
    },
    {
        value: 'Perks',
        label: 'Perks',
    },
    {
        value: 'Tradein',
        label: 'Tradein',
    },
    {
        value: 'FWA',
        label: 'FWA',
    },
    {
        value: 'Activation',
        label: 'Activation',
    },
    {
        value: 'Mobility',
        label: 'Mobility',
    },
    {
        value: 'DPP',
        label: 'DPP',
    },
    {
        value: 'Trade',
        label: 'Trade',
    },
    {
        value: 'POS API',
        label: 'POS API',
    },
  ];
 
  return(
    <Box
      component="form"
      sx={{ '& .MuiTextField-root': { m: 1, width: '25ch' } }}
      noValidate
      autoComplete="off"
    >
      <div>
      <TextField
          id="outlined-select-category"
          select
          label="Category"
          defaultValue="Switch"
          
        >
          {category.map((option) => (
            <MenuItem key={option.value} value={option.value}>
              {option.label}
            </MenuItem>
          ))}
        </TextField>

        <TextField
          id="outlined-multiline-flexible"
          label="Scenario"
          multiline
          maxRows={10}
        />

        <TextField
          id="outlined-select-isactive"
          select
          label="Is Active"
          defaultValue="Yes"
          
        >
          <MenuItem key="yes" value="Yes">
              Yes
            </MenuItem>
            <MenuItem key="no" value="No">
              No
            </MenuItem>
        </TextField>

      </div>
      <Box>
        <div>
        <TextField
          id="outlined-select-alert-type"
          select
          label="Alert type"
          defaultValue="Alert"
          
        >
          <MenuItem key="alert" value="Alert">
              Alert
            </MenuItem>
            <MenuItem key="report" value="Report">
              Report
            </MenuItem>
        </TextField>
        </div>
      </Box>
    </Box>
  
  );
}

export default UpdateQuery;
