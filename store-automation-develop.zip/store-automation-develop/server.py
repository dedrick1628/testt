from typing import Union
from fastapi.responses import StreamingResponse
from fastapi.responses import HTMLResponse
from fastapi import Request,FastAPI,Response,File,UploadFile
#from fastapi.response import JSONResponse
from starlette.responses import JSONResponse
import oracledb
import json
import urllib.parse
import os
from fastapi.middleware.cors import CORSMiddleware
from fastapi import FastAPI, Request
from starlette.responses import RedirectResponse

import io
import pandas as pd



import asyncio
import httpx
import io
from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from starlette.responses import StreamingResponse
from AysIncidents import AYSAnalyser
from AysIncidents_V1 import AYSAnalyser_V1
from RuleEngine import SimpleRuleEngine
from RuleEngine_V1 import SimpleRuleEngine_V1

server = FastAPI()

origins = ["*"]

oracledb.defaults.fetch_lobs = False

server.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
# db_jobs = JobScheduler()
# kibana_jobs = KibanaScheduler()
proxy = f'http://vzproxy.verizon.com:9290'
os.environ['http_proxy'] = '' 
os.environ['HTTP_PROXY'] = ''
os.environ['https_proxy'] = ''
os.environ['HTTPS_PROXY'] = ''


@server.post("/api/v1/process-aysincident")
async def process_aysincident(file: UploadFile = File(...)):
    print("api is calling")
    if not file.filename.endswith('.xlsx'):
        raise HTTPException(status_code=400, detail="Invalid file type. Please upload a .xlsx file.")
    print("api is calling")
    try:
        # Read the uploaded file directly into pandas
        contents = await file.read()
        buffer = io.BytesIO(contents)
        
        df = pd.read_excel(buffer)
        ays_inc_bot = AYSAnalyser()
        # Iterate through each row in the DataFrame
        for index, row in df.iterrows():
            single_row_df = pd.DataFrame([row])
            ays_inc_bot.process_ays_orders(row)
        results = ays_inc_bot.pricess_pending_orders()

        results_df = pd.DataFrame(results)
        

       
        print("Inserted records into the database.", results_df)
        
        # Optional: Save detailed results to a separate file for debugging (local copy)
        results_df.to_excel('AYS_processed_data.xlsx', index=False)
        
        # Save the result to an in-memory buffer for response
        output_buffer = io.BytesIO()
        with pd.ExcelWriter(output_buffer, engine='openpyxl') as writer:
            results_df.to_excel(writer, index=False, sheet_name='ProcessedAYSData')
        
        output_buffer.seek(0)

        # Stream the file back to the client
        return StreamingResponse(
            output_buffer,
            media_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            headers={"Content-Disposition": "attachment; filename=AYS_processed_data.xlsx"}
        )
    except Exception as e:
        # Catch any other unexpected errors
        raise HTTPException(status_code=500, detail=f"An unexpected error occurred: {str(e)}")


    
@server.post("/api/v1/process_slack_orders")
async def process_slack_orders(request: Request):
    try:
        req = await request.json()
        DB_CONFIG = {
            'user': 'CXP_OPS_MONITORING',
            'password': 'QWEqwe##00',
            'dsn': 'tpalpbrhvd00-scan.verizon.com:1532/cxpopsmon_srv01'
        }

        # Initialize the simple rule engine (robust connection handling)
        

        rule_engine = SimpleRuleEngine(DB_CONFIG)
        result = rule_engine.process_order_request(
            order_number=req.get('order_number'),
            location_code=req.get('location_code'),
            order_type='PENDING ORDER',
            user_name=''  # Use actual user name from thread lookup
        )
        return JSONResponse(content=result)
    except Exception as er:
        print("Error in ", er)

@server.post("/api/v1/process_slack_orders_V1")
async def process_slack_orders1(request: Request):
    try:
        req = await request.json()
        DB_CONFIG = {
            'user': 'CXP_OPS_MONITORING',
            'password': 'QWEqwe##00',
            'dsn': 'tpalpbrhvd00-scan.verizon.com:1532/cxpopsmon_srv01'
        }

        # Initialize the simple rule engine (robust connection handling)
        

        rule_engine = SimpleRuleEngine_V1(DB_CONFIG)
        result = rule_engine.process_order_request(
            order_number=req.get('order_number'),
            location_code=req.get('location_code'),
            order_type='PENDING ORDER',
            user_name=''  # Use actual user name from thread lookup
        )
        return JSONResponse(content=result)
    except Exception as er:
        print("Error in ", er)
@server.post("/api/v1/process-aysincident_V1")
async def process_aysincident_V1(file: UploadFile = File(...)):
    print("api is calling")
    if not file.filename.endswith('.xlsx'):
        raise HTTPException(status_code=400, detail="Invalid file type. Please upload a .xlsx file.")
    print("api is calling")
    try:
        # Read the uploaded file directly into pandas
        contents = await file.read()
        buffer = io.BytesIO(contents)
        
        df = pd.read_excel(buffer)
        ays_inc_bot = AYSAnalyser_V1()
        # Iterate through each row in the DataFrame
        for index, row in df.iterrows():
            single_row_df = pd.DataFrame([row])
            ays_inc_bot.process_ays_orders(row)
        results = ays_inc_bot.process_pending_orders()

        results_df = pd.DataFrame(results)
        

       
        
        
        # Optional: Save detailed results to a separate file for debugging (local copy)
        results_df.to_excel('AYS_processed_data.xlsx', index=False)
        
        # Save the result to an in-memory buffer for response
        output_buffer = io.BytesIO()
        with pd.ExcelWriter(output_buffer, engine='openpyxl') as writer:
            results_df.to_excel(writer, index=False, sheet_name='ProcessedAYSData')
        
        output_buffer.seek(0)
        headers = {
            "Content-Disposition": "attachment; filename=AYS_processed_data.xlsx",
            
            # --- THIS IS THE MISSING LINE ---
            "Access-Control-Expose-Headers": "Content-Disposition"
        }
        # Stream the file back to the client
        return StreamingResponse(
            output_buffer,
            media_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            headers=headers
        )
    except Exception as e:
        # Catch any other unexpected errors
        raise HTTPException(status_code=500, detail=f"An unexpected error occurred: {str(e)}")
    # ays_inc_bot = AYSAnalyser_V1()          
    # result = ays_inc_bot.process_order_request(
    #     order_number=order_number,
    #     location_code=location_code,
    #     order_type=order_type,
    #     user_name=user_name
    # )
    # return result           
