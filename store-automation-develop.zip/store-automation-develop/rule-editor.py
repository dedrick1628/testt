import flask
from flask import Flask, jsonify, request, render_template_string
import csv
import oracledb  # This is now required
import os

app = Flask(__name__)

# --- METADATA-DRIVEN CORE ---
# This remains the single source of truth for the UI.
# The table names ('rules', 'stores', etc.) MUST match your
# Oracle table names exactly.
TABLE_CONFIG = {
    'TEMP_CXP_STORE_SUPPORT_RULE': {
        'pk': 'RULE_ID',
        'display_name': 'Rules',
        'columns': [
            'RULE_ID', 'RULE_NAME', 'RULE_INTENT_TYPE', 'RULE_DESC', 
            'RULE_TYPE', 'RULE_STEP_NUMBER', 'FILED_PATH', 'OPERATOR', 
            'EXPECTED_VALUE', 'RULE_ACTION', 'RULE_NEXT_STEP', 'IS_ACTIVE', 'RULE_CONTEXT'
        ]
    },
    'TEMP_CXP_STORE_SUPPORT_RESP_TEMPLATE': {
        'pk': 'TEMPLATE_ID',
        'display_name': 'Templates',
        'columns': ['TEMPLATE_ID', 'TEMPLATE_NAME', 'MESSAGE_CONTENT', 'MESSAGE_TYPE', 'DESCRIPTION', 'IS_ACTIVE', 'CREATED_BY','CREATED_DATE']
    },
    'TEMP_cxp_store_support_api_db_configuration': {
        'pk': 'CONF_ID',
        'display_name': 'API Config',
        'columns': ['CONF_ID','RULE_ID', 'API_NAME', 'API_URL', 'API_HEADERS', 'API_REQUEST_PAYLOAD', 'QUERY_NAME', 'QUERY','METHOD']
    },
}
# --- End of Metadata Config ---


def get_oracle_connection():
    """
    Connects to Oracle Database. Ensure the Oracle Instant Client is installed.
    """
    # Load credentials and DSN from environment variables
    ORACLE_USER = os.getenv("ORACLE_USER", "CXP_OPS_MONITORING")
    ORACLE_PASS = os.getenv("ORACLE_PASS", "QWEqwe##00")
    ORACLE_DSN = os.getenv("ORACLE_DSN", "tpalpbrhvd00-scan.verizon.com:1532/cxpopsmon_srv01")

    try:
        # Log the DSN for debugging
        print(f"Connecting to Oracle Database with DSN: {ORACLE_DSN}")

        conn = oracledb.connect(
            user=ORACLE_USER,
            password=ORACLE_PASS,
            dsn=ORACLE_DSN
        )
        print("Successfully connected to Oracle Database.")
        return conn
    except oracledb.DatabaseError as e:
        error, = e.args
        print(f"Error connecting to Oracle Database:")
        print(f"  Error Code: {error.code}")
        print(f"  Error Message: {error.message}")
        print(f"  Context: {error.context}")
        print("\nPlease check your credentials, DSN, and network access.")
        print("Ensure the Oracle Instant Client is installed and accessible.")
        return None
    except Exception as e:
        print(f"An unexpected error occurred during Oracle connection: {e}")
        print("Check if the hostname in the DSN is resolvable.")
        return None

# Add this new helper function after get_oracle_connection()
def convert_lob_to_str(value):
    """Convert Oracle LOB objects to strings for JSON serialization."""
    if value is None:
        return None
    # Check if it's a LOB type (CLOB/BLOB)
    if hasattr(value, 'read'):
        try:
            return value.read()
        except Exception as e:
            print(f"Error reading LOB: {e}")
            return str(value)
    return value

def process_row_data(row_dict):
    """Process a row dictionary to handle LOB columns."""
    processed = {}
    for key, value in row_dict.items():
        processed[key] = convert_lob_to_str(value)
    return processed

# ---
# GENERIC Database Functions (LIVE)
# ---

def validate_table(table_name):
    """Security Check: Ensures table is in our config."""
    if table_name not in TABLE_CONFIG:
        raise ValueError(f"Invalid or unauthorized table: {table_name}")
    return TABLE_CONFIG[table_name]

def get_all_data_from_db(table_name):
    """LIVE: Returns all data for a given table from Oracle."""
    config = validate_table(table_name)  # Security check
    
    conn = get_oracle_connection()
    if conn:
        cursor = None
        try:
            cursor = conn.cursor()
            # Use f-string ONLY with validated table_name from config
            query = f"SELECT * FROM {table_name}"
            print(f"Executing query: {query}")  # Debugging: Log the query
            cursor.execute(query)
            columns = [col[0] for col in cursor.description]
            # Fetch all rows and process LOBs
            rows = cursor.fetchall()
            data = []
            for row in rows:
                row_dict = dict(zip(columns, row))
                processed_row = process_row_data(row_dict)
                data.append(processed_row)
            print(f"Query result: {len(data)} rows fetched")
            return data
        except Exception as e:
            print(f"Error in get_all_data_from_db: {e}")  # Debugging: Log the error
            return []  # Return empty on error
        finally:
            if cursor: cursor.close()
            if conn: conn.close()
    return []

def get_one_data_from_db(table_name, pk_value):
    """LIVE: Finds a single record in Oracle."""
    config = validate_table(table_name) # Security check
    pk_col = config['pk']

    conn = get_oracle_connection()
    if conn:
        cursor = None
        try:
            cursor = conn.cursor()
            # Use f-string for table/column, but bind variable for value
            sql = f"SELECT * FROM {table_name} WHERE {pk_col} = :1"
            
            cursor.execute(sql, [pk_value])
            columns = [col[0] for col in cursor.description]
            cursor.rowfactory = lambda *args: dict(zip(columns, args))
            
            row = cursor.fetchone()
            if row:
                row_dict = dict(zip(columns, row))
                return process_row_data(row_dict)
            return None
        except Exception as e:
            print(f"Error in get_one_data_from_db: {e}")
            return None
        finally:
            if cursor: cursor.close()
            if conn: conn.close()
    return None

def update_data_in_db(table_name, pk_value, data):
    """LIVE: Updates a record in Oracle."""
    config = validate_table(table_name) # Security check
    pk_col = config['pk']

    # Build the "SET" part of the query dynamically
    set_clause_parts = []
    # Use data.keys() instead of config['columns'] in case only
    # partial data is sent, although our UI sends all.
    for col in data.keys():
        if col != pk_col: # Don't update primary key
            set_clause_parts.append(f"{col} = :{col}")
    set_clause = ", ".join(set_clause_parts)
    
    # Ensure PK is in the data dict for binding
    data[pk_col] = pk_value
    
    sql = f"UPDATE {table_name} SET {set_clause} WHERE {pk_col} = :{pk_col}"
    
    conn = get_oracle_connection()
    if conn:
        cursor = None
        try:
            cursor = conn.cursor()
            # 'data' dictionary must have keys matching all column names
            cursor.execute(sql, data)
            conn.commit()
            return True
        except Exception as e:
            print(f"Error in update_data_in_db: {e}")
            conn.rollback() # Rollback changes on error
            return False
        finally:
            if cursor: cursor.close()
            if conn: conn.close()
    return False

def create_data_in_db(table_name, data):
    """LIVE: Adds a new record to Oracle."""
    config = validate_table(table_name) # Security check

    # Use data.keys() to build query dynamically
    cols = data.keys()
    col_names = ", ".join(cols)
    col_binds = ", ".join([f":{col}" for col in cols])
    
    sql = f"INSERT INTO {table_name} ({col_names}) VALUES ({col_binds})"
    
    conn = get_oracle_connection()
    if conn:
        cursor = None
        try:
            cursor = conn.cursor()
            cursor.execute(sql, data)
            conn.commit()
            return True
        except Exception as e:
            print(f"Error in create_data_in_db: {e}")
            conn.rollback()
            return False
        finally:
            if cursor: cursor.close()
            if conn: conn.close()
    return False

def delete_data_from_db(table_name, pk_value):
    """LIVE: Deletes a record from Oracle."""
    config = validate_table(table_name) # Security check
    pk_col = config['pk']

    sql = f"DELETE FROM {table_name} WHERE {pk_col} = :1"
    conn = get_oracle_connection()
    if conn:
        cursor = None
        try:
            cursor = conn.cursor()
            cursor.execute(sql, [pk_value])
            conn.commit()
            return True
        except Exception as e:
            print(f"Error in delete_data_from_db: {e}")
            conn.rollback()
            return False
        finally:
            if cursor: cursor.close()
            if conn: conn.close()
    return False

# --- HTML Template ---
HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Low-Code Admin Platform</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        #confirmation-modal { transition: opacity 0.3s ease; }
        thead th { position: sticky; top: 0; background-color: #f3f4f6; z-index: 10;}
        .form-label { @apply block text-sm font-medium text-gray-700 mb-1; }
        .form-input { @apply block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm; border:1px solid grey;border-radius:5px  }
        .nav-button { @apply w-full text-left px-3 py-2 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-200; }
        .nav-button-active { @apply w-full text-left px-3 py-2 rounded-md text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700; }
    </style>
</head>
<body class="bg-gray-100 font-sans">

    <!-- Header -->
    <div class="bg-white shadow-sm">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
            <h1 class="text-2xl font-bold text-gray-900">Low-Code Admin Platform</h1>
            <p class="text-gray-600">Unified hub for managing business configuration.</p>
        </div>
    </div>

    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 grid grid-cols-1 lg:grid-cols-4 gap-8">
        
        <!-- Navigation Column -->
        <div class="lg:col-span-1 h-max">
             <div class="bg-white p-4 rounded-lg shadow-md">
                <h2 class="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-3">Manage Tables</h2>
                <nav id="table-navigation" class="space-y-2">
                    <!-- Nav buttons will be injected by JavaScript -->
                </nav>
            </div>
        </div>

        <!-- Form Column -->
        <div class="lg:col-span-1 bg-white p-6 rounded-lg shadow-md h-max">
            <form id="data-form">
                <h2 id="form-title" class="text-xl font-semibold mb-4">Create New</h2>
                <input type="hidden" id="form-mode" value="create">
                
                <!-- Form fields will be injected by JavaScript -->
                <div id="form-fields" class="grid grid-cols-1 gap-y-4">
                    <p class="text-gray-500">Select a table to begin.</p>
                </div>

                <div class="mt-6 flex items-center space-x-3">
                    <button type="submit" class="bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2 px-4 rounded-md shadow-sm">
                        Save
                    </button>
                    <button type="button" id="clear-form-btn" class="bg-gray-200 hover:bg-gray-300 text-gray-800 font-bold py-2 px-4 rounded-md">
                        Clear
                    </button>
                </div>
            </form>
        </div>

        <!-- Table Column -->
        <div class="lg:col-span-2">
            <div class="flex justify-between items-center mb-4">
                <h2 id="table-title" class="text-xl font-semibold">Data</h2>
                <span id="record-count" class="text-gray-600"></span>
            </div>
            <div class="bg-white rounded-lg shadow-md overflow-hidden">
                <div class="overflow-x-auto" style="max-height: 80vh;">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead id="table-head" class="bg-gray-100">
                            <!-- Headers will be injected by JavaScript -->
                        </thead>
                        <tbody id="table-body" class="bg-white divide-y divide-gray-200">
                            <!-- Rows will be injected by JavaScript -->
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Confirmation Modal -->
    <div id="confirmation-modal" class="fixed inset-0 z-10 flex items-center justify-center bg-black bg-opacity-50 opacity-0 pointer-events-none">
        <!-- ... (Modal HTML is unchanged) ... -->
         <div class="bg-white rounded-lg shadow-xl p-6 w-full max-w-sm">
            <h3 class="text-lg font-medium text-gray-900" id="modal-title">Delete Record?</h3>
            <p class="mt-2 text-sm text-gray-500" id="modal-body">Are you sure you want to delete this record?</p>
            <div class="mt-4 flex justify-end space-x-3">
                <button id="modal-cancel-btn" class="bg-gray-200 hover:bg-gray-300 text-gray-800 font-bold py-2 px-4 rounded-md">
                    Cancel
                </button>
                <button id="modal-confirm-btn" class="bg-red-600 hover:bg-red-700 text-white font-bold py-2 px-4 rounded-md">
                    Delete
                </button>
            </div>
        </div>
    </div>

    <!-- 2. Main Application JavaScript -->
    <script>
        // Global state
        let current_table_name = null;
        let table_config = {};
        // The local_cache is still useful for holding the *current* table data
        // to avoid re-fetching on simple UI interactions, but it's populated
        // from the API, not from a file.
        let local_cache = {}; 

        document.addEventListener('DOMContentLoaded', async () => {
            // Entry point
            try {
                const response = await fetch('/api/config');
                if (!response.ok) throw new Error('Failed to load config');
                table_config = await response.json();
                
                buildNav(table_config);
                
                // We no longer load the first table by default.
                // The user will click a table from the nav to load it.
                document.getElementById('table-title').innerText = "Select a table";
                document.getElementById('record-count').innerText = "";
                document.getElementById('table-body').innerHTML = `<tr><td colspan="99" class="p-4 text-center text-gray-500">Please select a table from the navigation menu to begin.</td></tr>`;

            } catch (error) {
                console.error('Error on init:', error);
                document.getElementById('table-body').innerHTML = `<tr><td colspan="99" class="p-4 text-center text-red-500">Failed to load application configuration.</td></tr>`;
            }

            // Attach listeners
            document.getElementById('data-form').addEventListener('submit', handleFormSubmit);
            document.getElementById('clear-form-btn').addEventListener('click', resetForm);
        });

        function buildNav(config) {
            const nav = document.getElementById('table-navigation');
            nav.innerHTML = '';
            Object.keys(config).forEach(tableName => {
                const button = document.createElement('button');
                button.id = `nav-btn-${tableName}`;
                button.className = 'nav-button w-full'; // Ensure full width for each button
                button.innerText = config[tableName].display_name;
                button.onclick = () => loadEditor(tableName);
                nav.appendChild(button);
            });
        }

        async function loadEditor(tableName) {
            current_table_name = tableName;

            // Update Nav UI
            document.querySelectorAll('.nav-button, .nav-button-active').forEach(btn => {
                btn.className = btn.id === `nav-btn-${tableName}` 
                    ? 'nav-button-active w-full space-y-2' 
                    : 'nav-button w-full space-y-2'; // Maintain spacing
            });

            // Build form
            buildForm(tableName);

            // Load data and handle errors
            try {
                await loadData(tableName);
            } catch (error) {
                console.error(`Error loading data for table ${tableName}:`, error);
                document.getElementById('table-body').innerHTML = `<tr><td colspan="99" class="p-4 text-center text-red-500">Failed to load data for ${tableName}.</td></tr>`;
            }
        }

        async function loadData(tableName) {
            try {
                const response = await fetch(`/api/data/${tableName}`);
                if (!response.ok) {
                    throw new Error(`Failed to fetch data for table ${tableName}. Status: ${response.status}`);
                }
                local_cache[tableName] = await response.json();
                renderTable(tableName);
            } catch (error) {
                console.error('Error loading data:', error);
                throw error; // Re-throw the error to be handled by the caller
            }
        }

        function buildForm(tableName) {
            const config = table_config[tableName];
            const formFields = document.getElementById('form-fields');
            formFields.innerHTML = '';

            config.columns.forEach(col => {
                const div = document.createElement('div');
                
                const label = document.createElement('label');
                label.htmlFor = col;
                label.className = 'form-label';
                label.innerText = col;
                div.appendChild(label);
                
                // You could add logic here for different types
                // e.g., if (col.includes('Date')) ...
                
                const input = document.createElement('input');
                input.type = 'text';
                input.id = col;
                input.className = 'form-input';
                
                if (col === config.pk) {
                    input.placeholder = `e.g., ${col}_123`;
                    input.classList.add('bg-gray-50');
                }
                
                div.appendChild(input);
                formFields.appendChild(div);
            });
            resetForm(); // Set titles and mode
        }

        function renderTable(tableName) {
            const config = table_config[tableName];
            const data = local_cache[tableName];
            
            const tableHead = document.getElementById('table-head');
            const tableBody = document.getElementById('table-body');
            
            // Build Headers
            tableHead.innerHTML = '';
            const trHead = document.createElement('tr');
            config.columns.forEach(col => {
                const th = document.createElement('th');
                th.className = 'px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider';
                th.innerText = col;
                trHead.appendChild(th);
            });
            const thActions = document.createElement('th');
            thActions.className = 'px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider';
            thActions.innerText = 'Actions';
            trHead.appendChild(thActions);
            tableHead.appendChild(trHead);

            // Build Body
            tableBody.innerHTML = '';
            if (data.length === 0) {
                tableBody.innerHTML = `<tr><td colspan="${config.columns.length + 1}" class="p-4 text-center text-gray-500">No records found.</td></tr>`;
            }
            
            document.getElementById('table-title').innerText = config.display_name;
            document.getElementById('record-count').innerText = `${data.length} records`;

            data.forEach(record => {
                const tr = document.createElement('tr');
                tr.className = 'hover:bg-gray-50';
                
                config.columns.forEach(col => {
                    const td = document.createElement('td');
                    td.className = 'px-4 py-3 whitespace-nowrap text-sm text-gray-700';
                    td.innerText = record[col] || '';
                    if (col === config.pk) {
                        td.className = 'px-4 py-3 whitespace-nowrap text-sm font-medium text-indigo-600';
                    }
                    tr.appendChild(td);
                });

                // Add actions cell
                const pk_value = record[config.pk];
                const tdAct = document.createElement('td');
                tdAct.className = 'px-4 py-3 whitespace-nowrap text-sm font-medium';
                tdAct.innerHTML = `
                    <button onclick="handleEdit('${pk_value}')" class="text-indigo-600 hover:text-indigo-900">Edit</button>
                    <button onclick="handleDelete('${pk_value}')" class="text-red-600 hover:text-red-900 ml-4">Delete</button>
                `;
                tr.appendChild(tdAct);
                tableBody.appendChild(tr);
            });
        }
        
        function handleEdit(pk_value) {
            const config = table_config[current_table_name];
            const data = local_cache[current_table_name];
            const record = data.find(r => str(r[config.pk]) === str(pk_value));
            if (!record) return;

            // Populate form
            config.columns.forEach(col => {
                document.getElementById(col).value = record[col] || '';
            });
            
            // Set form state to "edit"
            const pkField = document.getElementById(config.pk);
            pkField.readOnly = true;
            pkField.classList.add('bg-gray-100');
            
            document.getElementById('form-title').innerText = `Edit ${config.display_name}`;
            document.getElementById('form-mode').value = 'edit';
            window.scrollTo({ top: 0, behavior: 'smooth' });
        }
        
        function str(val) {
            // Helper to prevent "null" vs null issues
            return val ? String(val) : '';
        }

        async function handleFormSubmit(event) {
            event.preventDefault();
            if (!current_table_name) return;

            const config = table_config[current_table_name];
            const formMode = document.getElementById('form-mode').value;
            const pk_col = config.pk;
            const pk_value = document.getElementById(pk_col).value;
            
            if (!pk_value) {
                alert(`${pk_col} is required.`);
                return;
            }

            // Build data object from form
            const recordData = {};
            config.columns.forEach(col => {
                // Only include fields that are not empty,
                // or are the PK.
                const val = document.getElementById(col).value;
                if (val || col === pk_col) {
                     recordData[col] = val;
                }
            });

            let url = `/api/data/${current_table_name}`;
            let method = 'POST';

            if (formMode === 'edit') {
                url = `/api/data/${current_table_name}/${pk_value}`;
                method = 'PUT';
            }

            try {
                const response = await fetch(url, {
                    method: method,
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(recordData)
                });

                if (!response.ok) {
                    const error = await response.json();
                    throw new Error(error.message || 'Failed to save record');
                }

                await loadData(current_table_name); // Reload table
                resetForm(); // Clear form
                
            } catch (error) {
                console.error('Error saving record:', error);
                alert(`Error: ${error.message}`);
            }
        }

        function handleDelete(pk_value) {
            if (!current_table_name) return;
            const config = table_config[current_table_name];
            
            // Use custom modal
            const modal = document.getElementById('confirmation-modal');
            modal.classList.remove('opacity-0', 'pointer-events-none');
            
            document.getElementById('modal-title').innerText = `Delete: ${pk_value}?`;
            document.getElementById('modal-body').innerText = `Are you sure you want to delete this record from ${config.display_name}?`;

            const confirmBtn = document.getElementById('modal-confirm-btn');
            const cancelBtn = document.getElementById('modal-cancel-btn');

            const newConfirmBtn = confirmBtn.cloneNode(true);
            confirmBtn.parentNode.replaceChild(newConfirmBtn, confirmBtn);

            newConfirmBtn.addEventListener('click', async () => {
                try {
                    const url = `/api/data/${current_table_name}/${pk_value}`;
                    const response = await fetch(url, { method: 'DELETE' });
                    if (!response.ok) {
                        const error = await response.json();
                        throw new Error(error.message || 'Failed to delete');
                    }
                    await loadData(current_table_name);
                } catch (error) {
                    console.error('Error deleting:', error);
                    alert(`Error: ${error.message}`);
                } finally {
                    closeModal();
                }
            });
            cancelBtn.onclick = closeModal;
        }

        function closeModal() {
            const modal = document.getElementById('confirmation-modal');
            modal.classList.add('opacity-0', 'pointer-events-none');
        }

        function resetForm() {
            if (!current_table_name) return;
            const config = table_config[current_table_name];
            
            document.getElementById('data-form').reset();
            
            const pkField = document.getElementById(config.pk);
            if (pkField) {
                pkField.readOnly = false;
                pkField.classList.remove('bg-gray-100');
            }
            
            document.getElementById('form-title').innerText = `Create New ${config.display_name}`;
            document.getElementById('form-mode').value = 'create';
        }

    </script>
</body>
</html>
"""

# ---
# GENERIC API Routes
# ---

@app.route('/')
def index():
    """Serves the main HTML page."""
    return render_template_string(HTML_TEMPLATE)

@app.route('/api/config', methods=['GET'])
def get_config():
    """Returns the master table configuration."""
    # Only return display_name, pk, and columns.
    # No need to expose internal logic.
    public_config = {
        name: {
            'display_name': conf['display_name'],
            'pk': conf['pk'],
            'columns': conf['columns']
        } for name, conf in TABLE_CONFIG.items()
    }
    return jsonify(public_config)

@app.route('/api/data/<string:table_name>', methods=['GET'])
def get_all_data(table_name):
    """Returns all records for a given table."""
    try:
        validate_table(table_name) # Security check
        data = get_all_data_from_db(table_name)
        return jsonify(data)
    except ValueError as e:
        return jsonify({"message": str(e)}), 404
    except Exception as e:
        return jsonify({"message": f"Server error: {e}"}), 500

@app.route('/api/data/<string:table_name>', methods=['POST'])
def create_data(table_name):
    """Creates a new record in a given table."""
    try:
        config = validate_table(table_name) # Security check
        data = request.json
        if not data:
            return jsonify({"message": "No data provided"}), 400
        
        # Check for existing PK
        pk_col = config['pk']
        if not data.get(pk_col):
             return jsonify({"message": f"Primary key '{pk_col}' is required"}), 400
        
        if get_one_data_from_db(table_name, data[pk_col]):
            return jsonify({"message": "Record with this Primary Key already exists"}), 409
        
        if create_data_in_db(table_name, data):
            return jsonify(data), 201
        return jsonify({"message": "Failed to create record"}), 500
        
    except ValueError as e:
        return jsonify({"message": str(e)}), 404
    except Exception as e:
        return jsonify({"message": f"Server error: {e}"}), 500


@app.route('/api/data/<string:table_name>/<string:pk_value>', methods=['PUT'])
def update_data(table_name, pk_value):
    """Updates an existing record in a given table."""
    try:
        config = validate_table(table_name) # Security check
        data = request.json
        if not data:
            return jsonify({"message": "No data provided"}), 400
        
        # Ensure PK in body matches URL
        pk_col = config['pk']
        if str(data.get(pk_col)) != str(pk_value):
             return jsonify({"message": f"Primary Key in URL and body do not match"}), 400
        
        if update_data_in_db(table_name, pk_value, data):
            return jsonify(data), 200
        return jsonify({"message": "Record not found or failed to update"}), 404

    except ValueError as e:
        return jsonify({"message": str(e)}), 404
    except Exception as e:
        return jsonify({"message": f"Server error: {e}"}), 500

@app.route('/api/data/<string:table_name>/<string:pk_value>', methods=['DELETE'])
def delete_data(table_name, pk_value):
    """Deletes a record from a given table."""
    try:
        validate_table(table_name) # Security check
        
        if delete_data_from_db(table_name, pk_value):
            return jsonify({"message": "Record deleted"}), 200
        return jsonify({"message": "Record not found"}), 404

    except ValueError as e:
        return jsonify({"message": str(e)}), 404
    except Exception as e:
        return jsonify({"message": f"Server error: {e}"}), 500


# --- Main entry point ---
if __name__ == '__main__':
    # We no longer initialize the DB from a CSV.
    # The app is now fully live against Oracle.
    
    print("\n" + "="*50)
    print("Starting the Low-Code Admin Platform (LIVE ORACLE MODE)...")
    print("Managed Tables:")
    for name, conf in TABLE_CONFIG.items():
        print(f"  - {conf['display_name']} (table: {name})")
    print("\n!! IMPORTANT !!")
    print("Make sure your Oracle credentials in 'get_oracle_connection()' are correct.")
    print("\nTo run this app, make sure you have Flask installed:")
    print("  pip install Flask oracledb")
    print("\nThen run this file:")
    print("  python admin_platform_app.py")
    print("\nOpen your browser and go to:")
    print("  http://127.0.0.1:5000")
    print("="*50 + "\n")
    
    app.run(debug=True, port=5000)