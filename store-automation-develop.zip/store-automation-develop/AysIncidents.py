"""
Database-Driven Rule Engine for Order Processing
Fully configurable through database with no hardcoded values
"""

import json
import oracledb
import requests
import logging
import os
import json
from datetime import datetime
import re
from typing import Dict, Any, List, Optional
import uuid  # For session ID generation
import pandas as pd  # For reading Excel files
import openpyxl  # Alternative Excel reader (optional)

# Add Slack integration
from slack_sdk import WebClient
import urllib3
from RuleEngine import SimpleRuleEngine
# Disable SSL warnings for API calls
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

class AYSAnalyser:
    """
    Database-driven rule engine that processes order requests
    All configurations stored in database
    """
    
    def __init__(self):
        DB_CONFIG = {
            'user': 'CXP_OPS_MONITORING',
            'password': 'QWEqwe##00',
            'dsn': 'tpalpbrhvd00-scan.verizon.com:1532/cxpopsmon_srv01'
        }
        self.ml_pending_orders=[]
        self.rule_final_results=[]
        # print("xls_dataxls_data==>",xls_data)
        # # Initialize the simple rule engine (robust connection handling)
        self.rule_engine = SimpleRuleEngine(DB_CONFIG)
        # self.logger = logging.getLogger(__name__)
        # self.extracted_results = self.get_ml_pnd_summary("Pending Order.xlsx")
        # print("self.extracted_results==>",self.extracted_results)
        # order_detail = self.extracted_results.get('order_details', [])
        
        # # print("order_detail ==>", order_detail)
        # for order in order_detail:
        #     if order is not None:
        #         print("order_detail11 ==>")
        #         self.process_orders(order,rule_engine)
    def filter_ml_pnd_orders(self, xls_data:Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        Filter orders where Description column contains 'ML_PND'
        
        Args:
            xls_data: Dictionary containing Excel data
            
        Returns:
            List of rows where Description contains 'ML_PND'
        """
        print(f"🔍 Filtering orders with Description containing 'ML_PND'...{xls_data}")
        
        # if not xls_data or 'sheets' not in xls_data:
        #     print(f"❌ Invalid Excel data provided")
        #     return []
        
        # ml_pnd_orders = []
        # total_processed = 0
        
        # for sheet_name, sheet_data in xls_data['sheets'].items():
        #     print(f"🔍 Searching in sheet: {sheet_name}")
        #     sheet_matches = 0
            
        #     for row in sheet_data['data']:
        #         total_processed += 1
                
        #         # Check if 'Description' column exists and contains 'ML_PND'
        #         description = row.get('Description', '')
        #         if description and 'ML_PND' in str(description).upper():
        #             row['_sheet_name'] = sheet_name  # Add sheet name to result
        #             row['_match_reason'] = f"Description contains ML_PND: {description}"
                    
        #             # Extract incident data from Self Service Variables
        #             self_service_vars = row.get('Self Service Variables', '')
        #             extracted_data = self.extract_incident_data(self_service_vars)
        #             row['_extracted_data'] = extracted_data  # Add extracted data to row
                    
        #             ml_pnd_orders.append(row)
        #             sheet_matches += 1
        #             # print(f"Found ML_PND order: {description}")
        #             # Further processing can be done here
            
        #     print(f"   📊 Found {sheet_matches} ML_PND orders in sheet '{sheet_name}'")
        
        # print(f"\n📋 FILTERING RESULTS:")
        # print(f"   Total rows processed: {total_processed}")
        # print(f"   ML_PND matches found: {len(ml_pnd_orders)}")
        # print(f"   Success rate: {(len(ml_pnd_orders)/total_processed*100):.1f}%" if total_processed > 0 else "   No data processed")
        
        # return ml_pnd_orders
    def process_orders(self, order_detail: Dict[str, Any], rule_engine: SimpleRuleEngine) -> None:
        print("order_detail in process_orders==>", order_detail)
        if order_detail is not None:
            message = rule_engine.process_order_request(order_detail['order_number'], order_detail['location_code'], "", "")
            return message
        else:
            message = rule_engine.process_order_request(None, None, "", "")
            return message
    def pricess_pending_orders(self):
        if not self.ml_pending_orders:
            print("❌ No ML_PND orders found")
            return {
                'order_details': [],
                'mtn_details': [],
                'account_numbers': []
            }
        
        # Initialize result dictionary
        final_results = {
            'order_details': [],
            'mtn_details': [],
            'account_numbers': []
        }
        
        for order in self.ml_pending_orders:
            extracted_data = order.get('_extracted_data', {})
            data_type = extracted_data.get('data_type', 'none')
            print("data_type==>33333",order)
            if data_type == 'order_details':
                order_detail = {
                    'order_number': extracted_data.get('order_number'),
                    'location_code': extracted_data.get('location_code'),
                    'incident_number': order.get('Incident Number', 'N/A'),
                    'sheet_source': order.get('_sheet_name', 'Unknown')
                }
                # final_results['order_details'].append(order_detail)
                order['rule_status'] = self.process_orders(order_detail,self.rule_engine)
                # rule_message = self.process_orders(order_detail,self.rule_engine)
                
                # print("@@@@@@@@@ ===>",self.process_orders(order_detail,self.rule_engine))
            elif data_type == 'account':
                order_detail = self.get_order_details(extracted_data.get('account_number'))
                final_results['order_details'].append(order_detail)
                # print("@@@@@@@@@ ===>",self.process_orders(order_detail,self.rule_engine))
                order['rule_status'] = self.process_orders(order_detail,self.rule_engine)
            print("orderorderorder ===>",order)
            self.rule_final_results.append(order)
        # for order in final_results.get('order_details', []):
        #     if order is not None:
        #         print("order_detail11 ==>", order)
        #         self.process_orders(order,self.rule_engine)
        # print("final_resultsfinal_results ==>",)
        # Print the results dictionary
        # print(f"\n📊 FINAL RESULTS DICTIONARY:")
        # print(f"=" * 50)
        # print(f"final_results = {json.dumps(final_results, indent=2)}")
        # print(f"\n� ML_PND ORDERS ANALYSIS")
        # print(f"=" * 50)
        # print(f"Total ML_PND Orders Found: {len(self.ml_pending_orders)}")
        # print("Processing each order for data extraction... ===>", )
        # print(f"\n📋 EXTRACTION RESULTS:")
        # print(f"   ✅ Order Details: {len(self.ml_pending_orders['order_details'])} records")
        # print(f"   📞 MTN Details: {len(self.ml_pending_orders['mtn_details'])} records")
        # print(f"   � Account Numbers: {len(self.ml_pending_orders['account_numbers'])} records")
        # print(f"   ❌ No Data: {len(self.ml_pending_orders) - len(self.ml_pending_orders['order_details']) - len(self.ml_pending_orders['mtn_details']) - len(self.ml_pending_orders)}")
        return self.rule_final_results
    def process_ays_orders(self, xls_data:Dict[str, Any]) -> None:
       
        description = xls_data.get('Description', '')
        
        if 'ML_PND' in description.upper():
            self_service_vars = xls_data.get('Self Service Variables', '')
            extracted_data = self.extract_incident_data(self_service_vars)
            xls_data['_extracted_data'] = extracted_data  # Add extracted data to row
            self.ml_pending_orders.append(xls_data)
            # print("extracted_data==>",extracted_data) 
    #                 ml_pnd_orders.append(row)
        #     for row in sheet_data['data']:
        #         description = row.get('Description', '')
        #         if description and 'ML_PND' in str(description).upper():
        #             print(f"Found ML_PND order: {description}")
                    # Further processing can be done here
    def read_pending_orders_excel(self, file_path: str ) -> Dict[str, Any]:
        """
        Read Pending Order.xlsx file and return structured data
        
        Args:
            file_path: Path to the Excel file (default: "Pending Order.xlsx")
            
        Returns:
            Dictionary containing the Excel data and metadata
        """
        try:
            print(f"📊 Reading Excel file: {file_path}")
            
            # Check if file exists
            if not os.path.exists(file_path):
                print(f"❌ File not found: {file_path}")
                return {
                    'success': False,
                    'error': f"File not found: {file_path}",
                    'data': None,
                    'row_count': 0
                }
            
            # Method 1: Using pandas (preferred method)
            try:
                # Read all sheets
                excel_data = pd.read_excel(file_path, sheet_name=None)
                
                result = {
                    'success': True,
                    'file_path': file_path,
                    'sheets': {},
                    'total_rows': 0,
                    'sheet_names': list(excel_data.keys())
                }
                
                # Process each sheet
                for sheet_name, df in excel_data.items():
                    print(f"📋 Processing sheet: {sheet_name}")
                    print(f"   Rows: {len(df)}, Columns: {len(df.columns)}")
                    
                    # Convert DataFrame to dictionary
                    sheet_data = {
                        'data': df.to_dict('records'),  # List of dictionaries
                        'columns': df.columns.tolist(),
                        'row_count': len(df),
                        'column_count': len(df.columns)
                    }
                    
                    result['sheets'][sheet_name] = sheet_data
                    result['total_rows'] += len(df)
                    
                    # Print first few column names
                    print(f"   Columns: {df.columns.tolist()[:5]}{'...' if len(df.columns) > 5 else ''}")
                
                print(f"✅ Successfully read {result['total_rows']} total rows from {len(result['sheets'])} sheets")
                return result
                
            except Exception as pandas_error:
                print(f"⚠️ Pandas method failed: {str(pandas_error)}")
                
                # Method 2: Using openpyxl as fallback
                try:
                    from openpyxl import load_workbook
                    
                    print("🔄 Trying openpyxl method...")
                    workbook = load_workbook(file_path, data_only=True)
                    
                    result = {
                        'success': True,
                        'file_path': file_path,
                        'sheets': {},
                        'total_rows': 0,
                        'sheet_names': workbook.sheetnames
                    }
                    
                    for sheet_name in workbook.sheetnames:
                        print(f"📋 Processing sheet: {sheet_name}")
                        worksheet = workbook[sheet_name]
                        
                        # Get all data from worksheet
                        data = []
                        headers = []
                        
                        # Get headers from first row
                        for cell in worksheet[1]:
                            headers.append(cell.value)
                        
                        # Get data rows
                        for row in worksheet.iter_rows(min_row=2, values_only=True):
                            if any(cell is not None for cell in row):  # Skip empty rows
                                row_dict = {}
                                for i, value in enumerate(row):
                                    if i < len(headers):
                                        row_dict[headers[i]] = value
                                data.append(row_dict)
                        
                        sheet_data = {
                            'data': data,
                            'columns': headers,
                            'row_count': len(data),
                            'column_count': len(headers)
                        }
                        
                        result['sheets'][sheet_name] = sheet_data
                        result['total_rows'] += len(data)
                        
                        print(f"   Rows: {len(data)}, Columns: {len(headers)}")
                    
                    print(f"✅ Successfully read {result['total_rows']} total rows using openpyxl")
                    return result
                    
                except Exception as openpyxl_error:
                    print(f"❌ Openpyxl method also failed: {str(openpyxl_error)}")
                    return {
                        'success': False,
                        'error': f"Both pandas and openpyxl failed. Pandas: {str(pandas_error)}, Openpyxl: {str(openpyxl_error)}",
                        'data': None,
                        'row_count': 0
                    }
            
        except Exception as e:
            print(f"❌ Error reading Excel file: {str(e)}")
            return {
                'success': False,
                'error': str(e),
                'data': None,
                'row_count': 0
            }
    
    def get_pending_orders_summary(self, file_path: str = "Pending Order.xlsx") -> None:
        """
        Print a summary of the Pending Orders Excel file
        """
        excel_data = self.read_pending_orders_excel(file_path)
        
        if not excel_data['success']:
            print(f"❌ Failed to read file: {excel_data['error']}")
            return
        
        print(f"\n📊 PENDING ORDERS SUMMARY")
        print(f"=" * 50)
        print(f"File: {excel_data['file_path']}")
        print(f"Total Sheets: {len(excel_data['sheets'])}")
        print(f"Total Rows: {excel_data['total_rows']}")
        print(f"Sheet Names: {', '.join(excel_data['sheet_names'])}")
        
        for sheet_name, sheet_data in excel_data['sheets'].items():
            print(f"\n📋 Sheet: {sheet_name}")
            print(f"   Rows: {sheet_data['row_count']}")
            print(f"   Columns: {sheet_data['column_count']}")
            print(f"   Column Names: {', '.join(sheet_data['columns'][:5])}{'...' if len(sheet_data['columns']) > 5 else ''}")
            
            # Show first row as sample
            if sheet_data['data'] and len(sheet_data['data']) > 0:
                print(f"   Sample Data (First Row):")
                first_row = sheet_data['data'][0]
                for key, value in list(first_row.items())[:3]:  # Show first 3 columns
                    print(f"      {key}: {value}")
                if len(first_row) > 3:
                    print(f"      ... and {len(first_row) - 3} more columns")

    def search_pending_orders(self, file_path: str = "Pending Order.xlsx", 
                            search_criteria: Dict[str, Any] = None) -> List[Dict[str, Any]]:
        """
        Search for specific orders in the Excel file
        
        Args:
            file_path: Path to Excel file
            search_criteria: Dictionary with column_name: value pairs to search for
            
        Returns:
            List of matching rows
        """
        excel_data = self.read_pending_orders_excel(file_path)
        
        if not excel_data['success']:
            print(f"❌ Failed to read file: {excel_data['error']}")
            return []
        
        if not search_criteria:
            print("ℹ️ No search criteria provided, returning all data")
            # Return all data from all sheets
            all_data = []
            for sheet_data in excel_data['sheets'].values():
                all_data.extend(sheet_data['data'])
            return all_data
        
        matching_rows = []
        
        for sheet_name, sheet_data in excel_data['sheets'].items():
            print(f"🔍 Searching in sheet: {sheet_name}")
            
            for row in sheet_data['data']:
                match = True
                for column, expected_value in search_criteria.items():
                    if column in row:
                        if str(row[column]).lower() != str(expected_value).lower():
                            match = False
                            break
                    else:
                        match = False
                        break
                
                if match:
                    row['_sheet_name'] = sheet_name  # Add sheet name to result
                    matching_rows.append(row)
        
        print(f"✅ Found {len(matching_rows)} matching rows")
        return matching_rows

    # def filter_ml_pnd_orders(self, file_path: str = "Pending Order.xlsx") -> List[Dict[str, Any]]:
    #     """
    #     Filter orders where Description column contains 'ML_PND'
        
    #     Args:
    #         file_path: Path to Excel file
            
    #     Returns:
    #         List of rows where Description contains 'ML_PND'
    #     """
    #     print(f"🔍 Filtering orders with Description containing 'ML_PND'...")
        
    #     excel_data = self.read_pending_orders_excel(file_path)
        
    #     if not excel_data['success']:
    #         print(f"❌ Failed to read file: {excel_data['error']}")
    #         return []
        
    #     ml_pnd_orders = []
    #     total_processed = 0
        
    #     for sheet_name, sheet_data in excel_data['sheets'].items():
    #         print(f"🔍 Searching in sheet: {sheet_name}")
    #         sheet_matches = 0
            
    #         for row in sheet_data['data']:
    #             total_processed += 1
                
    #             # Check if 'Description' column exists and contains 'ML_PND'
    #             description = row.get('Description', '')
    #             if description and 'ML_PND' in str(description).upper():
    #                 row['_sheet_name'] = sheet_name  # Add sheet name to result
    #                 row['_match_reason'] = f"Description contains ML_PND: {description}"
                    
    #                 # Extract incident data from Self Service Variables
    #                 self_service_vars = row.get('Self Service Variables', '')
    #                 extracted_data = self.extract_incident_data(self_service_vars)
    #                 row['_extracted_data'] = extracted_data  # Add extracted data to row
                    
    #                 ml_pnd_orders.append(row)
    #                 sheet_matches += 1
    #                 # print(f"   ✅ Match found: {description}")
    #                 # print(f"      📋 Extracted: {extracted_data['primary_data']}")
            
    #         print(f"   📊 Found {sheet_matches} ML_PND orders in sheet '{sheet_name}'")
        
    #     print(f"\n📋 FILTERING RESULTS:")
    #     print(f"   Total rows processed: {total_processed}")
    #     print(f"   ML_PND matches found: {len(ml_pnd_orders)}")
    #     print(f"   Success rate: {(len(ml_pnd_orders)/total_processed*100):.1f}%" if total_processed > 0 else "   No data processed")
        
    #     return ml_pnd_orders

    def extract_incident_data(self, self_service_variables: str) -> Dict[str, Any]:
        """
        Extract key incident data from Self Service Variables using waterfall priority logic
        
        Priority Order:
        1. Order Number + Location Code (both required)
        2. Telephone Number (if order details missing)
        3. Account Number (if above not available)
        4. No required data found
        
        Args:
            self_service_variables: String containing Q&A format data
            
        Returns:
            Dictionary with extracted data and metadata
        """
        if not self_service_variables:
            return {
                'data_type': 'none',
                'order_number': None,
                'location_code': None,
                'telephone': None,
                'account_number': None,
                'confidence': 0.0,
                'extraction_notes': 'No Self Service Variables provided'
            }
        
        # print(f"🔍 Extracting data from Self Service Variables...")
        
        # Initialize extracted values
        order_number = None
        location_code = None
        telephone = None
        account_number = None
        extraction_notes = []
        
        # Convert to string and prepare for parsing
        content = str(self_service_variables)
        
        # Step 1: Extract structured Q&A data using regex patterns
        try:
            # Order Number patterns - improved to extract clean numbers
            order_patterns = [
                r'Order Number[:\s]*(\d+)',  # Simple numeric order number
                r'order number[:\s]*(\d+)',
                r'What is.*order number.*?[:\?]\s*(\d+)',
                r'equipment order number.*?[:\?]\s*(\d+)',
                r'ORDER\s*:?\s*(\d+)',  # ORDER: 12345
                r'ORD\s*:?\s*(\d+)',    # ORD: 12345
                r'order\s*:?\s*(\d+)',   # order: 12345
                r'order\s+(\d{4,})'     # order followed by 4+ digits
            ]
            
            for pattern in order_patterns:
                match = re.search(pattern, content, re.IGNORECASE)
                if match and not order_number:
                    candidate = match.group(1).strip().upper()
                    # Exclude single "0" and very short numbers that are likely not order numbers
                    if candidate != "0" and len(candidate) >= 2:  # At least 2 digits
                        order_number = candidate
                        extraction_notes.append(f"Order number found: {order_number}")
                        break
            
            # Location Code patterns - improved to extract clean codes
            location_patterns = [
                r'location code[:\s]*([A-Z]\d{6})',  # Standard format like X473401
                r'LOC[:\s]*([A-Z]\d{6})',
                r'What is.*location code.*?[:\?]\s*([A-Z]\d{6})',
                r'loc code[:\s]*([A-Z]\d{6})',
                r'Loc Code[:\s]*([A-Z]\d{6})',
                r'LOCATION[:\s]*([A-Z]\d{6})'
            ]
            
            for pattern in location_patterns:
                match = re.search(pattern, content, re.IGNORECASE)
                if match and not location_code:
                    location_code = match.group(1).strip().upper()
                    extraction_notes.append(f"Location code found: {location_code}")
                    break
            
            # If standard patterns don't work, try broader location patterns
            if not location_code:
                broader_loc_patterns = [
                    r'location code[:\s]*([A-Za-z0-9]{7})',  # 7 chars alphanumeric
                    r'LOC[:\s]*([A-Za-z0-9]{7})',
                    r'loc code[:\s]*([A-Za-z0-9]{7})'
                ]
                
                for pattern in broader_loc_patterns:
                    match = re.search(pattern, content, re.IGNORECASE)
                    if match and not location_code:
                        location_code = match.group(1).strip().upper()
                        extraction_notes.append(f"Location code found (broad): {location_code}")
                        break
            
            # # Telephone patterns - improved to extract clean phone numbers
            # phone_patterns = [
            #     r'telephone number[:\s]*(\d{3}[-.\s]?\d{3}[-.\s]?\d{4})',
            #     r'mobile telephone number[:\s]*(\d{3}[-.\s]?\d{3}[-.\s]?\d{4})',
            #     r'phone number[:\s]*(\d{3}[-.\s]?\d{3}[-.\s]?\d{4})',
            #     r'What is.*mobile telephone number.*?[:\?]\s*(\d{3}[-.\s]?\d{3}[-.\s]?\d{4})',
            #     r'What is.*telephone number.*?[:\?]\s*(\d{3}[-.\s]?\d{3}[-.\s]?\d{4})',
            #     r'mobile[:\s]*(\d{3}[-.\s]?\d{3}[-.\s]?\d{4})'
            # ]
            
            # for pattern in phone_patterns:
            #     match = re.search(pattern, content, re.IGNORECASE)
            #     if match and not telephone:
            #         # Remove dashes, dots, and spaces from phone number
            #         telephone = re.sub(r'[-.\s]', '', match.group(1).strip())
            #         extraction_notes.append(f"Telephone found: {telephone}")
            #         break
            
            # Account Number patterns - improved to extract clean account numbers with dashes
            account_patterns = [
                r'account number[:\s]*(\d+-\d+)',  # Pattern like 0490310517-00001
                r'What is.*account number.*?[:\?]\s*(\d+-\d+)',
                r'customer.*account[:\s]*(\d+-\d+)',
                r'ACCOUNT[:\s]*(\d+-\d+)',
                r'account number[:\s]*(\d+)',  # Fallback for numbers without dashes
                r'What is.*account number.*?[:\?]\s*(\d+)',
                r'customer.*account[:\s]*(\d+)',
                r'ACCOUNT[:\s]*(\d+)'
            ]
            
            for pattern in account_patterns:
                match = re.search(pattern, content, re.IGNORECASE)
                if match and not account_number:
                    account_number = match.group(1).strip()
                    extraction_notes.append(f"Account number found: {account_number}")
                    break
            
            # Step 2: Try alternative extraction from unstructured text if Q&A format fails
            if not order_number:
                # Look for standalone order numbers in text
                alt_order_patterns = [
                    r'\b(\d{8})\b',  # 8-digit numbers
                    r'\b(\d{7})\b',  # 7-digit numbers
                    r'\b(\d{6})\b'   # 6-digit numbers (but exclude single digit 0)
                ]
                
                for pattern in alt_order_patterns:
                    matches = re.findall(pattern, content)
                    if matches and not order_number:
                        # Take the first reasonable number and convert to uppercase, but exclude "0"
                        candidate = matches[0].upper()
                        if candidate != "0":  # Exclude single "0" as it's not a valid order number
                            order_number = candidate
                            extraction_notes.append(f"Order number from text: {order_number}")
                            break
                        else:
                            # Debug: Log when we skip "0" as order number
                            extraction_notes.append("Skipped '0' as invalid order number")
            
            if not location_code:
                # Look for location code patterns in text
                alt_loc_patterns = [
                    r'\b([A-Z]\d{6})\b',  # Standard format like X473401
                    r'\b([A-Z]{1}\d{6})\b'
                ]
                
                for pattern in alt_loc_patterns:
                    matches = re.findall(pattern, content, re.IGNORECASE)
                    if matches and not location_code:
                        location_code = matches[0].upper()
                        extraction_notes.append(f"Location code from text: {location_code}")
                        break
            
        except Exception as e:
            extraction_notes.append(f"Regex extraction error: {str(e)}")
        
        # Step 3: Apply waterfall logic to determine data type and confidence
        if order_number and location_code:
            data_type = 'order_details'
            confidence = 0.95
            primary_data = f"Order: {order_number}, Location: {location_code}"
        # elif telephone:
        #     data_type = 'telephone'
        #     confidence = 0.80
        #     primary_data = f"Phone: {telephone}"
        elif account_number:
            data_type = 'account'
            confidence = 0.70
            primary_data = f"Account: {account_number}"
        else:
            data_type = 'none'
            confidence = 0.0
            primary_data = "No required data found"
            extraction_notes.append("No order, phone, or account data found")
        
        result = {
            'data_type': data_type,
            'order_number': order_number,
            'location_code': location_code,
            # 'telephone': telephone,
            'account_number': account_number,
            'confidence': confidence,
            'primary_data': primary_data,
            'extraction_notes': extraction_notes
        }
        
        # print(f"   ✅ Extracted: {primary_data} (confidence: {confidence:.1%})")
        return result

    def filter_description_contains(self, file_path: str = "Pending Order.xlsx", 
                                  search_text: str = "ML_PND", 
                                  case_sensitive: bool = False) -> List[Dict[str, Any]]:
        """
        Generic method to filter orders where Description column contains specific text
        
        Args:
            file_path: Path to Excel file
            search_text: Text to search for in Description column
            case_sensitive: Whether search should be case sensitive
            
        Returns:
            List of rows where Description contains the search text
        """
        print(f"🔍 Filtering orders with Description containing '{search_text}'...")
        
        excel_data = self.read_pending_orders_excel(file_path)
        
        if not excel_data['success']:
            print(f"❌ Failed to read file: {excel_data['error']}")
            return []
        
        matching_orders = []
        total_processed = 0
        
        for sheet_name, sheet_data in excel_data['sheets'].items():
            print(f"🔍 Searching in sheet: {sheet_name}")
            sheet_matches = 0
            
            for row in sheet_data['data']:
                total_processed += 1
                
                # Check if 'Description' column exists
                description = row.get('Description', '')
                if description:
                    # Convert to string and apply case sensitivity
                    desc_str = str(description)
                    search_str = search_text
                    
                    if not case_sensitive:
                        desc_str = desc_str.upper()
                        search_str = search_str.upper()
                    
                    if search_str in desc_str:
                        row['_sheet_name'] = sheet_name
                        row['_match_reason'] = f"Description contains '{search_text}': {description}"
                        matching_orders.append(row)
                        sheet_matches += 1
                        print(f"   ✅ Match found: {description}")
            
            print(f"   📊 Found {sheet_matches} matches in sheet '{sheet_name}'")
        
        print(f"\n📋 FILTERING RESULTS:")
        print(f"   Search text: '{search_text}' (Case sensitive: {case_sensitive})")
        print(f"   Total rows processed: {total_processed}")
        print(f"   Matches found: {len(matching_orders)}")
        print(f"   Success rate: {(len(matching_orders)/total_processed*100):.1f}%" if total_processed > 0 else "   No data processed")
        
        return matching_orders
    def get_order_details(self, account_number: str) -> None:
        """
        Placeholder method to get order details based on account number.
        
        Args:
            account_number: The account number to look up.
        """
        account_number = account_number.split('-')
        api_url = f"https://cxp-domain-b6vv-prod-proxy.vpc.verizon.com/b6vv/prod/orderRestrictions/eligiblityCheck?customerId={account_number[0]}&accountNumber={account_number[1]}&retrievalLevel=ACCOUNT_LEVEL"

        headers = {"Content-Type": "application/json","E2EREQUESTID":"skdfldkfjldk","x-apikey":"AIAodwK4gZJO0etJXdO2bgSAsJhDPRlK","CORRELATION_ID":"sdkfdsfd","CLIENT_ID":"VZW-NETACE"}
        response = requests.get(
            api_url,
            headers=headers,
            timeout=30,
            verify=False  # For internal APIs, adjust as needed
        )
        if response.status_code == 200:
            api_data = response.json()
            has_pending_order = self.find_attribute_in_json(api_data,'hasPendingOrder')
            if str(has_pending_order) == 'True':
                pending_order = self.find_attribute_in_json(api_data,'pendingOrderDetail')
                return {
                        'order_number': pending_order.get('pendingOrderNumber'),
                        'location_code': pending_order.get('netaceLocationCd',''),
                        'incident_number': '',
                        'sheet_source': ''
                        }
            else:
                {
                'order_number': '',
                'location_code': '',
                'incident_number': '',
                'sheet_source': ''
                }
        else:
            api_data = response.json()
            print("API DATA status is not 200 ==>",api_data)

    def find_attribute_in_json(self, json_data: Any, attribute_name: str, return_all: bool = False) -> Any:
        """
        Recursively search for an attribute in complex nested JSON data
        
        Args:
            json_data: The JSON data to search (dict, list, or any type)
            attribute_name: The attribute name to search for
            return_all: If True, returns all occurrences; if False, returns first occurrence
        
        Returns:
            - If return_all=False: First found value or None if not found
            - If return_all=True: List of all found values (empty list if none found)
        """
        try:
            print(f"🔍 Searching for attribute '{attribute_name}' in JSON data...")
            
            if return_all:
                results = []
                self._recursive_attribute_search(json_data, attribute_name, results, [])
                print(f"📊 Found {len(results)} occurrences of '{attribute_name}'")
                return results
            else:
                result = self._find_first_attribute(json_data, attribute_name, [])
                if result is not None:
                    print(f"✅ Found '{attribute_name}': {result['value']} at path: {' -> '.join(result['path'])}")
                    return result['value']
                else:
                    print(f"❌ Attribute '{attribute_name}' not found in JSON data")
                    return None
                    
        except Exception as e:
            print(f"❌ Error searching for attribute '{attribute_name}': {str(e)}")
            return None if not return_all else []
    def _recursive_attribute_search(self, data: Any, attribute_name: str, results: list, current_path: list) -> None:
        """Recursively collect all occurrences of attribute (internal helper)"""
        # Case 1: Data is a dictionary
        if isinstance(data, dict):
            # Check if the attribute exists at this level
            if attribute_name in data:
                results.append({
                    'value': data[attribute_name],
                    'path': current_path + [attribute_name],
                    'parent': data,
                    'full_path': ' -> '.join(current_path + [attribute_name])
                })
            
            # Continue searching deeper in dictionary values
            for key, value in data.items():
                self._recursive_attribute_search(value, attribute_name, results, current_path + [key])
        
        # Case 2: Data is a list
        elif isinstance(data, list):
            for index, item in enumerate(data):
                self._recursive_attribute_search(item, attribute_name, results, current_path + [f"[{index}]"])
        
        # Case 3: Data is primitive (string, int, etc.) - nothing to search
        return
    def _find_first_attribute(self, data: Any, attribute_name: str, current_path: list) -> dict:
        """Find first occurrence of attribute (internal helper)"""
        # Case 1: Data is a dictionary
        if isinstance(data, dict):
            # Check if the attribute exists at this level
            if attribute_name in data:
                return {
                    'value': data[attribute_name],
                    'path': current_path + [attribute_name],
                    'parent': data
                }
            
            # Search deeper in dictionary values
            for key, value in data.items():
                result = self._find_first_attribute(value, attribute_name, current_path + [key])
                if result is not None:
                    return result
        
        # Case 2: Data is a list
        elif isinstance(data, list):
            for index, item in enumerate(data):
                result = self._find_first_attribute(item, attribute_name, current_path + [f"[{index}]"])
                if result is not None:
                    return result
        
        # Case 3: Data is primitive (string, int, etc.) - nothing to search
        return None
    def get_ml_pnd_summary(self, file_path: str = "Pending Order.xlsx") -> Dict[str, List[Dict[str, Any]]]:
        """
        Get ML_PND orders and return results in structured dictionary format
        
        Returns:
            Dictionary with categorized extracted data:
            {
                'order_details': [{'order_number': 'xx', 'location_code': 'xxx'}, ...],
                'mtn_details': [{'mtn': 'xxxx'}, ...],
                'account_numbers': [{'account_number': 'xxxxx'}, ...]
            }
        """
        ml_pnd_orders = self.filter_ml_pnd_orders(file_path)
        
        if not ml_pnd_orders:
            print("❌ No ML_PND orders found")
            return {
                'order_details': [],
                'mtn_details': [],
                'account_numbers': []
            }
        
        # Initialize result dictionary
        final_results = {
            'order_details': [],
            'mtn_details': [],
            'account_numbers': []
        }
        
        print(f"\n� ML_PND ORDERS ANALYSIS")
        print(f"=" * 50)
        print(f"Total ML_PND Orders Found: {len(ml_pnd_orders)}")
        
        print(f"\n📋 EXTRACTION RESULTS:")
        print(f"   ✅ Order Details: {len(final_results['order_details'])} records")
        print(f"   📞 MTN Details: {len(final_results['mtn_details'])} records")
        print(f"   � Account Numbers: {len(final_results['account_numbers'])} records")
        print(f"   ❌ No Data: {len(ml_pnd_orders) - len(final_results['order_details']) - len(final_results['mtn_details']) - len(final_results['account_numbers'])} records")
        # Process each order and categorize extracted data
        for order in ml_pnd_orders:
            extracted_data = order.get('_extracted_data', {})
            data_type = extracted_data.get('data_type', 'none')
            
            if data_type == 'order_details':
                # Both order number and location code found
                # print("extracted_data ==>", extracted_data)
                order_detail = {
                    'order_number': extracted_data.get('order_number'),
                    'location_code': extracted_data.get('location_code'),
                    'incident_number': order.get('Incident Number', 'N/A'),
                    'sheet_source': order.get('_sheet_name', 'Unknown')
                }
                final_results['order_details'].append(order_detail)
                
            # elif data_type == 'telephone':
            #     # Telephone/MTN number found
            #     mtn_detail = {
            #         'mtn': extracted_data.get('telephone'),
            #         'incident_number': order.get('Incident Number', 'N/A'),
            #         'sheet_source': order.get('_sheet_name', 'Unknown')
            #     }
            #     final_results['mtn_details'].append(mtn_detail)
                
            elif data_type == 'account':
                order_detail = self.get_order_details(extracted_data.get('account_number'))
                final_results['order_details'].append(order_detail)
                # account_detail = {
                #     'account_number': extracted_data.get('account_number'),
                #     'incident_number': order.get('Incident Number', 'N/A'),
                #     'sheet_source': order.get('_sheet_name', 'Unknown')
                # }
                # final_results['account_numbers'].append(account_detail)
        
        # Print summary statistics
       
        
        # Print the results dictionary
        # print(f"\n📊 FINAL RESULTS DICTIONARY:")
        # print(f"=" * 50)
        # print(f"final_results = {json.dumps(final_results, indent=2)}")
        
        return final_results

# AYSAnalyser()

