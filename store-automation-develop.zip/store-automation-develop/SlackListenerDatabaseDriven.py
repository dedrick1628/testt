"""
Database-Driven Slack Bot for Order Processing
Preserves the working structure of SlackListener1.py while integrating the new rule engine
"""

import os
import re
import json
import datetime
import threading
import time
import urllib3
from slack_bolt import App
from slack_bolt.adapter.socket_mode import SocketModeHandler
from slack_sdk import WebClient

# Import our simple rule engine (more robust connection handling)
# from RuleEngine_V1 import SimpleRuleEngine

# from RuleEngine_V4 import SimpleRuleEngine

from RuleEngine import SimpleRuleEngine


# Disable SSL warnings for API calls
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# === SLACK CONFIGURATION ===
os.environ['SLACK_BOT_TOKEN'] = "xoxb-1111176898965-9630921002020-v7VN5wBnb7OA3LUqklYfxVNu"
os.environ['SLACK_APP_TOKEN'] = "xapp-1-A09JU2N2Z89-9633278793174-fcb6e5112c75c3bf24223f610b6315a78c292b71be0f2c04cdfc03a5ec8959a9"
SLACK_BOT_TOKEN = os.environ.get("SLACK_BOT_TOKEN")
SLACK_APP_TOKEN = os.environ.get("SLACK_APP_TOKEN")

# === PROXY CONFIGURATION ===
proxy_url = "http://proxy.ebiz.verizon.com:80"

# Set environment proxy for underlying libraries
os.environ['https_proxy'] = proxy_url
os.environ['HTTPS_PROXY'] = proxy_url
os.environ['http_proxy'] = proxy_url
os.environ['HTTP_PROXY'] = proxy_url

# Create WebClient with proxy configuration
web_client = WebClient(token=SLACK_BOT_TOKEN, proxy=proxy_url)

# Initialize Slack app
app = App(token=SLACK_BOT_TOKEN, client=web_client)


# auth_test = web_client.auth_test()
# print("auth_testauth_test ==>",auth_test)
# === DATABASE RULE ENGINE CONFIGURATION ===
DB_CONFIG = {
    'user': 'CXP_OPS_MONITORING',
    'password': 'QWEqwe##00',
    'dsn': 'tpalpbrhvd00-scan.verizon.com:1532/cxpopsmon_srv01'
}

# Initialize the simple rule engine (robust connection handling)
rule_engine = SimpleRuleEngine(DB_CONFIG)

# === CONNECTION MONITORING (PRESERVED FROM WORKING BOT) ===
last_message_time = datetime.datetime.now()

def update_last_message_time():
    global last_message_time
    last_message_time = datetime.datetime.now()

def enhanced_heartbeat():
    """Enhanced heartbeat with rule engine status"""
    try:
        current_time = datetime.datetime.now()
        time_since_last = current_time - last_message_time
        
        # Heartbeat check complete
    except Exception as e:
        pass  # Heartbeat error silently handled

def get_original_user_from_thread(channel_id, thread_ts):
    """
    Get the original user who triggered the workflow by looking at channel/thread history
    """
    try:
        if not thread_ts:
            return "Unknown User"
        
        # First try to get conversation replies (if it's a thread)
        try:
            result = web_client.conversations_replies(
                channel=channel_id,
                ts=thread_ts,
                limit=10
            )
            messages = result.get('messages', [])
            
            # Look for the first human user message (not bot)
            for message in messages:
                if not message.get('bot_id') and message.get('user'):
                    user_id = message.get('user')
                    return get_user_display_name(user_id)
                    
        except Exception as e:
            pass  # Thread lookup failed
        
        # If thread lookup fails, try recent channel history
        try:
            result = web_client.conversations_history(
                channel=channel_id,
                limit=20  # Look at recent messages
            )
            messages = result.get('messages', [])
            
            # Look for the most recent human user message
            for message in reversed(messages):  # Check most recent first
                if not message.get('bot_id') and message.get('user'):
                    user_id = message.get('user')
                    return get_user_display_name(user_id)
                    
        except Exception as e:
            pass  # Channel history lookup failed
        
        return "Unknown User"
        
    except Exception as e:
        pass  # Error getting original user
        return "Unknown User"

def get_user_display_name(user_id):
    """Get user display name from user ID"""
    try:
        user_info = web_client.users_info(user=user_id)
        user_data = user_info.get('user', {})
        
        # Try different name fields
        display_name = (user_data.get('real_name') or 
                       user_data.get('display_name') or 
                       user_data.get('name') or 
                       f"<@{user_id}>")
        
        return f"{display_name}"
        
    except Exception as e:
        pass  # Error getting user info
        # Return a more user-friendly fallback instead of the user ID format
        return "User"  # Simple fallback when permissions are missing

# === FORM DATA PARSING (ENHANCED WITH ORDER TYPE DETECTION) ===
def parse_workflow_form_submission(message_text, channel_id, say, thread_ts, user_id=None, user_name=None):
    """
    Parse workflow form submission and process with database rule engine
    """
    try:
        # Get original user from thread/conversation history
        original_user = get_original_user_from_thread(channel_id, thread_ts)
        
        # Initialize form data
        form_data = {
            'order_number': '',
            'location_code': '',
            'order_type': '',
            'comments': ''
        }
        response = f"""
            Dear User,
                Your form submission has been received and we will update the status soon. Thank you!
        """
                
        say(response, thread_ts=thread_ts)
        # Parse form data (preserved from working bot)
        lines = message_text.split('\n')
        
        for line in lines:
            line = line.strip()
            if not line or (line.startswith('*') and line.endswith('*') and len(line.replace('*', '').strip()) == 0):
                continue
            
            clean_line = line.replace('*', '').strip()
            
            # Extract order number
            if re.search(r'order\s*(number|id)', clean_line, re.IGNORECASE):
                next_line_idx = lines.index(line) + 1
                if next_line_idx < len(lines):
                    next_line = lines[next_line_idx].strip().replace('*', '')
                    if next_line and not re.search(r'(location|type|comment)', next_line, re.IGNORECASE):
                        form_data['order_number'] = next_line
            
            # Extract location code
            elif re.search(r'location\s*code', clean_line, re.IGNORECASE):
                next_line_idx = lines.index(line) + 1
                if next_line_idx < len(lines):
                    next_line = lines[next_line_idx].strip().replace('*', '')
                    if next_line and not re.search(r'(order|type|comment)', next_line, re.IGNORECASE):
                        form_data['location_code'] = next_line
            
            # Extract order type
            elif re.search(r'order\s*type', clean_line, re.IGNORECASE):
                next_line_idx = lines.index(line) + 1
                if next_line_idx < len(lines):
                    next_line = lines[next_line_idx].strip().replace('*', '')
                    if next_line and not re.search(r'(order|location|comment)', next_line, re.IGNORECASE):
                        form_data['order_type'] = next_line
        
        # Alternative regex patterns for better extraction
        text_clean = message_text.replace('*', '').strip()
        
        if not form_data['order_number']:
            order_match = re.search(r'order\s*(number|id)\s*\n\s*([A-Za-z0-9\-_]+)', text_clean, re.IGNORECASE)
            if order_match:
                form_data['order_number'] = order_match.group(2)
        
        if not form_data['location_code']:
            location_match = re.search(r'location\s*code\s*\n\s*([A-Za-z0-9\-_]+)', text_clean, re.IGNORECASE)
            if location_match:
                form_data['location_code'] = location_match.group(1)
        
        if not form_data['order_type']:
            type_match = re.search(r'order\s*type\s*\n\s*([A-Za-z0-9\-_\s]+)', text_clean, re.IGNORECASE)
            if type_match:
                form_data['order_type'] = type_match.group(1).strip()
        
        # PROCESS WITH DATABASE RULE ENGINE
        if form_data['order_number'] is not None and form_data['location_code'] is not None:
            
            try:
                # Use default order type if not specified
                order_type = form_data.get('order_type', 'GENERAL').strip().upper()
                if not order_type:
                    order_type = 'GENERAL'
                
                # Process with rule engine
                print(f"🚀 CALLING RULE ENGINE with:")
                print(f"   Order: {form_data['order_number']}")
                print(f"   Location: {form_data['location_code']}")
                print(f"   Type: {order_type}")
                print(f"   User: {original_user}")
                rule_engine = SimpleRuleEngine(DB_CONFIG)
                result = rule_engine.process_order_request(
                    order_number=form_data['order_number'],
                    location_code=form_data['location_code'],
                    order_type=order_type,
                    user_name=original_user  # Use actual user name from thread lookup
                )
                
                print(f"📨 RULE ENGINE RETURNED:")
                print(f"   Result Type: {type(result)}")
                print(f"   Result: {result}")
                
                # Send response based on rule engine result
                send_rule_engine_response(say, result, form_data, thread_ts)
                
            except Exception as rule_error:
                send_error_response(say, form_data, str(rule_error), thread_ts)
        elif form_data['order_number'] and form_data['location_code'] is None:
            try:
                # Use default order type if not specified
                order_type = form_data.get('order_type', 'GENERAL').strip().upper()
                if not order_type:
                    order_type = 'GENERAL'
                
                # Process with rule engine
                print(f"🚀 CALLING RULE ENGINE with:")
                print(f"   Order: {form_data['order_number']}")
                print(f"   Location: {form_data['location_code']}")
                print(f"   Type: {order_type}")
                print(f"   User: {original_user}")
                rule_engine = SimpleRuleEngine(DB_CONFIG)
                result = rule_engine.process_order_request(
                    order_number=form_data['order_number'],
                    location_code=form_data['location_code'],
                    order_type=order_type,
                    user_name=original_user  # Use actual user name from thread lookup
                )
                
                print(f"📨 RULE ENGINE RETURNED:")
                print(f"   Result Type: {type(result)}")
                print(f"   Result: {result}")
                
                # Send response based on rule engine result
                send_rule_engine_response(say, result, form_data, thread_ts)
                
            except Exception as rule_error:
                send_error_response(say, form_data, str(rule_error), thread_ts)
        else:
            send_missing_data_response(say, form_data, thread_ts)
            
    except Exception as e:
        send_error_response(say, {}, str(e), thread_ts)

def send_rule_engine_response(say, result, form_data, thread_ts):
    """Send response based on rule engine result"""
    try:
        status = result.get('status', 'UNKNOWN')
        message = result.get('message', 'No message provided')
        
        # Format response message
        if status == 'SUCCESS':
            response = f"""✅ **Order Processing Complete**

📋 **Order Details:**
• Order Number: `{form_data.get('order_number', 'N/A')}`
• Location Code: `{form_data.get('location_code', 'N/A')}`
• Order Type: `{form_data.get('order_type', 'GENERAL')}`

🎯 **Result:**
{message}

📅 Processed: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"""
        
        elif status == 'ERROR':
            response = f"""❌ **Order Processing Error**

📋 **Order Details:**
• Order Number: `{form_data.get('order_number', 'N/A')}`
• Location Code: `{form_data.get('location_code', 'N/A')}`
• Order Type: `{form_data.get('order_type', 'GENERAL')}`

⚠️ **Error:**
{message}

Please contact support if this issue persists."""
        
        else:
            response = f"""ℹ️ **Order Processing Status**

📋 **Order Details:**
• Order Number: `{form_data.get('order_number', 'N/A')}`
• Location Code: `{form_data.get('location_code', 'N/A')}`
• Order Type: `{form_data.get('order_type', 'GENERAL')}`

📊 **Status:** {status}
📝 **Message:** {message}"""
        
        print(f"📤 SENDING RESPONSE TO SLACK:")
        print(f"   Status: {status}")
        print(f"   Message: {message}")
        print(f"   Thread TS: {thread_ts}")
        print(f"   Response Length: {len(response)} characters")
        
        say(response, thread_ts=thread_ts)
        print("✅ RESPONSE SENT SUCCESSFULLY!")
        
    except Exception as e:
        print(f"❌ ERROR SENDING RULE ENGINE RESPONSE: {e}")
        import traceback
        traceback.print_exc()

def send_error_response(say, form_data, error_message, thread_ts):
    """Send error response"""
    try:
        response = f"""❌ **Processing Error**

📋 **Order Details:**
• Order Number: `{form_data.get('order_number', 'N/A')}`
• Location Code: `{form_data.get('location_code', 'N/A')}`

🚨 **Error:**
{error_message}

Please try again or contact support."""
        
        say(response, thread_ts=thread_ts)
        
    except Exception as e:
        pass  # Error sending error response

def send_missing_data_response(say, form_data, thread_ts):
    """Send response when required data is missing"""
    try:
        response = f"""⚠️ **Missing Required Information**

📋 **Received Data:**
• Order Number: `{form_data.get('order_number') or 'MISSING'}`
• Location Code: `{form_data.get('location_code') or 'MISSING'}`

❗ **Required:** Both Order Number and Location Code are required for processing.

Please submit the form again with complete information."""
        
        say(response, thread_ts=thread_ts)
        
    except Exception as e:
        pass  # Error sending missing data response

# === SLACK MESSAGE HANDLERS (PRESERVED FROM WORKING BOT) ===
@app.message("")
def handle_message(message, say):
    """Handle all messages - enhanced to process direct order messages"""
    try:
        
        update_last_message_time()
        # Skip bot messages except workflow forms
        if message.get('bot_id') or message.get('subtype') == 'bot_message':
            # Check if this is a workflow form we should process
            if message.get('bot_id') and ('order' in message['text'].lower() and 'location' in message['text'].lower()):
                parse_workflow_form_submission(
                    message['text'], 
                    message['channel'], 
                    say, 
                    message.get('ts'),
                    user_id=message.get('user', 'Bot/Workflow'),
                    user_name=None  # Will be fetched if needed
                )
                return
            else:
                return
        
        # Skip messages without text
        if 'text' not in message or not message['text'].strip():
            return
        
        channel_id = message['channel']
        message_text = message['text']
        user_id = message.get('user', 'Bot/Workflow')
        thread_ts = message.get('ts')

        print(f"🔍 RECEIVED MESSAGE: {message_text}")
        
        # Try to extract order information from the message
        order_info = extract_order_location(message_text)
        
        if order_info and order_info['order_number'] and order_info['location_code']:
            print(f"🚀 CALLING RULE ENGINE with:")
            print(f"   Order: {order_info['order_number']}")
            print(f"   Location: {order_info['location_code']}")
            print(f"   Type: {order_info['order_type']}")
            print(f"   User: {get_user_display_name(user_id)}")
            
            try:
                # Process with rule engine
                rule_engine = SimpleRuleEngine(DB_CONFIG)
                result = rule_engine.process_order_request(
                    order_number=order_info['order_number'],
                    location_code=order_info['location_code'],
                    order_type=order_info['order_type'],
                    user_name=get_user_display_name(user_id)
                )
                
                print(f"📨 RULE ENGINE RETURNED:")
                print(f"   Result Type: {type(result)}")
                print(f"   Result: {result}")
                
                # Send response to Slack
                status = result.get('status', 'UNKNOWN')
                response_message = result.get('message', 'Processing complete')
                
                print(f"📤 SENDING RESPONSE TO SLACK:")
                print(f"   Status: {status}")
                print(f"   Message: {response_message}")
                print(f"   Thread TS: {thread_ts}")
                print(f"   Response Length: {len(response_message)} characters")
                
                # Send formatted response
                if status == 'SUCCESS':
                    response = f"""✅ **Order Processed Successfully**

📋 **Order Details:**
• Order Number: `{order_info['order_number']}`
• Location Code: `{order_info['location_code']}`
• Order Type: `{order_info['order_type']}`

🎯 **Result:**
{response_message}

_Processed at {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}_"""
                else:
                    response = f"""⚠️ **Order Processing Status: {status}**

📋 **Order Details:**
• Order Number: `{order_info['order_number']}`
• Location Code: `{order_info['location_code']}`

📝 **Details:**
{response_message}

_Processed at {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}_"""
                
                say(text=response, thread_ts=thread_ts)
                print(f"✅ RESPONSE SENT SUCCESSFULLY!")
                
            except Exception as e:
                error_msg = f"❌ Error processing order: {str(e)}"
                print(error_msg)
                say(text=error_msg, thread_ts=thread_ts)
        else:
            # Not an order message - provide helpful guidance
            say(
                text="👋 Hi! I can help you process orders. Send me a message like:\n`Order 932293, Location T326801`",
                thread_ts=thread_ts
            )
        
    except Exception as e:
        try:
            say(f"❌ Error processing message: {str(e)}", thread_ts=thread_ts)
        except:
            pass  # Failed to send error message


def extract_order_location(text):
    """Extract order number and location from text message"""
    try:
        print(f"🔍 EXTRACTING ORDER INFO FROM: {text}")
        
        order_number = None
        location_code = None
        
        # Pattern 1: "Order 123456, Location ABC123"
        pattern1 = r'order\s+(\w+).*?location\s+(\w+)'
        match1 = re.search(pattern1, text, re.IGNORECASE)
        if match1:
            order_number = match1.group(1)
            location_code = match1.group(2)
            print(f"   ✅ Pattern 1 matched: Order={order_number}, Location={location_code}")
        
        # Pattern 2: "123456 ABC123" (just numbers and codes)
        if not order_number:
            pattern2 = r'(\d{5,})\s+([A-Z]\d{5,}|[A-Z]{1,3}\d{3,})'
            match2 = re.search(pattern2, text, re.IGNORECASE)
            if match2:
                order_number = match2.group(1)
                location_code = match2.group(2).upper()
                print(f"   ✅ Pattern 2 matched: Order={order_number}, Location={location_code}")
        
        # Pattern 3: Look for numbers and alphanumeric codes separately
        if not order_number:
            # Find order number (6+ digits)
            order_match = re.search(r'\b(\d{6,})\b', text)
            if order_match:
                order_number = order_match.group(1)
                print(f"   🔢 Found order number: {order_number}")
            
            # Find location code (letter followed by digits, or just alphanumeric)
            location_match = re.search(r'\b([A-Z]\d{5,}|[A-Z]{1,3}\d{3,}|T\d{6})\b', text, re.IGNORECASE)
            if location_match:
                location_code = location_match.group(1).upper()
                print(f"   📍 Found location code: {location_code}")
        
        # Determine order type
        order_type = "PENDING ORDERS"  # Default type
        if any(word in text.lower() for word in ['cancel', 'cancellation']):
            order_type = "CANCEL ORDERS"
        elif any(word in text.lower() for word in ['pending', 'pending orders']):
            order_type = "PENDING ORDERS"
        
        result = {
            'order_number': order_number,
            'location_code': location_code,
            'order_type': order_type
        }
        
        print(f"🎯 FINAL EXTRACTION RESULT: {result}")
        return result
        
    except Exception as e:
        print(f"❌ Error extracting order info: {str(e)}")
        return {'order_number': None, 'location_code': None, 'order_type': 'PENDING ORDERS'}

# === EVENT HANDLERS (PRESERVED FROM WORKING BOT) ===
@app.event("message")
def handle_message_events(event, say):
    """Handle all message events for debugging"""
    try:
        pass  # Event handling without debug output
    except Exception as e:
        pass  # Error in debug event handler

@app.event("hello")
def handle_hello(event, logger):
    pass  # WebSocket connection established

@app.event("disconnect")
def handle_disconnect(event, logger):
    pass  # WebSocket disconnected

@app.event("app_mention")
def handle_app_mentions(event, say):
    """Handle app mentions"""
    try:
        # Bot mentioned in channel
        pass
    except Exception as e:
        pass  # Error in app mention handler

# === FORM HANDLERS (PRESERVED FROM WORKING BOT) ===
@app.command("/submit-form")
def handle_submit_form_command(ack, body, client):
    """Handle /submit-form slash command"""
    try:
        ack()
        
        print("📝 SLASH COMMAND RECEIVED: /submit-form")
        print(f"User: {body.get('user_name', 'Unknown')} ({body.get('user_id', 'Unknown')})")
        
        # Open the same modal form from working bot
        client.views_open(
            trigger_id=body["trigger_id"],
            view={
                "type": "modal",
                "callback_id": "order_form_modal",
                "title": {
                    "type": "plain_text",
                    "text": "Order Information Form"
                },
                "submit": {
                    "type": "plain_text",
                    "text": "Submit"
                },
                "close": {
                    "type": "plain_text",
                    "text": "Cancel"
                },
                "blocks": [
                    {
                        "type": "header",
                        "text": {
                            "type": "plain_text",
                            "text": "📋 Order Information"
                        }
                    },
                    {
                        "type": "input",
                        "block_id": "order_number_block",
                        "element": {
                            "type": "plain_text_input",
                            "action_id": "order_number_input",
                            "placeholder": {
                                "type": "plain_text",
                                "text": "Enter order number (e.g., 7242009)"
                            }
                        },
                        "label": {
                            "type": "plain_text",
                            "text": "Order Number"
                        }
                    },
                    {
                        "type": "input",
                        "block_id": "location_code_block",
                        "element": {
                            "type": "plain_text_input",
                            "action_id": "location_code_input",
                            "placeholder": {
                                "type": "plain_text",
                                "text": "Enter location code (e.g., N833201)"
                            }
                        },
                        "label": {
                            "type": "plain_text",
                            "text": "Location Code"
                        }
                    },
                    {
                        "type": "input",
                        "block_id": "order_type_block",
                        "element": {
                            "type": "static_select",
                            "action_id": "order_type_select",
                            "placeholder": {
                                "type": "plain_text",
                                "text": "Select order type"
                            },
                            "options": [
                                {
                                    "text": {"type": "plain_text", "text": "Pending Orders - Process pending orders"},
                                    "value": "Pending Orders"
                                },
                                {
                                    "text": {"type": "plain_text", "text": "AAL - Add a Line"},
                                    "value": "AAL"
                                },
                                {
                                    "text": {"type": "plain_text", "text": "CANCELLATION - Order Cancellation"},
                                    "value": "CANCELLATION"
                                },
                                {
                                    "text": {"type": "plain_text", "text": "GENERAL - General Order"},
                                    "value": "GENERAL"
                                }
                            ]
                        },
                        "label": {
                            "type": "plain_text",
                            "text": "Order Type"
                        }
                    },
                    {
                        "type": "input",
                        "block_id": "description_block",
                        "element": {
                            "type": "plain_text_input",
                            "action_id": "description_input",
                            "multiline": True,
                            "placeholder": {
                                "type": "plain_text",
                                "text": "Enter any additional details..."
                            }
                        },
                        "label": {
                            "type": "plain_text",
                            "text": "Description/Notes"
                        },
                        "optional": True
                    }
                ]
            }
        )
        
        print("✅ MODAL FORM OPENED SUCCESSFULLY!")
        
    except Exception as e:
        print(f"❌ ERROR OPENING FORM MODAL: {e}")
        import traceback
        traceback.print_exc()

@app.view("order_form_modal")
def handle_form_submission(ack, body, client, view):
    """Handle form submission with database rule processing"""
    try:
        ack()
        rule_engine = SimpleRuleEngine(DB_CONFIG)
        print("📝 FORM SUBMISSION RECEIVED!")
        print(f"Body: {json.dumps(body, indent=2)}")
        
        # Extract form data
        values = view["state"]["values"]
        
        order_number = values["order_number_block"]["order_number_input"]["value"]
        location_code = values["location_code_block"]["location_code_input"]["value"]
        order_type_data = values["order_type_block"]["order_type_select"]["selected_option"]
        order_type = order_type_data["value"] if order_type_data else "GENERAL"
        description = values["description_block"]["description_input"]["value"] or ""
        
        user_id = body["user"]["id"]
        user_name = body["user"]["name"]
        
        print(f"📋 EXTRACTED FORM DATA:")
        print(f"   Order Number: {order_number}")
        print(f"   Location Code: {location_code}")
        print(f"   Order Type: {order_type}")
        print(f"   User: {user_name} ({user_id})")
        
        # Process with database rule engine
        if order_number and location_code:
            
            try:
                print("🚀 PROCESSING WITH RULE ENGINE...")
                result = rule_engine.process_order_request(
                    order_number=order_number,
                    location_code=location_code,
                    order_type=order_type,
                    user_name=user_name
                )
                
                print(f"✅ RULE ENGINE RESULT: {result}")
                
                # Send confirmation to user
                status = result.get('status', 'UNKNOWN')
                message = result.get('message', 'Processing complete')
                
                if status == 'SUCCESS':
                    confirmation = f"""✅ **Order Processed Successfully**

📋 **Order Details:**
• Order Number: `{order_number}`
• Location Code: `{location_code}`
• Order Type: `{order_type}`
• Submitted by: <@{user_id}>

🎯 **Result:**
{message}

📅 Processed: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"""
                else:
                    confirmation = f"""⚠️ **Order Processing Result**

📋 **Order Details:**
• Order Number: `{order_number}`
• Location Code: `{location_code}`
• Order Type: `{order_type}`
• Submitted by: <@{user_id}>

📊 **Status:** {status}
📝 **Message:** {message}"""
                
                # Send to user via DM
                try:
                    print(f"📤 SENDING CONFIRMATION TO USER {user_id}...")
                    client.chat_postMessage(
                        channel=user_id,
                        text=confirmation
                    )
                    print("✅ CONFIRMATION SENT SUCCESSFULLY!")
                except Exception as dm_error:
                    print(f"❌ COULD NOT SEND DM: {dm_error}")
                    
            except Exception as rule_error:
                print(f"❌ RULE ENGINE ERROR: {rule_error}")
                error_message = f"""❌ **Processing Error**

📋 **Order Details:**
• Order Number: `{order_number}`
• Location Code: `{location_code}`
• Order Type: `{order_type}`

🚨 **Error:** {str(rule_error)}

Please try again or contact support."""
                
                try:
                    client.chat_postMessage(
                        channel=user_id,
                        text=error_message
                    )
                except:
                    pass  # Could not send error DM
        else:
            print(f"❌ MISSING REQUIRED DATA - Order: {order_number}, Location: {location_code}")
        
    except Exception as e:
        print(f"❌ FORM PROCESSING ERROR: {e}")
        import traceback
        traceback.print_exc()

@app.message("form")
def handle_form_request(message, say):
    """Handle 'form' message to show form button"""
    try:
        say(
            blocks=[
                {
                    "type": "section",
                    "text": {
                        "type": "mrkdwn",
                        "text": "📋 *Ready to submit order information?*\nDatabase-driven processing available!"
                    },
                    "accessory": {
                        "type": "button",
                        "text": {
                            "type": "plain_text",
                            "text": "Open Form 📝"
                        },
                        "action_id": "open_form_button"
                    }
                }
            ]
        )
    except Exception as e:
        pass  # Error showing form button

@app.action("open_form_button")
def handle_open_form_button(ack, body, client):
    """Handle button click to open form"""
    try:
        ack()
        # Trigger the same form as slash command
        handle_submit_form_command(lambda: None, body, client)
    except Exception as e:
        pass  # Error opening form via button

# === MAIN EXECUTION ===
def start_bot_with_retry():
    """Start bot with retry capability"""
    max_retries = 5
    retry_count = 0
    
    while retry_count < max_retries:
        try:
            # Test database connection - REMOVE THIS FOR PRODUCTION
            # try:
            #     print("🧪 TESTING: Running test workflow...")
            #     test_result = rule_engine.process_order_request("7242009", "N833201", "Pending Orders", "System")
            #     print(f"✅ TEST COMPLETE: {test_result.get('status', 'UNKNOWN')}")
            #     print("🎯 Test shows rule engine is working correctly!")
            #     print("=" * 60)
            # except Exception as db_error:
            #     print(f"❌ Database connection error: {db_error}")
            
            # Start the bot
            handler = SocketModeHandler(app, SLACK_APP_TOKEN)
            handler.start()
            
        except KeyboardInterrupt:
            break
        except Exception as e:
            retry_count += 1
            
            if retry_count < max_retries:
                wait_time = min(2 ** retry_count, 30)
                time.sleep(wait_time)
            else:
                break

def heartbeat_loop():
    """Background heartbeat loop"""
    while True:
        time.sleep(60)
        enhanced_heartbeat()

if __name__ == "__main__":
    # Start heartbeat in background
    heartbeat_thread = threading.Thread(target=heartbeat_loop, daemon=True)
    heartbeat_thread.start()
    
    # Start bot
    start_bot_with_retry()
