from neomodel import config, db
from datetime import datetime
from typing import ClassVar, Optional, List
import json
import OasSpec
from utils.authentication import hasAccess
import re

from pydantic import BaseModel, Field, JsonValue, StrictInt, Extra, ConfigDict, StringConstraints, constr
from typing import List, Dict, Annotated, Any
from datetime import date
import uuid
import os
from dotenv import load_dotenv
# Imporatant imports to get the properties used to generate the Task Class
from neomodel import (config, StructuredNode, StringProperty, IntegerProperty, UniqueIdProperty, RelationshipTo, StructuredRel, UniqueIdProperty, DateTimeFormatProperty, JSONProperty, ArrayProperty, BooleanProperty)
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from fastapi import Request
from starlette.status import HTTP_400_BAD_REQUEST

from fastapi import FastAPI, Depends, HTTPException
from fastapi import FastAPI, HTTPException, Body, Query, Path
import routers.allworkflows as allworkflows
import routers.allworkflowsnexttask as allworkflowsnexttask
import routers.nexttask as nexttask
import routers.alltasks as alltasks
import routers.numversion as numversion
import routers.gettask as gettask
import routers.starttask as starttask
import routers.completetask as completetask
import routers.updatedata as updatedata
import routers.metadata as metadata
import routers.restart as restart
import routers.workflowtags as workflowtags
import routers.newworkflow as newworkflow

from fastapi import FastAPI, Depends, HTTPException, APIRouter, FastAPI, HTTPException, Body, Query, Path

import json

load_dotenv()

app = OasSpec.app

# this is used to load the custom openapi json to fit the FirstAPI guidelines

print("test")

app.include_router(allworkflows.router)
app.include_router(allworkflowsnexttask.router)
app.include_router(nexttask.router)
app.include_router(alltasks.router)
app.include_router(numversion.router)
app.include_router(gettask.router)
app.include_router(starttask.router)
app.include_router(completetask.router)
app.include_router(updatedata.router)
app.include_router(metadata.router)
app.include_router(restart.router)
app.include_router(workflowtags.router)
app.include_router(newworkflow.router)

@app.on_event("startup")
async def startup_event():

   config.DATABASE_URL  = os.getenv('config.DATABASE_URL')
   db.set_connection(url=os.getenv('url'))
#    results, meta = run_cypher_query("RETURN 'Helloo World!' as message")

@app.exception_handler(RequestValidationError)
async def validation_exception_handler(request: Request, exc: RequestValidationError):
    return JSONResponse(
        status_code=HTTP_400_BAD_REQUEST,
        content={"detail":exc.errors()})











# Method to get all Tasks for a specific Workflow


# Method to get the number of versions for a specific workflow



# Method to get the the Task of a certain Workflow




# Method to start a task in a workflow
  
# Method to complete a task in a workflow
# Method to add data or notes to a task in a workflow  




# Method to add data or notes to a task in a workflow  



# Method to add data or notes to a task in a workflow  

  
# Method to restart the Task 


