import jwt
from typing import Optional
import json
from . import authenv
from fastapi import Request
from fastapi.security import HTTPBearer, OAuth2

from fastapi import Depends, HTTPException
from fastapi.security import HTTPBearer
from urllib.request import urlopen
from fastapi import Request
from fastapi import Request
from urllib.request import urlopen
import json
from starlette.status import HTTP_401_UNAUTHORIZED
from fastapi.openapi.models import OAuthFlows as OAuthFlowsModel




# Authentication jwks
public_keys = {}
keys = urlopen(authenv.outputenv.keys_json ).read().decode('utf-8')
keySet=json.loads(keys)
publicKeyFormat = jwt.algorithms.RSAAlgorithm.from_jwk(next((item for item in keySet["keys"] if item['kid'] is not None), None))
print(publicKeyFormat)




#  Code below is for authentication

class Oauth2ClientCredentials(OAuth2):
    def __init__(
        self,
        tokenUrl: str,
        scheme_name: str = None,
        scopes: dict = None,
        auto_error: bool = True,
    ):
        if not scopes:
            scopes = {}
        flows = OAuthFlowsModel(clientCredentials={"tokenUrl": tokenUrl, "scopes": scopes})
        super().__init__(flows=flows, scheme_name=scheme_name, auto_error=auto_error)

    async def __call__(self, request: Request) -> Optional[str]:
        authorization: str = request.headers.get("x-apif-auth")
        # print(authorization)
        # endpoint_url2 = Request.url
        # audience = str(endpoint_url2).rsplit("/",1)[-1]
        # print(audience)
        if not authorization:
            if self.auto_error:
                raise HTTPException(
                    status_code=HTTP_401_UNAUTHORIZED,
                    detail="Not authenticated",
                    headers={"WWW-Authenticate": "Bearer"},
                )
            else:
                return authorization
        return authorization 
security = HTTPBearer()
oauth2_scheme = Oauth2ClientCredentials(tokenUrl=authenv.outputenv.tokenUrl, scopes={})
#  authentication function that will authenticate user using the FirstAPI token before authorizing them to preform a method
async def hasAccess(request: Request,authorization: str = Depends(oauth2_scheme)):
    endpoint_url = str(request.url)
    # audience_end = "/bpms/v1/"+endpoint_url.split("/",3)[3]
    audience_slug_version = "/"+authenv.outputenv.slug + "/" + authenv.outputenv.version +"/"
    audience_end = audience_slug_version+endpoint_url.split("/",3)[3]
    audience_end = audience_end.split("?")[0]
    print(audience_end)
    publicKeyFormat = jwt.algorithms.RSAAlgorithm.from_jwk(next((item for item in keySet["keys"] if item['kid'] is not None), None))
    try: 
        data = jwt.decode(
            authorization,
            publicKeyFormat,

            algorithms=["RS256"],
            audience=audience_end,
            issuer=authenv.outputenv.issuer,
            options={"verify_exp": True}
        )
    except: 
        
        return False
    return data['teamId'], data['sub']


