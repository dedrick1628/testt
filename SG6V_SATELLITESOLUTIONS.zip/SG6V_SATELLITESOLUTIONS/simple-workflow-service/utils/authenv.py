import os

class depEnv():
     def __init__(
        self,
        tokenUrl: str,
        keys_json: str ,
        issuer: str ,
        server: str,
        slug: str,
        version: str
    ):
          self.tokenUrl= tokenUrl
          self.keys_json = keys_json
          self.issuer = issuer
          self.sever =server
          self.slug =slug
          self.version =version


dev = depEnv("https://dev.apigw.verizon.com/oauth2/v2/token","https://dev.apigw.verizon.com/platform-jwks/v1/jwks.json","https://aws-us-east-2.dev.int.apigw.verizon.com","https://satellite-dev.vzbi.com/bpms",os.getenv('slug'),os.getenv('version'))
qa = depEnv("https://qa.apigw.verizon.com/oauth2/v2/token","https://qa.apigw.verizon.com/platform-jwks/v1/jwks.json","https://aws-us-east-2.qa.int.apigw.verizon.com","https://satellite-uat.verizon.com/bpms",os.getenv('slug'),os.getenv('version'))
prod = depEnv("https://int.apigw.verizon.com/oauth2/v2/token","https://int.apigw.verizon.com/platform-jwks/v1/jwks.json","https://aws-us-east-2.int.apigw.verizon.com","https://satellite.verizon.com/bpms",os.getenv('slug'),os.getenv('version'))      
preprod = depEnv("https://preprod.apigw.verizon.com/oauth2/v2/token","https://preprod.apigw.verizon.com/platform-jwks/v1/jwks.json","https://aws-us-east-2.preprod.int.apigw.verizon.com","satellite-prepord.vzbi.com/bpms",os.getenv('slug'),os.getenv('version')) 


outputenv = depEnv
deployment_target = os.getenv('deployment_target')
match deployment_target:
        case "prod":
            outputenv=prod
        case "dev":
            outputenv= dev
        case "qa":
            outputenv=qa
        case "preprod":
            outputenv=preprod
