from neomodel import config, db
from datetime import datetime
from typing import ClassVar, Optional, List
import json

from copy import deepcopy
import re

from pydantic import BaseModel, Field, JsonValue, StrictInt, Extra, ConfigDict, StringConstraints, constr
from typing import List, Dict, Annotated, Any
from datetime import date
import uuid
import os
from dotenv import load_dotenv
# Imporatant imports to get the properties used to generate the Task Class
from neomodel import (config, StructuredNode, StringProperty, IntegerProperty, UniqueIdProperty, RelationshipTo, StructuredRel, UniqueIdProperty, DateTimeFormatProperty, JSONProperty, ArrayProperty, BooleanProperty)
from fastapi.openapi.utils import get_openapi
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from fastapi import Request
from starlette.status import HTTP_400_BAD_REQUEST
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials, OAuth2AuthorizationCodeBearer ,OAuth2PasswordBearer, OAuth2

from fastapi import FastAPI, Depends, HTTPException
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
# from jose import jws, jwt, ExpiredSignatureError, JWTError, JWSError
# from jose.exceptions import JWTClaimsError
load_dotenv()
from jwt import PyJWKClient
import jwt
from urllib.request import urlopen
from starlette import status

import json

# Authentication jwks
public_keys = {}
keys = urlopen("https://dev.apigw.verizon.com/platform-jwks/v1/jwks.json").read().decode('utf-8')
keySet=json.loads(keys)
publicKeyFormat = jwt.algorithms.RSAAlgorithm.from_jwk(next((item for item in keySet["keys"] if item['kid'] is not None), None))
print(publicKeyFormat)



# these are the tags visible to the User seeing the API docs
tags_metadata = [
    {
        "name": "all-workflows",
        "description": "Operation to get all the Workflows for a Team. ",
    },
    {
        "name": "all-workflows/next-task",
        "description": "Operation to get all the Workflows Next Task(s) for a Team. ",
    },
    {
        "name": "all-tasks",
        "description": "Operation to get all the Tasks for a specific workflow (latest version). Input:  **Workflow ID**  ",
    },
   
    {
        "name": "num-version",
        "description": "Operation to get the number of versions for a specific workflow. Input:  **Workflow ID** ",
    },
    {
        "name": "task",
        "description": "Operation to get all the info of a specific task in a workflow (latest version). Input:  **Workflow ID**,**Task ID**  ",
    },
  
    {
        "name": "start-task",
        "description": "Operation to **Start** a task in a workflow (latest version). Input:  **Workflow ID**,**Task ID** Note: If Task is already started, operation will return first time task was started, and start date will not be updated! ",
    },
    {
        "name": "complete-task",
        "description": "Operation to **Complete** a task in a workflow (latest version). Input:  **Workflow ID**,**Task ID**  ",
    },
 
    {
        "name": "next-task",
        "description": "Operation to **Retrieve** the next task to do in a workflow (latest version). Input:  **Workflow ID**  ",
    },
    
    {
        "name": "restart-task",
        "description": "Operation to **Redo a task** in a workflow sets completed date to null and creates a new workflow version with that after . Input:  **Workflow ID**,**Task ID** NOTE: Even if input Task is not started/completed, a new version will be created! ",
    },
    
    {
        "name": "new-workflow",
        "description": "Operation to **Create a workflow**. Input: **Json Body**  ",
    },
]



# helper function to run query commands and raise errors as needed if DB connection isn't valid
def run_cypher_query(query, parameters = None):
   if  parameters is not None:
     try:
         results,meta = db.cypher_query(query, parameters)
         return results, meta
     except:
         raise HTTPException(status_code=503, detail="Database is down. We're working on bringing it back up")

   else:
     try:
         results,meta = db.cypher_query(query)
         return results, meta
     except:
         raise HTTPException(status_code=503, detail="Database is down. We're working on bringing it back up")


# function to get total nodecount from the DB, used later to generate UUID for WorkflowID

def getNodeCount():
    query= 'Match (n) Return count(n) AS node_count'
    results,meta = run_cypher_query(query)
    num_nodes = results[0][0]
    return num_nodes


# function to generate UUID for WorkflowID

def generateUUID(num_nodes):
    UUID = str(uuid.uuid4().hex)
    node_count = str(num_nodes)
    # Calculate the maximum allowed length for UUID
    max_long_length = 32 - len(node_count)
    
    # Truncate UUID if necessary
    if len(UUID) > max_long_length:
        UUID = UUID[:max_long_length]
    
    # Concatenate the strings
    result = UUID + node_count
    return result


import base64
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.backends import default_backend


from fastapi.openapi.models import OAuthFlows as OAuthFlowsModel
from fastapi.security.utils import get_authorization_scheme_param
from starlette.status import HTTP_401_UNAUTHORIZED, HTTP_403_FORBIDDEN







#  Code below is for authentication

class Oauth2ClientCredentials(OAuth2):
    def __init__(
        self,
        tokenUrl: str,
        scheme_name: str = None,
        scopes: dict = None,
        auto_error: bool = True,
    ):
        if not scopes:
            scopes = {}
        flows = OAuthFlowsModel(clientCredentials={"tokenUrl": tokenUrl, "scopes": scopes})
        super().__init__(flows=flows, scheme_name=scheme_name, auto_error=auto_error)

    async def __call__(self, request: Request) -> Optional[str]:
        authorization: str = request.headers.get("x-apif-auth")
        # print(authorization)
        # endpoint_url2 = Request.url
        # audience = str(endpoint_url2).rsplit("/",1)[-1]
        # print(audience)
        if not authorization:
            if self.auto_error:
                raise HTTPException(
                    status_code=HTTP_401_UNAUTHORIZED,
                    detail="Not authenticated",
                    headers={"WWW-Authenticate": "Bearer"},
                )
            else:
                return authorization
        return authorization 
security = HTTPBearer()
oauth2_scheme = Oauth2ClientCredentials(tokenUrl="https://dev.apigw.verizon.com/oauth2/v2/token", scopes={})
from jwt import PyJWKClient
import jwt
import os
from urllib.request import urlopen
import json
#  authentication function that will authenticate user using the FirstAPI token before authorizing them to preform a method
async def hasAccess(request: Request,authorization: str = Depends(oauth2_scheme)):
    endpoint_url = str(request.url)
    audience_end = "/workflow-mgmt-system/v1/"+endpoint_url.split("/",3)[3]
    audience_end = audience_end.split("?")[0]
    print(audience_end)
    publicKeyFormat = jwt.algorithms.RSAAlgorithm.from_jwk(next((item for item in keySet["keys"] if item['kid'] is not None), None))
    try: 
        data = jwt.decode(
            authorization,
            publicKeyFormat,

            algorithms=["RS256"],
            audience=audience_end,
            issuer="https://aws-us-east-2.dev.int.apigw.verizon.com",
            options={"verify_exp": True}
        )
    except: 
        
        return False
    return data['teamId'], data['sub']

# Establishing FASTAPI app and DB connecitions
from fastapi import FastAPI, HTTPException, Body, Query, Path
# app = FastAPI(openapi_tags=tags_metadata)
app = FastAPI(openapi_tags=tags_metadata, dependencies=[ Depends(hasAccess)])




# this is used to create custom openapi json to fit the FirstAPI guidelines

def custom_openapi():
    if app.openapi_schema:
        return app.openapi_schema
    openapi_schema = get_openapi(
        title="Workflow Executor API",
        version="1.0.0",
        openapi_version="3.0.3",


        # summary="This is a custom API to CRUD workflows and tasks and traverse the workflow as well",
        description="This is a custom API to create and manage workflows and tasks and traverse the workflow as well. This api will store, and establishes version control when user needs to *restart* a task",
       
        routes=app.routes,
    )
    openapi_schema["info"] = {
        
        "title" :"Workflow Executor API",
         "version":"1.0.0",

         "contact":{
      "name":"SSG API Workflow Support",
      "url":"http://ssg.verizon.com/web/not/created/yet",
      "email":"mark.farid@verizon.com"
    },
         "description":"This is a custom API to create and manage workflows and tasks and traverse the workflow as well. This api will store, and establishes version control when user needs to *restart* a task",
        
         
         "x-vz-audience": "verizon-private",
         "x-vz-experience":True
        
        
    }
    openapi_schema["security"] = [
        {
            "Oauth2ClientCredentials": [
                "readOnly"
            ]
        }
    ]
    
    openapi_schema["servers"] = [{
      "url": "https://satellite-uat.verizon.com/twmss",
        "description": "API server"
        
        }]
#removing code 422 and replacing it with 400 since 422 isn't supported yet by FirstAPi
#removing and reading code 200 to change the description "successful to Ok" and remove the schema of the response 
    for path in openapi_schema["paths"]:
        for method in openapi_schema["paths"][path]:
            responses = openapi_schema["paths"][path][method]["responses"]
#             if "200" in responses and (path != "/all-workflows") and (path != "/all-workflows/next-task") and (path != "/add-data-or-notes"):
#                 print(path)
#                 responses.pop("200")
#                 responses["200"] = {
#                    "description": "Ok",
#     "content": {
#       "application/json": {
#         "schema": {
#           "type": "object",
#           "properties": {
#             "items": {
#               "type": "string",
#               "maxLength": 250,
#               "minLength": 1,
#               "description": "Ok"
#             }
#           }
#         }
#       }
#     }
#   }
            if "422" in responses:
                responses.pop("422")
                responses["400"] = {
                    
                    "description":"Bad Request"
                    }
        
                
    # for path in openapi_schema["paths"]:
    #      # for method in openapi_schema["paths"][path]:
    #          if "security" in path:
    #              path.pop("security")
                 
    for path in openapi_schema["paths"].values():
        for data in path.values():
            # data.pop("security")
            for method in path.values():       
                method.pop("security")
                
                
           # Fixing the  paths to include dashes inside the parameter name
    paths = openapi_schema.get("paths", {})
    if '/all-workflows' in paths:
        paths['/all-workflows'] = paths['/all-workflows']
        # paths.pop('/all-workflows')
    if '/all-workflows/next-task' in paths:
        paths['/all-workflows/next-task'] = paths['/all-workflows/next-task']
        # paths.pop('/all-workflows')
        
        
    if '/all-tasks/workflow-id/{workflowId}' in paths:
        paths['/all-tasks/workflow-id/{workflow-id}'] = paths['/all-tasks/workflow-id/{workflowId}']
        paths.pop('/all-tasks/workflow-id/{workflowId}')
        
    if '/num-version/workflow-id/{workflowId}' in paths:
        paths['/num-version/workflow-id/{workflow-id}'] = paths['/num-version/workflow-id/{workflowId}']
        paths.pop('/num-version/workflow-id/{workflowId}')    

    if '/get-task/workflow-id/{workflowId}/task-id/{taskIndex}' in paths:
        paths['/get-task/workflow-id/{workflow-id}/task-id/{task-id}'] = paths['/get-task/workflow-id/{workflowId}/task-id/{taskIndex}']
        paths.pop('/get-task/workflow-id/{workflowId}/task-id/{taskIndex}')  
        
        
    if '/start-task/workflow-id/{workflowId}/task-id/{taskIndex}' in paths:
        paths['/start-task/workflow-id/{workflow-id}/task-id/{task-id}'] = paths['/start-task/workflow-id/{workflowId}/task-id/{taskIndex}']
        paths.pop('/start-task/workflow-id/{workflowId}/task-id/{taskIndex}')   

    if '/complete-task/workflow-id/{workflowId}/task-id/{taskIndex}' in paths:
        paths['/complete-task/workflow-id/{workflow-id}/task-id/{task-id}'] = paths['/complete-task/workflow-id/{workflowId}/task-id/{taskIndex}']
        paths.pop('/complete-task/workflow-id/{workflowId}/task-id/{taskIndex}')   

    # if '/edit-notes/workflow-id/{workflowId}/task-id/{taskIndex}/notes/{notes}' in paths:
    #     paths['/edit-notes/workflow-id/{workflow-id}/task-id/{task-id}'] = paths['/edit-notes/workflow-id/{workflowId}/task-id/{taskIndex}/notes/{notes}']
    #     paths.pop('/edit-notes/workflow-id/{workflowId}/task-id/{taskIndex}/notes/{notes}')   


    if '/add-data-or-notes/workflow-id/{workflowId}/task-id/{taskIndex}' in paths:
        paths['/add-data/workflow-id/{workflow-id}/task-id/{task-id}'] = paths['/add-data-or-notes/workflow-id/{workflowId}/task-id/{taskIndex}']
        paths.pop('/add-data-or-notes/workflow-id/{workflowId}/task-id/{taskIndex}')   

    if '/add-metadata/workflow-id/{workflowId}/task-id/{taskIndex}' in paths:
        paths['/add-metadata/workflow-id/{workflow-id}/task-id/{task-id}'] = paths['/add-metadata/workflow-id/{workflowId}/task-id/{taskIndex}']
        paths.pop('/add-metadata/workflow-id/{workflowId}/task-id/{taskIndex}')           
        
    if '/workflow-tags/workflow-id/{workflowId}' in paths:
        paths['/workflow-tags/workflow-id/{workflow-id}/task-id/{task-id}'] = paths['/workflow-tags/workflow-id/{workflowId}']
        paths.pop('/workflow-tags/workflow-id/{workflowId}')   


    if '/next-task/workflow-id/{workflowId}' in paths:
        paths['/next-task/workflow-id/{workflow-id}'] = paths['/next-task/workflow-id/{workflowId}']
        paths.pop('/next-task/workflow-id/{workflowId}')   

    if '/restart-task/workflow-id/{workflowId}/task-id/{taskIndex}' in paths:
        paths['/restart-task/workflow-id/{workflow-id}/task-id/{task-id}'] = paths['/restart-task/workflow-id/{workflowId}/task-id/{taskIndex}']
        paths.pop('/restart-task/workflow-id/{workflowId}/task-id/{taskIndex}')   

    # Fixing the parameters to be dashes instead of camel Case 

    for path in openapi_schema["paths"].values():
        for data in path.values():
            for method in path.values():
                for parameter in method.get("parameters", []):
                    if parameter["name"] == "teamId":
                            parameter["name"] = "client-id"  # Rename to "name" in OpenAPI schema
            #     parameters.pop("teamId")
                    if parameter["name"] == "workflowId":
                            parameter["name"] = "workflow-id"  # Rename to "name" in OpenAPI schema
            #     parameters.pop("teamId")
                    if parameter["name"] == "taskIndex":
                            parameter["name"] = "task-id"  # Rename to "name" in OpenAPI schema
            #     parameters.pop("teamId")
                    if parameter["name"] == "inputData":
                            parameter["name"] = "input-data"  # Rename to "name" in OpenAPI schema
            #     parameters.pop("teamId")
    
    
    
  
    
    # removing the JsonvAlue schema since it causes errors    
    schemas = openapi_schema["components"]["schemas"]

    if 'JsonValue' in schemas:
        schemas.pop("JsonValue")
       
    
    # substituting the old properties of the below schemas to be of type object instead of jsonvalue
    schemas= openapi_schema["components"]["schemas"]["TaskData"]["properties"]
    schemas["taskInput"] =  {
	 "type": "object",
		"description": "taskInput",

     "properties": {
       "items": {
         "type": "string",
         "maxLength": 250,
         "minLength": 1,
         "description": "Ok"
       }
     }
	}
    schemas= openapi_schema["components"]["schemas"]["TaskData"]["properties"]
    schemas["taskMetadata"] =  {
	 "type": "object",
		"description": "taskMetadata",

     "properties": {
       "items": {
         "type": "string",
         "maxLength": 250,
         "minLength": 1,
         "description": "Ok"
       }
     }
	}
    
    schemas= openapi_schema["components"]["schemas"]["TaskData"]["properties"]
    schemas["taskDeliverable"] =  {
	 "type": "object",
		"description": "taskDeliverable",

    "properties": {
      "items": {
        "type": "string",
        "maxLength": 250,
        "minLength": 1,
        "description": "Ok"
      }
    }
}

    
    schemas= openapi_schema["components"]["schemas"]["updateData"]["properties"]
    schemas["taskInput"]=  {
	 "type": "object",
		"description": "taskInput",

     "properties": {
       "items": {
         "type": "string",
         "maxLength": 250,
         "minLength": 1,
         "description": "Ok"
       }
     }
	}  

    schemas= openapi_schema["components"]["schemas"]["updateData"]["properties"]
    schemas["taskDeliverable"]=  {
	 "type": "object",
		"description": "taskDeliverable",

     "properties": {
       "items": {
         "type": "string",
         "maxLength": 250,
         "minLength": 1,
         "description": "Ok"
       }
     }
	}     
    schemas= openapi_schema["components"]["schemas"]["updateMetadata"]["properties"]
    schemas["taskMetadata"]=  {
	 "type": "object",
		"description": "taskMetadata",

     "properties": {
       "items": {
         "type": "string",
         "maxLength": 250,
         "minLength": 1,
         "description": "Ok"
       }
     }
	} 
    openapi_schema["tags"] = [
        {
            "name": "all-workflows",
            "description": "Operation to get all the Workflows for a Team.  ",
        },
        {
            "name": "all-workflows/next-task",
            "description": "Operation to get all the Workflows and their Next Task for a Team.  ",
        },
        {
            "name": "all-tasks",
            "description": "Operation to get all the Tasks for a specific workflow (latest version). Input:  **Workflow ID**  ",
        },
        
        {
            "name": "num-version",
            "description": "Operation to get the number of versions for a specific workflow. Input:  **Workflow ID** ",
        },
        {
            "name": "task",
            "description": "Operation to get all the info of a specific task in a workflow (latest version). Input:  **Workflow ID**,**Task ID**  ",
        },
        
        {
            "name": "start-task",
            "description": "Operation to **Start** a task in a workflow (latest version). Input:  **Workflow ID**,**Task ID** Note: If Task is already started, operation will return first time task was started, and start date will not be updated! ",
        },
        {
            "name": "complete-task",
            "description": "Operation to **Complete** a task in a workflow (latest version). Input:  **Workflow ID**,**Task ID**  ",
        },
        
        
        
    
        
        
        {
            "name": "next-task",
            "description": "Operation to **Retrieve** the next task to do in a workflow (latest version). Input:  **Workflow ID**  ",
        },
        
        {
            "name": "restart-task",
            "description": "Operation to **Redo a task** in a workflow sets completed date to null and creates a new workflow version with that after . Input:  **Workflow ID**,**Task ID** NOTE: Even if input Task is not started/completed, a new version will be created! ",
        },
        
        {
            "name": "new-workflow",
            "description": "Operation to **Create a workflow**. Input: **Json Body**  ",
        }
        
        ]
       
    # removing schemas that cause issues    
    if "components" in openapi_schema and "schemas" in openapi_schema["components"]:
         openapi_schema["components"]["schemas"].pop("ValidationError")
         openapi_schema["components"]["schemas"].pop("HTTPValidationError")

    app.openapi_schema = openapi_schema
    return app.openapi_schema
    
    schema_for_iteration = deepcopy(openapi_schema)
    openapi_schema["paths"] = {}
    for path, path_definition in schema_for_iteration["paths"].items():
            list_of_path_params_with_underscores = re.findall("{([a-zA-Z_]*)}", path)
            if list_of_path_params_with_underscores:
                # Change the 'path' key and replace _ with -
                new_path = path.replace("_", "-")
                openapi_schema["paths"][new_path] = schema_for_iteration["paths"][path]
                # For each path param with underscores, changes the parameter name
                for path_param in list_of_path_params_with_underscores:
                    new_path_param = path_param.replace("_", "-")
                    for http_verb, http_verb_definition in path_definition.items():
                        for index, param in enumerate(http_verb_definition["parameters"]):
                            if param["name"] == path_param:
                                openapi_schema["paths"][new_path][http_verb]["parameters"][
                                    index
                                ]["name"] = new_path_param
            else:
                # If there are no path params with underscores, take the original definition
                openapi_schema["paths"][path] = schema_for_iteration["paths"][path]
                
    

app.openapi = custom_openapi




# The Task Class 

class Task(StructuredNode):
    workflowId = StringProperty()
    workflowName = StringProperty(unique_index=True, required=True)
    workflowDateDue= DateTimeFormatProperty(required=True)
    taskName = StringProperty(required=True)
    taskDateDue= DateTimeFormatProperty()
    taskDateCompleted=DateTimeFormatProperty()
    taskDateCreated= StringProperty( )
    taskDateStarted=DateTimeFormatProperty()
    taskSla=IntegerProperty()
    taskIndex=IntegerProperty( required=True)
    taskInput= JSONProperty(required=False)
    taskDeliverable= JSONProperty(required=False)
    taskAllowedUser = ArrayProperty(required=False)
    workflowTags = ArrayProperty(required=False)
    taskCompletedBy = StringProperty(required=False)
    NextTask = RelationshipTo('Task','NEXT_TASK')
    teamId = StringProperty(required=True)
    sub = StringProperty(required=True)
    taskMetadata = JSONProperty(required=False)
    notes = StringProperty()
    workflowVersion = IntegerProperty()
    
    




# This is a sample date I use for testing in the API, has no functionality in the code
user_input = "2024-12-25 10:30:00"

# Convert user input string to datetime object
datetime_object = datetime.strptime(user_input, "%Y-%m-%d %H:%M:%S")

valid_pattern = Annotated [str, StringConstraints(pattern=r"^[A-Za-z0-9_-]{1,32}$")]
 # This is a class created for FastAPI to generate variables as json fields, passed in the POST statement.    
class TaskData(BaseModel):
    taskName : str = Field(min_length=1, max_length=250 , description='Task Name', pattern=".+" )
    taskDateDue: str = Field(min_length=1, max_length=250, description='Task Due Date', pattern="^\d{4}-\d{2}-\d{2}\s\d{2}:\d{2}:\d{2}$")
    taskIndex: StrictInt = Field(..., format='int32', description='Task ID')
    taskInput:JsonValue = None
    taskMetadata:JsonValue = None
    taskDeliverable:JsonValue = None
    taskCompletedBy :str = Field(default=None,min_length=1, max_length=250, description='Task Completed by Field', pattern="^[a-zA-Z0-9\s\-:_@.]{1,100}$")
    taskAllowedUser : Annotated[ List [valid_pattern], Field ( default=None, min_length=1, max_length=250, description='Task Allowed User, the liist of User Roles permitted to see the Task')] 
    taskSla: StrictInt = Field( default=None, format='int64', description='Task SLA') 
    notes: str = Field(default=None,min_length=1, max_length=250, description='Task Notes', pattern=".+")
    connectsTo: List[int] = Field( default=None, format='int64', min_length=1, max_length=250, description='Task connections') 
    model_config = ConfigDict(extra='forbid')

 # This is a class created for FastAPI to generate variables as json fields, passed in the POST statement.    

class WorkflowData(BaseModel):
    workflowName : str = Field(min_length=1, max_length=250, description='Workflow Name', pattern=".+")
    workflowDateDue: str = Field(min_length=1, max_length=250, description='Workflow Due Date',  pattern="^\d{4}-\d{2}-\d{2}\s\d{2}:\d{2}:\d{2}$")
    workflowTags : Annotated[ List [valid_pattern], Field ( default=None, min_length=1, max_length=250, description='Task Allowed User, the liist of User Roles permitted to see the Task')] 
    model_config = ConfigDict(extra='forbid')


class response(BaseModel):
    response : str = Field(min_length=1, max_length=250, default= "Response Worked")
    


class updateData(BaseModel):
    workflowId: str = Field(min_length=1, max_length=250 , description='WorkflowID', pattern="^[A-Za-z0-9]{1,32}$")
    # teamId: str = Field(min_length=1, max_length=250, description='TeamID', pattern="^[A-Za-z0-9]{1,32}$")
    taskIndex: StrictInt = Field(..., format='int64', description='Task ID', ge=0, le=10000)
    taskInput:JsonValue = None
    taskDeliverable:JsonValue = None

    notes: str = Field(default=None,min_length=1, max_length=250, description='Task Notes', pattern=".+")
    model_config = ConfigDict(extra='forbid')

class updateMetadata(BaseModel):
    workflowId: str = Field(min_length=1, max_length=250 , description='WorkflowID', pattern="^[A-Za-z0-9]{1,32}$")
    taskIndex: StrictInt = Field(..., format='int64', description='Task ID' , ge=0, le=10000)
    taskMetadata:JsonValue = None
    model_config = ConfigDict(extra='forbid')    

class workflowTagsData(BaseModel):
    workflowTags : Annotated[ List [valid_pattern], Field ( default=None, min_length=1, max_length=250, description='Task Allowed User, the liist of User Roles permitted to see the Task')] 
    workflowId: str = Field(min_length=1, max_length=250 , description='WorkflowID', pattern="^[A-Za-z0-9]{1,32}$")

    model_config = ConfigDict(extra='forbid')


@app.on_event("startup")
async def startup_event():

   config.DATABASE_URL  = os.getenv('config.DATABASE_URL')
   db.set_connection(url=os.getenv('url'))
#    results, meta = run_cypher_query("RETURN 'Helloo World!' as message")

@app.exception_handler(RequestValidationError)
async def validation_exception_handler(request: Request, exc: RequestValidationError):
    return JSONResponse(
        status_code=HTTP_400_BAD_REQUEST,
        content={"detail":exc.errors()})
from fastapi.openapi.models import OAuthFlows as OAuthFlowsModel
from fastapi.security.utils import get_authorization_scheme_param
from starlette.status import HTTP_401_UNAUTHORIZED, HTTP_403_FORBIDDEN
 
async def get_next_task( workflowId: str  = Path( description="The TeamID should be Passed here", regex='^[A-Za-z0-9]{1,32}$'), task_allowed_user:  List [valid_pattern] = Query ( default=None, min_length=1, max_length=250, description='Task Allowed User, the dyt of User Roles permitted to see the Task'), hasAccess : dict= Depends(hasAccess) ):
    
  
  """
   Operation to **Retrieve** the next task to do in a workflow (latest version). Input:  **Workflow ID**  
  """
  
  if hasAccess and hasAccess is not None:
      teamId , _ = hasAccess
      if task_allowed_user and task_allowed_user is not None:
          
          query= '''MATCH (t:Task {workflowId:$workflowId})-[NEXT_TASK]-(b)
                  WITH max(t.workflowVersion) as max
                  MATCH (t:Task {workflowVersion : max, workflowId:$workflowId, teamId: $teamId })
                  WHERE (NOT ()-->(t) AND t.taskDateCompleted is null  AND (t.workflowId= $workflowId AND t.teamId =$teamId AND  ( ANY  (allowedUsers IN $taskAllowedUser Where  allowedUsers IN t.taskAllowedUser ) 	)    ))
                  OR (t.taskDateCompleted is null AND (t.workflowId= $workflowId AND t.teamId =$teamId AND  (ANY  (allowedUsers IN $taskAllowedUser Where  allowedUsers IN t.taskAllowedUser ) 	 ) ) AND ALL(m IN [(m)-->(t) | m] WHERE m.taskDateCompleted is NOT null))
                
                  RETURN DISTINCT t.workflowId as workflowId,t.taskIndex as taskIndex, t.taskName as taskName, t.taskDateDue as Task_Due_Date, t.workflowDateDue,  t.workflowName, t.taskMetadata
          '''
        #   query= '''MATCH (t:Task {workflowId:$workflowId})-[NEXT_TASK]-(b)
        #           WITH max(t.workflowVersion) as max
        #           MATCH (t:Task {workflowVersion : max, workflowId:$workflowId, teamId: $teamId })
        #           WHERE (NOT ()-->(t) AND t.taskDateCompleted is null  AND (t.workflowId= $workflowId AND t.teamId =$teamId AND  ( ANY  (allowedUsers IN $taskAllowedUser Where  allowedUsers IN t.taskAllowedUser ) 	 OR (t.taskAllowedUser	 IS NULL OR size(t.taskAllowedUser	) = 0))   ))
        #           OR (t.taskDateCompleted is null AND (t.workflowId= $workflowId AND t.teamId =$teamId AND  (ANY  (allowedUsers IN $taskAllowedUser Where  allowedUsers IN t.taskAllowedUser ) 	 OR (t.taskAllowedUser	 IS NULL OR size(t.taskAllowedUser	) = 0)) ) AND ALL(m IN [(m)-->(t) | m] WHERE m.taskDateCompleted is NOT null))
                
        #           RETURN DISTINCT t.workflowId as workflowId, t.taskIndex as taskIndex, t.taskName as taskName, t.taskDateDue as Task_Due_Date, t.workflowDateDue, t.workflowName
        #   '''
          results,meta =run_cypher_query(query, {'teamId': teamId , 'workflowId':workflowId, 'taskAllowedUser': task_allowed_user})

          if (len(results) ==0):
                incorrect_out = "Incorrect Input: Task, Workflow don't exist!, OR Workflow is already completed"
                return incorrect_out
        #   Formatted_Results = [{"workflowId": row[0], "taskIndex":row[1],"taskName":row[2], "taskDateDue": row[3],"workflowDateDue": row[4],"workflowDateCompleted": row[5], "workflowName": row[6] } for row in results]
          Formatted_Results = [{"workflowId": row[0], "taskIndex":row[1],"taskName":row[2], "taskDateDue": row[3],"workflowDateDue": row[4], "workflowName": row[5], "taskMetadata": row[6] } for row in results]
        
          return Formatted_Results 
      else:
          query= '''MATCH (t:Task {workflowId:$workflowId})-[NEXT_TASK]-(b)
                  WITH max(t.workflowVersion) as max
                  MATCH (t:Task {workflowVersion : max, workflowId:$workflowId, teamId: $teamId})
                  WHERE (NOT ()-->(t) AND t.taskDateCompleted is null  AND (t.workflowId= $workflowId AND t.teamId =$teamId))
                  OR (t.taskDateCompleted is null AND (t.workflowId= $workflowId AND t.teamId =$teamId) AND ALL(m IN [(m)-->(t) | m] WHERE m.taskDateCompleted is NOT null))
                
                  RETURN DISTINCT t.workflowId as workflowId,t.taskIndex as taskIndex, t.taskName as taskName, t.taskDateDue as Task_Due_Date, t.workflowDateDue, t.workflowName, t.taskMetadata
        
          '''
          results,meta = run_cypher_query(query, {'teamId': teamId , 'workflowId':workflowId})
          if (len(results) ==0):
                  incorrect_out = "Incorrect Input: Task, Workflow don't exist!, OR Workflow is already completed"
                  return incorrect_out
          Formatted_Results = [{"workflowId": row[0], "taskIndex":row[1],"taskName":row[2], "taskDateDue": row[3],"workflowDateDue": row[4], "workflowName": row[5] , "taskMetadata": row[6]  } for row in results]
        
          return  Formatted_Results 
  else:
      return {"NOT AUTHENTICATED or Invalid Token"} 

              



@app.get("/all-workflows",  tags=["all-workflows"], responses = {
 
 200: {"description": "Ok","content": {
                            "application/json": {
                                "schema": {
                                    "type": "object",
                                    "properties": {
                                       

                                                      "workflows": {
                                                        "type": "array",
                                                        "minItems": 0,
                                                        "maxItems": 1000,
                                                        "description": "Operation to get all the Workflows for a client. Input: **Client**", 
                                                        "items": {
                                                        "type": "object",
                                                        "properties": {
                                                            "workflowName": {
                                                                "type": "string",
                                                                "description": "Workflow Name",
                                                                "minLength": 0,
                                                                "maxLength": 100
                                                            },
                                                            "workflowDateDue": {
                                                                "type": "string",
                                                                "description": "Workflow Due Date",
                                                                "minLength": 0,
                                                                "maxLength": 100
                                                            },
                                                            "workflowId": {
                                                                "type": "string",
                                                                "description": "Workflow ID",
                                                                "minLength": 0,
                                                                "maxLength": 100
                                                            }
                                                        },
                                                        "additionalProperties": False
                                                    }
                                                }

                                             
                                       
                                      
                                    },
                                    "additionalProperties": False
                                }
                            }
                        }},
403: {"description": "Forbidden"}, 
404: {"description": "Not Found"}, 
401: {"description": "Unauthorized"}, 
415: {"description": "Unsupported Media Type"}, 
504: {"description": "Gateway Timeout"}, 
404: {"description": "Not Found"}, 
401: {"description": "Unauthorized"}, 
415: {"description": "Unsupported Media Type"}, 
504: {"description": "Gateway Timeout"},   
400: {"description": "Bad Request"}
 
    
})
# async def read_root(  teamId:  Annotated[str, Path(description="The ID of the item to get" , regex='^[A-Za-z0-9]{1,32}$')], hasAccess : dict= Depends(hasAccess)):

async def all_workflows(   request: Request, workflow_tags: str= Query( None, description='''The workflowTags should be Passed here. The syntax should follow this format: {"workflowTags": ["Tag1","Tag2"]}''', regex="^.{1,1048}$"),task_allowed_user: str= Query( None, description='''The Allowed user role should be Passed here. The syntax should follow this format: {"taskAllowedUser": ["role1","role2"]}''', regex="^.{1,1048}$") ,hasAccess : dict= Depends(hasAccess), skip : int= Query( None, description="The number of items you want to skip should be Passed here",  ge=0, le=1000000), limit : int= Query( None, description="The number of items you want to return should be Passed here",  ge=1, le=100)):
  """
     Operation to get all the Workflows for a client. 
    """  
  if hasAccess and hasAccess is not None:
      print ("TeamID is: ", hasAccess)
      teamId , _ = hasAccess
      query_params = request.query_params
      keys_list = list(query_params.keys())
      for key in keys_list:
        if len(query_params.getlist(key))>1  :
            raise HTTPException(status_code=400, detail="Bad Request can not pass an array")
      if task_allowed_user and task_allowed_user is not None:
         json_string = task_allowed_user 
         try:
            task_allowed_user = json.loads(json_string)  
         except:
            raise HTTPException(status_code=400, detail="Wrong Json Syntax")
         try:
            task_allowed_user= task_allowed_user["taskAllowedUser"]
         except:
            print(task_allowed_user)
            raise HTTPException(status_code=400, detail="task_allowed_user Key was not provided, or key contains a typo")
      if workflow_tags and workflow_tags is not None:
         json_string = workflow_tags 
         try:
            workflow_tags = json.loads(json_string)  
         except:
            raise HTTPException(status_code=400, detail="Wrong Json Syntax")
         try:
            workflow_tags= workflow_tags["workflowTags"]
         except:
            print(workflow_tags)
            raise HTTPException(status_code=400, detail="workflow_tags Key was not provided, or key contains a typo")

      if (limit or skip) and task_allowed_user and workflow_tags:
         if limit is None:
            limit = 100
         if skip is None:
            skip = 0
            
         query= '''Match (n:Task {teamId:$teamId})
          WITH n.workflowId as workflowId, max(n.workflowVersion) as max 
          MATCH (n:Task {workflowVersion : max, workflowId : workflowId,teamId:$teamId })  
          Where (ANY  (allowedUsers IN $taskAllowedUser Where  allowedUsers IN n.taskAllowedUser ) ) AND  (all  (workflowTags IN $workflowTags Where workflowTags IN n.workflowTags ) )
         Return DISTINCT n.workflowName , n.workflowDateDue , n.workflowId
          skip $skip limit $limit '''
         results,meta = run_cypher_query(query, {'teamId': teamId , "skip": skip, "limit": limit, "taskAllowedUser":task_allowed_user , "workflowTags": workflow_tags})


      elif task_allowed_user and workflow_tags:
         if limit is None:
            limit = 100
         if skip is None:
            skip = 0
            
         query= '''Match (n:Task  {teamId:$teamId})
          WITH n.workflowId as workflowId, max(n.workflowVersion) as max 
          Match (n:Task  {workflowVersion : max, workflowId : workflowId,teamId:$teamId })  
          Where (ANY  (allowedUsers IN $taskAllowedUser Where  allowedUsers IN n.taskAllowedUser ) ) AND  (all  (workflowTags IN $workflowTags Where workflowTags IN n.workflowTags ) )
         Return DISTINCT n.workflowName , n.workflowDateDue , n.workflowId
          skip $skip limit $limit '''
         results,meta = run_cypher_query(query, {'teamId': teamId , "skip": skip, "limit": limit, "taskAllowedUser":task_allowed_user , "workflowTags": workflow_tags})

    
      elif (limit or skip) and task_allowed_user:
         if limit is None:
            limit = 100
         if skip is None:
            skip = 0
            
         query= '''Match (n:Task  {teamId:$teamId})
          WITH n.workflowId as workflowId, max(n.workflowVersion) as max 
          Match (n:Task  {workflowVersion : max, workflowId : workflowId,teamId:$teamId })  
          Where (ANY  (allowedUsers IN $taskAllowedUser Where  allowedUsers IN n.taskAllowedUser ) ) 
          Return DISTINCT n.workflowName , n.workflowDateDue , n.workflowId
          skip $skip limit $limit '''
         results,meta = run_cypher_query(query, {'teamId': teamId , "skip": skip, "limit": limit, "taskAllowedUser":task_allowed_user })
         
      elif (limit or skip) and workflow_tags:
         if limit is None:
            limit = 100
         if skip is None:
            skip = 0
            
         query= '''Match (n:Task  {teamId:$teamId})
          WITH n.workflowId as workflowId, max(n.workflowVersion) as max 
          Match (n:Task  {workflowVersion : max, workflowId : workflowId,teamId:$teamId })  
          Where (all  (workflowTags IN $workflowTags Where workflowTags IN n.workflowTags ) )
          Return DISTINCT n.workflowName , n.workflowDateDue , n.workflowId
          skip $skip limit $limit '''
         results,meta = run_cypher_query(query, {'teamId': teamId , "skip": skip, "limit": limit, "workflowTags":workflow_tags })
      elif (limit or skip) :
         if limit is None:
            limit = 100
         if skip is None:
            skip = 0
         query= '''Match (n:Task  {teamId:$teamId})
          WITH n.workflowId as workflowId, max(n.workflowVersion) as max 
          Match (n:Task  {workflowVersion : max, workflowId : workflowId,teamId:$teamId })  
            
          Return DISTINCT n.workflowName , n.workflowDateDue , n.workflowId
          skip $skip limit $limit '''        
         results,meta = run_cypher_query(query, {'teamId': teamId , "skip": skip, "limit": limit})
      elif  task_allowed_user:
         if limit is None:
            limit = 100
         if skip is None:
            skip = 0
            
         query= '''Match (n:Task  {teamId:$teamId})
          WITH n.workflowId as workflowId, max(n.workflowVersion) as max 
          Match (n:Task  {workflowVersion : max, workflowId : workflowId,teamId:$teamId })  
          Where (ANY  (allowedUsers IN $taskAllowedUser Where  allowedUsers IN n.taskAllowedUser ) ) 
          Return DISTINCT n.workflowName , n.workflowDateDue , n.workflowId
          skip $skip limit $limit '''
         results,meta = run_cypher_query(query, {'teamId': teamId , "skip": skip, "limit": limit, "taskAllowedUser":task_allowed_user })      

      elif  workflow_tags:
         if limit is None:
            limit = 100
         if skip is None:
            skip = 0
            
         query= '''Match (n:Task  {teamId:$teamId})
          WITH n.workflowId as workflowId, max(n.workflowVersion) as max 
          Match (n:Task  {workflowVersion : max, workflowId : workflowId,teamId:$teamId })  
          Where (all  (workflowTags IN $workflowTags Where workflowTags IN n.workflowTags ) )
        Return DISTINCT n.workflowName , n.workflowDateDue , n.workflowId
          skip $skip limit $limit '''
         results,meta = run_cypher_query(query, {'teamId': teamId , "skip": skip, "limit": limit, "workflowTags":workflow_tags })          
      else:  
        query= '''Match (n:Task  {teamId:$teamId})
                WITH n.workflowId as workflowId, max(n.workflowVersion) as max 
                Match (n:Task  {workflowVersion : max, workflowId : workflowId,teamId:$teamId })   
                 Return DISTINCT n.workflowName , n.workflowDateDue , n.workflowId
                limit 100
               '''
        results,meta = run_cypher_query(query, {'teamId': teamId })
      if (len(results) ==0):
              raise HTTPException(status_code=404, detail="Incorrect Input")
      Formatted_Results = [{"workflowName":row[0], "workflowDateDue": row[1], "workflowId" : row[2]} for row in results]
      return {"workflows": Formatted_Results}
  else :
      return {"NOT AUTHENTICATED or Invalid Token"}


#   if hasAccess and hasAccess is not None:
#       print ("TeamID is: ", hasAccess)
#       teamId , _ = hasAccess
#       if limit or skip:
#          if limit is None:
#             limit = 100
#          if skip is None:
#             skip = 0
#          query= '''Match (n:Task  {teamId:$teamId})
#           WITH n.workflowId as workflowId, max(n.workflowVersion) as max 
#           Match (n:Task  {workflowVersion : max, workflowId : workflowId,teamId:$teamId })      
#          Return DISTINCT n.workflowName AS workflowName, n.workflowDateDue as DUE_DATE , n.workflowId as WorkflowID
#           skip $skip limit $limit '''
#          results,meta = run_cypher_query(query, {'teamId': teamId , "skip": skip, "limit": limit})
#       else :
#         query= '''Match (n:Task  {teamId:$teamId})
#                 WITH n.workflowId as workflowId, max(n.workflowVersion) as max 
#                 Match (n:Task  {workflowVersion : max, workflowId : workflowId,teamId:$teamId })      
#                 Return DISTINCT n.workflowName AS workflowName, n.workflowDateDue as DUE_DATE , n.workflowId as WorkflowID 
#                 limit 100
#                '''
#         results,meta = run_cypher_query(query, {'teamId': teamId })
#       if (len(results) ==0):
#               raise HTTPException(status_code=404, detail="Incorrect Input")
#       Formatted_Results = [{"workflowName":row[0], "workflowDateDue": row[1], "workflowId" : row[2]} for row in results]

#       return {"All Workflows": Formatted_Results}
#   else :
#       return {"NOT AUTHENTICATED or Invalid Token"}





@app.get("/all-workflows/next-task",  tags=["all-workflows/next-task"], responses = {
 
  200: {
                        "description": "Ok",
                        "content": {
                            "application/json": {
                                "schema": {
                                    "type": "object",
                                    "properties": {
                                        "allWorkflows": {
                                            "type": "array",
                                            "minItems": 0,
                                            "maxItems": 1000,
                                            "description": "This key will actually be the workflow ID of the array object inside of it.",
                                            "items": {
                                                "type": "array",
                                                "minItems": 0,
                                                "maxItems": 1000,
                                                "description": "This key will actually be the workflow ID of the array object inside of it.",
                                                "items": {
                                                    "type": "object",
                                                    "properties": {
                                                        "workflowId": {
                                                            "type": "string",
                                                            "description": "Workflow ID",
                                                            "minLength": 0,
                                                            "maxLength": 100
                                                        },
                                                        "taskDateDue": {
                                                            "type": "string",
                                                            "description": "task Due Date",
                                                            "minLength": 0,
                                                            "maxLength": 100
                                                        },
                                                        "workflowDateDue": {
                                                            "type": "string",
                                                            "description": "Workflow Due Date",
                                                            "minLength": 0,
                                                            "maxLength": 100
                                                        },
                                                        "workflowDateCompleted": {
                                                            "type": "string",
                                                            "description": "Workflow Completion Date",
                                                            "minLength": 0,
                                                            "maxLength": 100
                                                        },
                                                        "taskIndex": {
                                                            "type": "integer",
                                                            "description": "Task ID",
                                                            "format": "int64"
                                                        },
                                                        "taskName": {
                                                            "type": "string",
                                                            "description": "Task Name",
                                                            "minLength": 0,
                                                            "maxLength": 100
                                                        },
                                                        "workflowName": {
                                                            "type": "string",
                                                            "description": "workflowName",
                                                            "minLength": 0,
                                                            "maxLength": 100
                                                        },
                                                        "taskMetadata": {
                                                            "type": "string",
                                                            "description": "workflowName",
                                                            "minLength": 0,
                                                            "maxLength": 10000
                                                        }
                                                    },
                                                    "additionalProperties": False,
                                                    "required": [
                                                        "workflowId",
                                                        "taskDateDue",
                                                        "workflowDateDue",
                                                        "taskName",
                                                        "taskIndex",
                                                        "workflowName"
                                                    ]
                                                },
                                                "additionalProperties": False
                                            },
                                            "additionalProperties": False
                                        }
                                    },
                                    "additionalProperties": False
                                }
                            }
                        }
                    },
403: {"description": "Forbidden"}, 
404: {"description": "Not Found"}, 
401: {"description": "Unauthorized"}, 
415: {"description": "Unsupported Media Type"}, 
504: {"description": "Gateway Timeout"},   
400: {"description": "Bad Request"}
 
    
})

async def all_workflows_next_task(  request: Request, workflow_tags: str= Query( None, description='''The workflowTags should be Passed here. The syntax should follow this format: {"workflowTags": ["Tag1","Tag2"]}''', regex="^.{1,1048}$"),task_allowed_user: str= Query( None, description='''The Allowed user role should be Passed here. The syntax should follow this format: {"taskAllowedUser": ["role1","role2"]}''', regex="^.{1,1048}$") ,hasAccess : dict= Depends(hasAccess), skip : int= Query( None, description="The number of items you want to skip should be Passed here",  ge=0, le=1000000), limit : int= Query( None, description="The number of items you want to return should be Passed here",  ge=1, le=100)):
  """
     Operation to get all the Workflows for a client. 
    """  
  if hasAccess and hasAccess is not None:
      print ("TeamID is: ", hasAccess)
      teamId , _ = hasAccess
      query_params = request.query_params
      keys_list = list(query_params.keys())
      for key in keys_list:
        if len(query_params.getlist(key))>1  :
            raise HTTPException(status_code=400, detail="Bad Request can not pass an array")
      if task_allowed_user and task_allowed_user is not None:
         json_string = task_allowed_user 
         try:
            task_allowed_user = json.loads(json_string)  
         except:
            raise HTTPException(status_code=400, detail="Wrong Json Syntax")
         try:
            task_allowed_user= task_allowed_user["taskAllowedUser"]
         except:
            print(task_allowed_user)
            raise HTTPException(status_code=400, detail="task_allowed_user Key was not provided, or key contains a typo")
      if workflow_tags and workflow_tags is not None:
         json_string = workflow_tags 
         try:
            workflow_tags = json.loads(json_string)  
         except:
            raise HTTPException(status_code=400, detail="Wrong Json Syntax")
         try:
            workflow_tags= workflow_tags["workflowTags"]
         except:
            print(workflow_tags)
            raise HTTPException(status_code=400, detail="workflow_tags Key was not provided, or key contains a typo")

      if (limit or skip) and task_allowed_user and workflow_tags:
         if limit is None:
            limit = 100
         if skip is None:
            skip = 0
            
         query= '''Match (n:Task {teamId:$teamId})
          WITH n.workflowId as workflowId, max(n.workflowVersion) as max 
          MATCH (n:Task {workflowVersion : max, workflowId : workflowId,teamId:$teamId })  
          Where n.workflowDateCompleted is Null AND  (ANY  (allowedUsers IN $taskAllowedUser Where  allowedUsers IN n.taskAllowedUser ) ) AND  (all  (workflowTags IN $workflowTags Where workflowTags IN n.workflowTags ) )
         Return DISTINCT n.workflowId as WorkflowID
          skip $skip limit $limit '''
         results,meta = run_cypher_query(query, {'teamId': teamId , "skip": skip, "limit": limit, "taskAllowedUser":task_allowed_user , "workflowTags": workflow_tags})


      elif task_allowed_user and workflow_tags:
         if limit is None:
            limit = 100
         if skip is None:
            skip = 0
            
         query= '''Match (n:Task  {teamId:$teamId})
          WITH n.workflowId as workflowId, max(n.workflowVersion) as max 
          Match (n:Task  {workflowVersion : max, workflowId : workflowId,teamId:$teamId })  
          Where n.workflowDateCompleted is Null AND  (ANY  (allowedUsers IN $taskAllowedUser Where  allowedUsers IN n.taskAllowedUser ) ) AND  (all  (workflowTags IN $workflowTags Where workflowTags IN n.workflowTags ) )
          Return DISTINCT n.workflowId as WorkflowID
          skip $skip limit $limit '''
         results,meta = run_cypher_query(query, {'teamId': teamId , "skip": skip, "limit": limit, "taskAllowedUser":task_allowed_user , "workflowTags": workflow_tags})

    
      elif (limit or skip) and task_allowed_user:
         if limit is None:
            limit = 100
         if skip is None:
            skip = 0
            
         query= '''Match (n:Task  {teamId:$teamId})
          WITH n.workflowId as workflowId, max(n.workflowVersion) as max 
          Match (n:Task  {workflowVersion : max, workflowId : workflowId,teamId:$teamId })  
          Where n.workflowDateCompleted is Null AND  (ANY  (allowedUsers IN $taskAllowedUser Where  allowedUsers IN n.taskAllowedUser ) ) 
          Return DISTINCT n.workflowId as WorkflowID
          skip $skip limit $limit '''
         results,meta = run_cypher_query(query, {'teamId': teamId , "skip": skip, "limit": limit, "taskAllowedUser":task_allowed_user })
         
      elif (limit or skip) and workflow_tags:
         if limit is None:
            limit = 100
         if skip is None:
            skip = 0
            
         query= '''Match (n:Task  {teamId:$teamId})
          WITH n.workflowId as workflowId, max(n.workflowVersion) as max 
          Match (n:Task  {workflowVersion : max, workflowId : workflowId,teamId:$teamId })  
          Where n.workflowDateCompleted is Null AND  (all  (workflowTags IN $workflowTags Where workflowTags IN n.workflowTags ) )
          Return DISTINCT n.workflowId as WorkflowID
          skip $skip limit $limit '''
         results,meta = run_cypher_query(query, {'teamId': teamId , "skip": skip, "limit": limit, "workflowTags":workflow_tags })
      elif (limit or skip) :
         if limit is None:
            limit = 100
         if skip is None:
            skip = 0
         query= '''Match (n:Task  {teamId:$teamId})
          WITH n.workflowId as workflowId, max(n.workflowVersion) as max 
          Match (n:Task  {workflowVersion : max, workflowId : workflowId,teamId:$teamId })  
          Where n.workflowDateCompleted is Null    
          Return DISTINCT n.workflowId as WorkflowID
          skip $skip limit $limit '''        
         results,meta = run_cypher_query(query, {'teamId': teamId , "skip": skip, "limit": limit})
      elif  task_allowed_user:
         if limit is None:
            limit = 100
         if skip is None:
            skip = 0
            
         query= '''Match (n:Task  {teamId:$teamId})
          WITH n.workflowId as workflowId, max(n.workflowVersion) as max 
          Match (n:Task  {workflowVersion : max, workflowId : workflowId,teamId:$teamId })  
          Where n.workflowDateCompleted is Null AND  (ANY  (allowedUsers IN $taskAllowedUser Where  allowedUsers IN n.taskAllowedUser ) ) 
          Return DISTINCT n.workflowId as WorkflowID
          skip $skip limit $limit '''
         results,meta = run_cypher_query(query, {'teamId': teamId , "skip": skip, "limit": limit, "taskAllowedUser":task_allowed_user })      

      elif  workflow_tags:
         if limit is None:
            limit = 100
         if skip is None:
            skip = 0
            
         query= '''Match (n:Task  {teamId:$teamId})
          WITH n.workflowId as workflowId, max(n.workflowVersion) as max 
          Match (n:Task  {workflowVersion : max, workflowId : workflowId,teamId:$teamId })  
          Where n.workflowDateCompleted is Null AND  (all  (workflowTags IN $workflowTags Where workflowTags IN n.workflowTags ) )
         Return DISTINCT n.workflowId as WorkflowID
          skip $skip limit $limit '''
         results,meta = run_cypher_query(query, {'teamId': teamId , "skip": skip, "limit": limit, "workflowTags":workflow_tags })          
      else:  
        query= '''Match (n:Task  {teamId:$teamId})
                WITH n.workflowId as workflowId, max(n.workflowVersion) as max 
                Match (n:Task  {workflowVersion : max, workflowId : workflowId,teamId:$teamId })
                Where n.workflowDateCompleted is Null      
                 Return DISTINCT n.workflowId as WorkflowID
                limit 100
               '''
        results,meta = run_cypher_query(query, {'teamId': teamId })
      if (len(results) ==0):
              return []
    #   Formatted_Results = [{"workflowName":row[0], "workflowDateDue": row[1], "WorkflowID" : row[2], "Num_Tasks": row[3]} for row in results]
      Formatted_Results = []
      for i, row in enumerate(results): 
         Next_task= await get_next_task(row[0],task_allowed_user,hasAccess)
         if Next_task !="Incorrect Input: Task, Workflow don't exist!, OR Workflow is already completed":
            Formatted_Results.append(Next_task)

        #  Formatted_Results.append(results)
        # Formatted_Results.append(await next_task(row[2],task_allowed_user,hasAccess))
      return  {"allWorkflows":Formatted_Results}
  else :
      return {"NOT AUTHENTICATED or Invalid Token"}













# Method to get all Tasks for a specific Workflow
@app.get("/all-tasks/workflow-id/{workflowId}", tags=["all-tasks"], responses = {
    
   200: {"description": "Ok","content": {
                            "application/json": {
                                "schema": {
                                    "type": "object",
                                    "properties": {
                                        "items": {
                                            "type": "array",
                                            "minItems": 0,
                                            "maxItems": 1000,
                                            "description": "This Array of Tasks in a workflow", 
                                            "items": {
                                                "type": "object",
                                               "properties": {
                                        "workflowId": {
                                            "type": "string",
                                            "description": "Workflow ID",
                                            "minLength": 1,
                                            "maxLength": 100
                                        },
                                        "taskDateDue": {
                                            "type": "string",
                                            "description": "task Due Date",
                                            "minLength": 1,
                                            "maxLength": 100
                                        },
                                        "sub": {
                                            "type": "string",
                                            "description": "Sub ID of the user APP",
                                            "minLength": 1,
                                            "maxLength": 100
                                        },
                                        "teamId": {
                                            "type": "string",
                                            "description": "Team ID of the user APP",
                                            "minLength": 1,
                                            "maxLength": 100
                                        },
                                        "taskDateCreated": {
                                            "type": "string",
                                            "description": "The date of the task creation",
                                            "minLength": 1,
                                            "maxLength": 100
                                        },
                                        "notes": {
                                            "type": "string",
                                            "description": "The notes of the task",
                                            "minLength": 1,
                                            "maxLength": 100
                                        },
                                        "taskAllowedUser": {
                                                        "type": "array",
                                                        "description": "List of the task allowed user",

                                                        "maxItems": 250,
                                                        "minItems": 1,

                                                        "items": {
                                                            "type": "string"
                                                        },
                                                    },
                                        "workflowDateDue": {
                                            "type": "string",
                                            "description": "Workflow Due Date",
                                            "minLength": 0,
                                            "maxLength": 100
                                        },
                                        "taskInput": {
                                            "type": "string",
                                            "description": "Initial data of the task ",
                                            "minLength": 0,
                                            "maxLength": 100
                                        },
                                        "taskDeliverable": {
                                            "type": "string",
                                            "description": "task Deliverables data",
                                            "minLength": 0,
                                            "maxLength": 100
                                        },
                                        "workflowDateCompleted": {
                                            "type": "string",
                                            "description": "Workflow Date Completed",
                                            "minLength": 0,
                                            "maxLength": 100
                                        },
                                        "taskIndex": {
                                            "type": "integer",
                                            "description": "Task Index",
                                            "format": "int64"
                                        },
                                        "taskSla": {
                                            "type": "integer",
                                            "description": "Task SLA",
                                            "format": "int64"
                                        },
                                        "workflowVersion": {
                                            "type": "integer",
                                            "description": "workflow version",
                                            "format": "int64"
                                        },
                                        "workflowName": {
                                            "type": "string",
                                            "description": "Workflow Name",
                                            "minLength": 0,
                                            "maxLength": 100
                                        },
                                        "taskName": {
                                            "type": "string",
                                            "description": "Task Name",
                                            "minLength": 0,
                                            "maxLength": 100
                                        }
                                    },
                                                "additionalProperties": False,
                                                "required": [
                                                    "workflowId",
                                                    "taskDateDue",
                                                    "workflowDateDue",
                                                    "taskName",
                                                    "taskIndex",
                                                    "workflowName"

                                                ]
                                            }
                                        }
                                    },
                                    "additionalProperties": False
                                }
                            }
                        }},
403: {"description": "Forbidden"}, 
404: {"description": "Not Found"}, 
401: {"description": "Unauthorized"}, 
415: {"description": "Unsupported Media Type"}, 
504: {"description": "Gateway Timeout"},   
400: {"description": "Ok","content": {
               "application/json": {
                 "schema": {
                   "$ref": "#/components/schemas/WorkflowData"
                 }
               }
             }},
   
})
async def all_tasks( request: Request, workflowId: str  = Path( description="The TeamID should be Passed here", regex='^[A-Za-z0-9]{1,32}$') , workflow_version : int= Query( None, description="The Workflow Version should be Passed here",  ge=1, le=10000), task_allowed_user: str= Query( None, description='''The Allowed user role should be Passed here. The syntax should follow this format: {"taskAllowedUser": ["role1","role2"]}''', regex="^.{1,1048}$"), hasAccess : dict= Depends(hasAccess) ):
  """
   Operation to get all the Tasks for a specific workflow (latest version). Input:  **Workflow ID**. Not if no User Roles are declaired and assigned during the creation of the workflow, passing data to *task_allowed_user* will not affect the outcome of the results 
  """  
  if hasAccess and hasAccess is not None:
      teamId , _ = hasAccess
      query_params = request.query_params
      keys_list = list(query_params.keys())
      for key in keys_list:
        if len(query_params.getlist(key))>1  :
            raise HTTPException(status_code=400, detail="Bad Request can not pass an array")      
      if task_allowed_user and task_allowed_user is not None:
         json_string = task_allowed_user
         try:
            task_allowed_user = json.loads(json_string)  
         except:
            raise HTTPException(status_code=400, detail="Wrong Json Syntax")
         try:
            task_allowed_user= task_allowed_user["taskAllowedUser"]
         except:
            print(task_allowed_user)
            raise HTTPException(status_code=400, detail="task_allowed_user Key was not provided, or key contains a typo")  
      if not workflow_version:
          if not task_allowed_user:
                # query= 'Match (n) WHERE n.workflowId=$workflowId AND n.teamId = $teamId Return n.workflowName AS workflowName,  n.workflowDateDue        as Workflow_DUE_DATE, n.taskName as taskName, n.taskDateDue as Task_Due_Date'
              query= '''Match (n:Task  {workflowId:$workflowId, teamId: $teamId}) 
                        WITH max(n.workflowVersion) as max
                        Match (n:Task  {workflowVersion : max, workflowId:$workflowId, teamId: $teamId })
                     
                      
                      Return n ORDER BY n.taskIndex'''
            
              results,meta = run_cypher_query(query, {'teamId': teamId , 'workflowId':workflowId })
              if (len(results) ==0):
                      raise HTTPException(status_code=404, detail="Incorrect Input")
            
              results = [item for sublist in results for item in sublist]
              return results
          elif task_allowed_user:
            query= '''Match (n:Task  {workflowId:$workflowId, teamId: $teamId}) 
                      WITH max(n.workflowVersion) as max
                      Match (n:Task  {workflowVersion : max, workflowId:$workflowId, teamId: $teamId })
                      WHERE   (ANY  (allowedUsers IN $taskAllowedUser Where  allowedUsers IN n.taskAllowedUser ))	OR (n.taskAllowedUser	 IS NULL OR size(n.taskAllowedUser	) = 0)
                   
                    
                     Return n ORDER BY n.taskIndex Asc'''
          
            results,meta = run_cypher_query(query, {'teamId': teamId , 'workflowId':workflowId, 'taskAllowedUser':task_allowed_user })
            if (len(results) ==0):
                    raise HTTPException(status_code=404, detail="Incorrect Input")
            results = [item for sublist in results for item in sublist]
            return  results
      elif workflow_version:
          if not task_allowed_user:
              query= '''Match (n) 
              
                      WHERE n.workflowId=$workflowId AND n.teamId = $teamId  AND n.workflowVersion = $workflowVersion
                      
                       Return n ORDER BY n.taskIndex Asc'''
        
              results,meta = run_cypher_query(query, {'teamId': teamId , 'workflowId':workflowId, 'workflowVersion':workflow_version })
              if (len(results) ==0):
                      raise HTTPException(status_code=404, detail="Incorrect Input")
        
              results = [item for sublist in results for item in sublist]
              return  results
          elif   task_allowed_user:
              
           query= '''Match (n) 
           
                   WHERE n.workflowId=$workflowId AND n.teamId = $teamId  AND n.workflowVersion = $workflowVersion AND ((ANY  (allowedUsers IN $taskAllowedUser Where  allowedUsers IN n.taskAllowedUser ))	OR (n.taskAllowedUser	 IS NULL OR size(n.taskAllowedUser	) = 0))
                   
                    Return n ORDER BY n.taskIndex Asc'''
     
           results,meta = run_cypher_query(query, {'teamId': teamId , 'workflowId':workflowId, 'workflowVersion':workflow_version,  'taskAllowedUser':task_allowed_user })
           if (len(results) ==0):
                #    return JSONResponse(status_code=404, content = {    "Message": "Incorrect Input"})
                raise HTTPException(status_code=404, detail="Incorrect Input")
           results = [item for sublist in results for item in sublist]
           return  results
  else:
    return {"NOT AUTHENTICATED or Invalid Token"}      



# Method to get the number of versions for a specific workflow
@app.get("/num-version/workflow-id/{workflowId}" , tags=["num-version"], responses = {
    
   "200": {
                        "description": "Ok",
                        "content": {
                            "application/json": {
                                "schema": {
                                    "type": "object",
                                    "properties": {
                                       
                                        "numVersions": {
                                            "type": "integer",
                                            "description": "Workflow Version number",
                                            "format": "int64"
                                      
                                    }},
                                    "additionalProperties": False
                                
                            }
                        }}
                    },
403: {"description": "Forbidden"}, 
404: {"description": "Not Found"}, 
401: {"description": "Unauthorized"}, 
415: {"description": "Unsupported Media Type"}, 
504: {"description": "Gateway Timeout"},   
   400: {"description": "Ok","content": {
               "application/json": {
                 "schema": {
                   "$ref": "#/components/schemas/WorkflowData"
                 }
               }
             }}
   
})
async def num_versions(request: Request, workflowId: str  = Path( description="The TeamID should be Passed here", regex='^[A-Za-z0-9]{1,32}$'), hasAccess : dict= Depends(hasAccess)):
  
    
  """
   Operation to get the number of versions for a specific workflow. Input:  **Workflow ID**  
  """  
  if hasAccess and hasAccess is not None:
      query_params = request.query_params
      keys_list = list(query_params.keys())
      for key in keys_list:
        if len(query_params.getlist(key))>1  :
            raise HTTPException(status_code=400, detail="Bad Request can not pass an array")
      teamId , _ = hasAccess
      query= '''Match (n:Task  {workflowId:$workflowId, teamId: $teamId}) 
                WITH max(n.workflowVersion) as max
              Return max'''

      results,meta = run_cypher_query(query, {'teamId': teamId , 'workflowId':workflowId })
      if (results[0][0] == None):
              raise HTTPException(status_code=404, detail="Incorrect Input")

      return {"numVersions": results[0][0]}
  else:
      return {"NOT AUTHENTICATED or Invalid Token"}      
 



# Method to get the the Task of a certain Workflow
@app.get("/get-task/workflow-id/{workflowId}/task-id/{taskIndex}" , tags=["task"], responses = {
    
   "200": {
                        "description": "Ok",
                        "content": {
                            "application/json": {
                                "schema": {
                                    "type": "object",
                                    "properties": {
                                        "workflowId": {
                                            "type": "string",
                                            "description": "Workflow ID",
                                            "minLength": 1,
                                            "maxLength": 100
                                        },
                                        "taskDateDue": {
                                            "type": "string",
                                            "description": "task Due Date",
                                            "minLength": 1,
                                            "maxLength": 100
                                        },
                                        "sub": {
                                            "type": "string",
                                            "description": "Sub ID of the user APP",
                                            "minLength": 1,
                                            "maxLength": 100
                                        },
                                        "teamId": {
                                            "type": "string",
                                            "description": "Team ID of the user APP",
                                            "minLength": 1,
                                            "maxLength": 100
                                        },
                                        "taskDateCreated": {
                                            "type": "string",
                                            "description": "The date of the task creation",
                                            "minLength": 1,
                                            "maxLength": 100
                                        },
                                        "notes": {
                                            "type": "string",
                                            "description": "The notes of the task",
                                            "minLength": 1,
                                            "maxLength": 100
                                        },
                                        "taskAllowedUser": {
                                                        "type": "array",
                                                        "description": "List of the task allowed user",

                                                        "maxItems": 250,
                                                        "minItems": 1,

                                                        "items": {
                                                            "type": "string"
                                                        },
                                                    },
                                        "workflowDateDue": {
                                            "type": "string",
                                            "description": "Workflow Due Date",
                                            "minLength": 0,
                                            "maxLength": 100
                                        },
                                        "taskInput": {
                                            "type": "string",
                                            "description": "Initial data of the task ",
                                            "minLength": 0,
                                            "maxLength": 100
                                        },
                                        "taskDeliverable": {
                                            "type": "string",
                                            "description": "task Deliverables data",
                                            "minLength": 0,
                                            "maxLength": 100
                                        },
                                        "workflowDateCompleted": {
                                            "type": "string",
                                            "description": "Workflow Date Completed",
                                            "minLength": 0,
                                            "maxLength": 100
                                        },
                                        "taskIndex": {
                                            "type": "integer",
                                            "description": "Task Index",
                                            "format": "int64"
                                        },
                                        "taskSla": {
                                            "type": "integer",
                                            "description": "Task SLA",
                                            "format": "int64"
                                        },
                                        "workflowVersion": {
                                            "type": "integer",
                                            "description": "workflow version",
                                            "format": "int64"
                                        },
                                        "workflowName": {
                                            "type": "string",
                                            "description": "Workflow Name",
                                            "minLength": 0,
                                            "maxLength": 100
                                        },
                                        "taskName": {
                                            "type": "string",
                                            "description": "Task Name",
                                            "minLength": 0,
                                            "maxLength": 100
                                        }
                                    },
                                    "additionalProperties": False
                                }
                            }
                        }
                    },
403: {"description": "Forbidden"}, 
404: {"description": "Not Found"}, 
401: {"description": "Unauthorized"}, 
415: {"description": "Unsupported Media Type"}, 
504: {"description": "Gateway Timeout"},   
    400: {"description": "Ok","content": {
                "application/json": {
                  "schema": {
                    "$ref": "#/components/schemas/WorkflowData"
                  }
                }
              }},
    
})
async def get_task( request: Request, workflowId: str  = Path( description="The TeamID should be Passed here", regex='^[A-Za-z0-9]{1,32}$'), taskIndex: int= Path( description="The Task ID should be Passed here",  ge=1, le=10000), workflow_version : int= Query( None, description="The Workflow Version should be Passed here", ge=1, le=10000), hasAccess : dict= Depends(hasAccess)):
 
  """
        Operation to get all the info of a specific task in a workflow (latest version). Input:  **Workflow ID**,**Task ID**  
  """  
  
  if hasAccess and hasAccess is not None:
      teamId , _ = hasAccess
      query_params = request.query_params
      keys_list = list(query_params.keys())
      for key in keys_list:
        if len(query_params.getlist(key))>1  :
            raise HTTPException(status_code=400, detail="Bad Request can not pass an array")
      if not workflow_version: 
        
          query= '''Match (n:Task  {workflowId:$workflowId, teamId:$teamId, taskIndex : $taskIndex }) 
                    WITH max(n.workflowVersion) as max
                    Match (n:Task  {workflowVersion : max, workflowId:$workflowId, teamId: $teamId, taskIndex : $taskIndex })          
                  Return n'''
        
          results,meta = run_cypher_query(query, {'teamId': teamId , 'workflowId':workflowId, 'taskIndex':taskIndex })
          if (len(results) ==0):
                  raise HTTPException(status_code=404, detail="Incorrect Input")
          results= results[0][0]

          return results
      elif workflow_version:
          """
          Operation to get all the info of a specific task and version in a workflow. Input:  **Workflow ID**,**Task ID**,  **Workflow Version** ,
          """  
          
            
          query= '''Match (n) 
                    
                  WHERE n.workflowId=$workflowId AND n.teamId = $teamId AND n.taskIndex = $taskIndex AND n.workflowVersion = $workflowVersion
                  
                  Return n'''

          results,meta = run_cypher_query(query, {'teamId': teamId , 'workflowId':workflowId, 'taskIndex':taskIndex, 'workflowVersion':workflow_version  })
          if (len(results) ==0):
                  raise HTTPException(status_code=404, detail="Incorrect Input")
          results= results[0][0]        
          return results
  else:
      return {"NOT AUTHENTICATED or Invalid Token"} 
    
 




# Method to start a task in a workflow
@app.get("/start-task/workflow-id/{workflowId}/task-id/{taskIndex}" , tags=["start-task"], responses = {
    
   "200": {
                        "description": "Ok",
                        "content": {
                            "application/json": {
                                "schema": {
                                    "type": "object",
                                    "properties": {
                                       
                                        "taskStartDate": {
                                            "type": "string",
                                            "description": "The start date of the task",
                                            "minLength": 0,
                                            "maxLength": 100
                                        }
                                      
                                    }, "additionalProperties": False}
                                    
                                }
                            }
                        }
                    ,
403: {"description": "Forbidden"}, 
404: {"description": "Not Found"}, 
401: {"description": "Unauthorized"}, 
415: {"description": "Unsupported Media Type"}, 
504: {"description": "Gateway Timeout"},
   400: {"description": "Ok","content": {
               "application/json": {
                 "schema": {
                   "$ref": "#/components/schemas/WorkflowData"
                 }
               }
             }},}
   
)
async def start_task( request: Request, workflowId: str  = Path( description="The TeamID should be Passed here", regex='^[A-Za-z0-9]{1,32}$'), taskIndex: int= Path( description="The Task ID should be Passed here" ,  ge=1, le=10000), hasAccess : dict= Depends(hasAccess)):

  """
   Operation to **Start** a task in a workflow (latest version). Input:  **Workflow ID**,**Task ID** Note: If Task is already started, operation will throw an error, and start date will not be updated!  
  """  
  if hasAccess and hasAccess is not None:
      teamId , _ = hasAccess
      query_params = request.query_params
      keys_list = list(query_params.keys())
      for key in keys_list:
        if len(query_params.getlist(key))>1  :
            raise HTTPException(status_code=400, detail="Bad Request can not pass an array")
      Startdate = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
      
      query= '''MATCH (t:Task {workflowId: $workflowId })-[NEXT_TASK]-(b)
              WITH max(t.workflowVersion) as max
              MATCH (t:Task {workflowVersion : max, workflowId:$workflowId, teamId: $teamId})
              WHERE (NOT ()-->(t) AND t.taskDateCompleted is null  AND t.taskDateStarted is null AND  (t.workflowId= $workflowId AND t.teamId =$teamId))
              OR (t.taskDateCompleted is null AND t.taskDateStarted is null AND (t.workflowId= $workflowId AND t.teamId =$teamId) AND ALL(m IN [(m)-->(t) | m] WHERE m.taskDateCompleted is NOT null))
            
              RETURN DISTINCT t.taskIndex as taskIndex

      '''
      results,meta = run_cypher_query(query, {'teamId': teamId , 'workflowId':workflowId})
      if (len(results) ==0):
              raise HTTPException(status_code=404, detail="Incorrect Input")
      Formatted_Results = [{"taskIndex":row[0]} for row in results]  

      if any(taskIndex in sublist for sublist in results):

      
          query= '''Match (n:Task  {workflowId:$workflowId}) 
          WITH max(n.workflowVersion) as max
          Match (n:Task  {workflowVersion : max,  workflowId:$workflowId, teamId: $teamId})
          WHERE n.workflowId=$workflowId AND n.teamId = $teamId AND n.taskIndex = $taskIndex 
          
          SET n.taskDateStarted = coalesce(n.taskDateStarted,$Startdate) 
          RETURN n.taskDateStarted'''
          results,meta = run_cypher_query(query, {'teamId': teamId , 'workflowId':workflowId, 'taskIndex':taskIndex , 'Startdate':Startdate })

          return {"taskStartDate": results[0][0] }
      else :
          raise HTTPException(status_code=404, detail="Incorrect Input")

      
  else:
      return {"NOT AUTHENTICATED or Invalid Token"} 
  
# Method to complete a task in a workflow
@app.get("/complete-task/workflow-id/{workflowId}/task-id/{taskIndex}", tags=["complete-task"], responses = {
    
  "200": {
                        "description": "Ok",
                        "content": {
                            "application/json": {
                                "schema": {
                                    "type": "object",
                                    "properties": {
                                       
                                        "taskCompletionDate": {
                                            "type": "string",
                                            "description": "The start date of the task",
                                            "minLength": 0,
                                            "maxLength": 100
                                        }
                                      
                                    } ,"additionalProperties": False}
                                   
                                }
                            }
        }
                    ,
403: {"description": "Forbidden"}, 
404: {"description": "Not Found"}, 
401: {"description": "Unauthorized"}, 
415: {"description": "Unsupported Media Type"}, 
504: {"description": "Gateway Timeout"},   
400: {"description": "Incorrect Input","content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/WorkflowData"
                }
              }
            }
  
}})
async def complete_task( request: Request, workflowId: str  = Path( description="The TeamID should be Passed here", regex='^[A-Za-z0-9]{1,32}$'), taskIndex: int= Path( description="The Task ID should be Passed here", ge=1, le=10000), task_completed_by: str =Query( None, description="The User completing the role should be passed here", regex="^[a-zA-Z0-9\s\-:_@.]{1,100}$"), hasAccess : dict= Depends(hasAccess) ):

  """
  Operation to **Complete** a task in a workflow (latest version). Input:  **Workflow ID**,**Task ID**  
  """  
  if hasAccess and hasAccess is not None:
      teamId , _ = hasAccess
      query_params = request.query_params
      keys_list = list(query_params.keys())
      for key in keys_list:
        if len(query_params.getlist(key))>1  :
            raise HTTPException(status_code=400, detail="Bad Request can not pass an array")
      if not task_completed_by:
        
          Completedate = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        #   Query to get a list of all next tasks
          query= '''MATCH (t:Task {workflowId:$workflowId})-[NEXT_TASK]-(b)
                  WITH max(t.workflowVersion) as max
                  MATCH (t:Task {workflowVersion : max, workflowId:$workflowId, teamId: $teamId})
                  WHERE (NOT ()-->(t) AND t.taskDateCompleted is null  AND (t.workflowId= $workflowId AND t.teamId =$teamId))
                  OR (t.taskDateCompleted is null AND (t.workflowId= $workflowId AND t.teamId =$teamId ) AND ALL(m IN [(m)-->(t) | m] WHERE m.taskDateCompleted is NOT null))
                
                  RETURN DISTINCT t.taskIndex as taskIndex
        
          '''
          results,meta = run_cypher_query(query, {'teamId': teamId , 'workflowId':workflowId})
          if (len(results) ==0):
              raise HTTPException(status_code=404, detail="Incorrect Input")

          Formatted_Results = [{"taskIndex":row[0]} for row in results]  
# loop across al next tasks and check if *taskIndex* passed is in that list
          if any(taskIndex in sublist for sublist in results):

        # Query to set that task to complete and taskDate started as well if date wasn't in there yet
              query= '''Match (n:Task  {workflowId:$workflowId}) 
                      WITH max(n.workflowVersion) as max
                      Match (n:Task  {workflowVersion : max})
                      WHERE n.workflowId=$workflowId AND n.teamId = $teamId AND n.taskIndex = $taskIndex  
                      
                      SET n.taskDateCompleted = $Completedate 
                      SET n.taskDateStarted = coalesce(n.taskDateStarted,$Completedate)'''
              results,meta = run_cypher_query(query, {'teamId': teamId , 'workflowId':workflowId, 'taskIndex':taskIndex , 'Completedate': Completedate })
            #   Query to check if there are any next tasks in the workflow
              query= '''MATCH (t:Task {workflowId:$workflowId})-[NEXT_TASK]-(b)
                      WITH max(t.workflowVersion) as max
                      MATCH (t:Task {workflowVersion : max, workflowId:$workflowId, teamId: $teamId})
                      WHERE (NOT ()-->(t) AND t.taskDateCompleted is null  AND (t.workflowId= $workflowId AND t.teamId =$teamId))
                      OR (t.taskDateCompleted is null AND (t.workflowId= $workflowId AND t.teamId =$teamId) AND ALL(m IN [(m)-->(t) | m] WHERE m.taskDateCompleted is NOT null))
                    
                      RETURN DISTINCT t.taskIndex as taskIndex, t.taskName as taskName, t.taskDateDue as Task_Due_Date
            
              '''
              results,meta = run_cypher_query(query, {'teamId': teamId , 'workflowId':workflowId})
              if (len(results) ==0):
                  #   If the previous query outputs no results (no more tasks to do, set workflowcompletion date)
                  query= '''Match (n:Task  {workflowId:$workflowId}) 
                          WITH max(n.workflowVersion) as max
                          Match (n:Task  {workflowVersion : max})
                          WHERE n.workflowId=$workflowId AND n.teamId = $teamId
                          
                          SET n.workflowDateCompleted = $Completedate 
                          '''
                         
                  results,meta = run_cypher_query(query, {'teamId': teamId , 'workflowId':workflowId, 'taskIndex':taskIndex , 'Completedate': Completedate })

              return {"taskDateCompleted": Completedate }
          else :
             raise HTTPException(status_code=404, detail="Incorrect Input")
            #   return {"Can't Complete Tasks out of order or Task is already completed"}
# does everything above except with setting the task_completed_by field
      elif task_completed_by:
            Completedate = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            
            query= '''MATCH (t:Task {workflowId:$workflowId})-[NEXT_TASK]-(b)
                    WITH max(t.workflowVersion) as max
                    MATCH (t:Task {workflowVersion : max, workflowId:$workflowId, teamId: $teamId})
                    WHERE (NOT ()-->(t) AND t.taskDateCompleted is null  AND (t.workflowId= $workflowId AND t.teamId =$teamId))
                    OR (t.taskDateCompleted is null AND (t.workflowId= $workflowId AND t.teamId =$teamId ) AND ALL(m IN [(m)-->(t) | m] WHERE m.taskDateCompleted is NOT null))
                  
                    RETURN DISTINCT t.taskIndex as taskIndex
          
            '''
            results,meta = run_cypher_query(query, {'teamId': teamId , 'workflowId':workflowId})
            if (len(results) ==0):
                    raise HTTPException(status_code=404, detail="Incorrect Input")
            Formatted_Results = [{"taskIndex":row[0]} for row in results]  

            if any(taskIndex in sublist for sublist in results):

          
                query= '''Match (n:Task  {workflowId:$workflowId}) 
                        WITH max(n.workflowVersion) as max
                        Match (n:Task  {workflowVersion : max})
                        WHERE n.workflowId=$workflowId AND n.teamId = $teamId AND n.taskIndex = $taskIndex  
                        
                        SET n.taskDateCompleted = $Completedate 
                        SET n.taskDateStarted = coalesce(n.taskDateStarted,$Completedate)
                        SET n.taskCompletedBy = $taskCompletedBy
                        '''
                results,meta = run_cypher_query(query, {'teamId': teamId , 'workflowId':workflowId, 'taskIndex':taskIndex , 'Completedate': Completedate, 'taskCompletedBy':task_completed_by  })
                
                query= '''MATCH (t:Task {workflowId:$workflowId})-[NEXT_TASK]-(b)
                        WITH max(t.workflowVersion) as max
                        MATCH (t:Task {workflowVersion : max, workflowId:$workflowId, teamId: $teamId})
                        WHERE (NOT ()-->(t) AND t.taskDateCompleted is null  AND (t.workflowId= $workflowId AND t.teamId =$teamId))
                        OR (t.taskDateCompleted is null AND (t.workflowId= $workflowId AND t.teamId =$teamId) AND ALL(m IN [(m)-->(t) | m] WHERE m.taskDateCompleted is NOT null))
                      
                        RETURN DISTINCT t.taskIndex as taskIndex, t.taskName as taskName, t.taskDateDue as Task_Due_Date
              
                '''
                results,meta = run_cypher_query(query, {'teamId': teamId , 'workflowId':workflowId})
                if (len(results) ==0):
                    
                    query= '''Match (n:Task  {workflowId:$workflowId}) 
                            WITH max(n.workflowVersion) as max
                            Match (n:Task  {workflowVersion : max})
                            WHERE n.workflowId=$workflowId AND n.teamId = $teamId 
                            
                            SET n.workflowDateCompleted = $Completedate 
                            '''
                           
                    results,meta = run_cypher_query(query, {'teamId': teamId , 'workflowId':workflowId, 'taskIndex':taskIndex , 'Completedate': Completedate })
                return {"taskDateCompleted": Completedate }
            else :
                raise HTTPException(status_code=404, detail="Incorrect Input")


                # return {"Can't Complete Tasks out of order or Task is already completed"}
  else:
      return {"NOT AUTHENTICATED or Invalid Token"} 
  
  



# Method to add data or notes to a task in a workflow  
@app.post("/add-data-or-notes", tags=["Add or Edit Data"], responses = {
    
 "200": {
                        "description": "Ok",
                        "content": {
                            "application/json": {
                                "schema": {
                                    "type": "object",
                                    "properties": {
                                        "workflowId": {
                                            "type": "string",
                                            "description": "Workflow ID",
                                            "minLength": 1,
                                            "maxLength": 100
                                        },
                                        "taskDateDue": {
                                            "type": "string",
                                            "description": "task Due Date",
                                            "minLength": 1,
                                            "maxLength": 100
                                        },
                                        "sub": {
                                            "type": "string",
                                            "description": "Sub ID of the user APP",
                                            "minLength": 1,
                                            "maxLength": 100
                                        },
                                        "teamId": {
                                            "type": "string",
                                            "description": "Team ID of the user APP",
                                            "minLength": 1,
                                            "maxLength": 100
                                        },
                                        "taskDateCreated": {
                                            "type": "string",
                                            "description": "The date of the task creation",
                                            "minLength": 1,
                                            "maxLength": 100
                                        },
                                        "notes": {
                                            "type": "string",
                                            "description": "The notes of the task",
                                            "minLength": 1,
                                            "maxLength": 100
                                        },
                                        "taskAllowedUser": {
                                                        "type": "array",
                                                        "description": "List of the task allowed user",

                                                        "maxItems": 250,
                                                        "minItems": 1,

                                                        "items": {
                                                            "type": "string"
                                                        },
                                                    },
                                        "workflowDateDue": {
                                            "type": "string",
                                            "description": "Workflow Due Date",
                                            "minLength": 0,
                                            "maxLength": 100
                                        },
                                        "taskInput": {
                                            "type": "string",
                                            "description": "Initial data of the task ",
                                            "minLength": 0,
                                            "maxLength": 100
                                        },
                                        "taskDeliverable": {
                                            "type": "string",
                                            "description": "task Deliverables data",
                                            "minLength": 0,
                                            "maxLength": 100
                                        },
                                        "workflowDateCompleted": {
                                            "type": "string",
                                            "description": "Workflow Date Completed",
                                            "minLength": 0,
                                            "maxLength": 100
                                        },
                                        "taskIndex": {
                                            "type": "integer",
                                            "description": "Task Index",
                                            "format": "int64"
                                        },
                                        "taskSla": {
                                            "type": "integer",
                                            "description": "Task SLA",
                                            "format": "int64"
                                        },
                                        "workflowVersion": {
                                            "type": "integer",
                                            "description": "workflow version",
                                            "format": "int64"
                                        },
                                        "workflowName": {
                                            "type": "string",
                                            "description": "Workflow Name",
                                            "minLength": 0,
                                            "maxLength": 100
                                        },
                                        "taskName": {
                                            "type": "string",
                                            "description": "Task Name",
                                            "minLength": 0,
                                            "maxLength": 100
                                        }
                                    },
                                    "additionalProperties": False
                                }
                            }
                        }
                    },
403: {"description": "Forbidden"}, 
404: {"description": "Not Found"}, 
401: {"description": "Unauthorized"}, 
415: {"description": "Unsupported Media Type"}, 
504: {"description": "Gateway Timeout"},   
 400: {"description": "Ok","content": {
             "application/json": {
               "schema": {
                 "$ref": "#/components/schemas/WorkflowData"
               }
             }
           }},
 
})



async def add_data_or_notes( data: Annotated[
 updateData, Body( ),
   ],hasAccess : dict= Depends(hasAccess)):
 
    
  """
  Operation to **Add** the User Input Data (Json) of a task in a workflow (latest version) or to **Add/Update** the notes of a task in a workflow (latest version). Input:  **Workflow ID**,**Task ID**  Note: If Input Data is initalized, this will overide it!  
  """
  
  if hasAccess and hasAccess is not None:
      teamId , _ = hasAccess
      raw_data = data.model_dump(exclude_unset=True)
      data.taskInput  = json.dumps(data.taskInput)
      data.taskDeliverable  = json.dumps(data.taskDeliverable)
      if  "taskInput" in raw_data and "notes"  in raw_data and "taskDeliverable" in raw_data:
          """
           Operation to **Add** the User Input Data of a task in a workflow (latest version). Input:  **Workflow ID**,**Task ID**  Note: If Input Data is initalized, this will overide it! 
          """    
          Updated = datetime.now().strftime('%Y-%m-%d %H:%M:%S')  
          data.notes =  Updated+ ": " + data.notes 
  
          query= '''Match (n:Task  {workflowId:$workflowId}) 
                  WITH max(n.workflowVersion) as max
                  Match (n:Task  {workflowVersion : max, workflowId:$workflowId, teamId: $teamId})
                  WHERE n.workflowId=$workflowId AND n.teamId = $teamId AND n.taskIndex = $taskIndex 
                 
                  
                  SET n.taskInput = $inputData, n.taskDeliverable = $taskDeliverable, n.notes = coalesce(n.notes +", ", "") + $notes
                  Return n'''
          results,meta = run_cypher_query(query, {'teamId': teamId , 'workflowId':data.workflowId, 'taskIndex':data.taskIndex , 'inputData':data.taskInput, 'taskDeliverable':data.taskDeliverable, 'notes':data.notes })
          if (len(results) ==0):
                  raise HTTPException(status_code=404, detail="Incorrect Input")
      
          """
           Operation to **Add** the User Input Data (Json) of a task in a workflow (latest version) or to **Add/Update** the notes of a task in a workflow (latest version). Input:  **Workflow ID**,**Task ID**  Note: If Input Data is initalized, this will overide it! 
         
          """    
            
        #   Updated = datetime.now().strftime('%Y-%m-%d %H:%M:%S')  
        #   data.notes =  Updated+ ": " + data.notes 
            
        #   query= '''Match (n{workflowId:$workflowId}) 
        #           WITH max(n.workflowVersion) as max
        #           Match (n:Task  {workflowVersion : max, workflowId:$workflowId, teamId: $teamId})
        #           WHERE n.workflowId=$workflowId AND n.teamId = $teamId AND n.taskIndex = $taskIndex 
                 
                  
        #           SET n.notes = coalesce(n.notes +", ", []) + $notes
        #           Return n.notes'''
        #   results,meta = run_cypher_query(query, {'teamId': teamId , 'workflowId':data.workflowId, 'taskIndex':data.taskIndex , 'notes':data.notes })
        #   if (len(results) ==0):
        #           return {"Incorrect Input: Task, Workflow, or TeamID don't exist!"}
          results= results[0][0]
          return results 
     
      if  "taskInput"  in raw_data and "notes"  in raw_data  :
          """
           Operation to **Add** the User Input Data of a task in a workflow (latest version). Input:  **Workflow ID**,**Task ID**  Note: If Input Data is initalized, this will overide it! 
          """    
          Updated = datetime.now().strftime('%Y-%m-%d %H:%M:%S')  
          data.notes =  Updated+ ": " + data.notes 
  
          query= '''Match (n:Task  {workflowId:$workflowId}) 
                  WITH max(n.workflowVersion) as max
                  Match (n:Task  {workflowVersion : max, workflowId:$workflowId, teamId: $teamId})
                  WHERE n.workflowId=$workflowId AND n.teamId = $teamId AND n.taskIndex = $taskIndex 
                 
                  
                  SET n.taskInput = $inputData, n.notes = coalesce(n.notes +", ", "") + $notes
                  Return n'''
          results,meta = run_cypher_query(query, {'teamId': teamId , 'workflowId':data.workflowId, 'taskIndex':data.taskIndex , 'inputData':data.taskInput , 'notes':data.notes })
          if (len(results) ==0):
                  raise HTTPException(status_code=404, detail="Incorrect Input")
      
          """
           Operation to **Add** the User Input Data (Json) of a task in a workflow (latest version) or to **Add/Update** the notes of a task in a workflow (latest version). Input:  **Workflow ID**,**Task ID**  Note: If Input Data is initalized, this will overide it! 
         
          """    
          results= results[0][0]
          return results
     
      if  "taskDeliverable"  in raw_data and "notes"  in raw_data:
          """
           Operation to **Add** the User Input Data of a task in a workflow (latest version). Input:  **Workflow ID**,**Task ID**  Note: If Input Data is initalized, this will overide it! 
          """    
          Updated = datetime.now().strftime('%Y-%m-%d %H:%M:%S')  
          data.notes =  Updated+ ": " + data.notes 
  
          query= '''Match (n:Task  {workflowId:$workflowId}) 
                  WITH max(n.workflowVersion) as max
                  Match (n:Task  {workflowVersion : max, workflowId:$workflowId, teamId: $teamId})
                  WHERE n.workflowId=$workflowId AND n.teamId = $teamId AND n.taskIndex = $taskIndex 
                 
                  
                  SET n.taskDeliverable = $taskDeliverable, n.notes = coalesce(n.notes +", ", "") + $notes
                  Return n'''
          results,meta = run_cypher_query(query, {'teamId': teamId , 'workflowId':data.workflowId, 'taskIndex':data.taskIndex , 'taskDeliverable':data.taskDeliverable , 'notes':data.notes })
          if (len(results) ==0):
                  raise HTTPException(status_code=404, detail="Incorrect Input")
      
          """
           Operation to **Add** the User Input Data (Json) of a task in a workflow (latest version) or to **Add/Update** the notes of a task in a workflow (latest version). Input:  **Workflow ID**,**Task ID**  Note: If Input Data is initalized, this will overide it! 
         
          """    
          results= results[0][0]
          return results

     
      if  "taskInput"  in raw_data and "taskDeliverable" in raw_data :
          """
           Operation to **Add** the User Input Data of a task in a workflow (latest version). Input:  **Workflow ID**,**Task ID**  Note: If Input Data is initalized, this will overide it! 
          """    
          Updated = datetime.now().strftime('%Y-%m-%d %H:%M:%S')  
            
          query= '''Match (n:Task  {workflowId:$workflowId}) 
                  WITH max(n.workflowVersion) as max
                  Match (n:Task  {workflowVersion : max, workflowId:$workflowId, teamId: $teamId})
                  WHERE n.workflowId=$workflowId AND n.teamId = $teamId AND n.taskIndex = $taskIndex 
                 
                  
                  SET n.taskInput = $inputData, n.taskDeliverable = $taskDeliverable
                  Return n'''
          results,meta = run_cypher_query(query, {'teamId': teamId , 'workflowId':data.workflowId, 'taskIndex':data.taskIndex , 'inputData':data.taskInput, 'taskDeliverable':data.taskDeliverable })
          if (len(results) ==0):
                  raise HTTPException(status_code=404, detail="Incorrect Input")
      
          """
           Operation to **Add** the User Input Data (Json) of a task in a workflow (latest version) or to **Add/Update** the notes of a task in a workflow (latest version). Input:  **Workflow ID**,**Task ID**  Note: If Input Data is initalized, this will overide it! 
         
          """    
          results= results[0][0]
          return results
     




      if "taskInput" in raw_data:   
          """
         Operation to **Add** the User Input Data (Json) of a task in a workflow (latest version) or to **Add/Update** the notes of a task in a workflow (latest version). Input:  **Workflow ID**,**Task ID**  Note: If Input Data is initalized, this will overide it! 
          """    
          Updated = datetime.now().strftime('%Y-%m-%d %H:%M:%S')  
            
          query= '''Match (n:Task  {workflowId:$workflowId}) 
                  WITH max(n.workflowVersion) as max
                  Match (n:Task  {workflowVersion : max, workflowId:$workflowId, teamId: $teamId})
                  WHERE n.workflowId=$workflowId AND n.teamId = $teamId AND n.taskIndex = $taskIndex 
                 
                  
                  SET n.taskInput = $inputData
                  Return n'''
          results,meta = run_cypher_query(query, {'teamId': teamId , 'workflowId':data.workflowId, 'taskIndex':data.taskIndex , 'inputData':data.taskInput })
          if (len(results) ==0):
                  raise HTTPException(status_code=404, detail="Incorrect Input")
          results= results[0][0]
          return results
      if "taskDeliverable" in raw_data :   
          """
         Operation to **Add** the User Input Data (Json) of a task in a workflow (latest version) or to **Add/Update** the notes of a task in a workflow (latest version). Input:  **Workflow ID**,**Task ID**  Note: If Input Data is initalized, this will overide it! 
          """    
          Updated = datetime.now().strftime('%Y-%m-%d %H:%M:%S')  
            
          query= '''Match (n:Task  {workflowId:$workflowId}) 
                  WITH max(n.workflowVersion) as max
                  Match (n:Task  {workflowVersion : max, workflowId:$workflowId, teamId: $teamId})
                  WHERE n.workflowId=$workflowId AND n.teamId = $teamId AND n.taskIndex = $taskIndex 
                 
                  
                  SET n.taskDeliverable = $taskDeliverable
                  Return n'''
          results,meta = run_cypher_query(query, {'teamId': teamId , 'workflowId':data.workflowId, 'taskIndex':data.taskIndex , 'taskDeliverable':data.taskDeliverable })
          if (len(results) ==0):
                  raise HTTPException(status_code=404, detail="Incorrect Input")
          results= results[0][0]
          return results  
      
      if "notes" in raw_data:
          """
           Operation to **Add** the User Input Data of a task in a workflow (latest version). Input:  **Workflow ID**,**Task ID**  Note: If Input Data is initalized, this will overide it! 
         
          """    
            
          Updated = datetime.now().strftime('%Y-%m-%d %H:%M:%S')  
          data.notes =  Updated+ ": " + data.notes 
            
          query= '''Match (n{workflowId:$workflowId}) 
                  WITH max(n.workflowVersion) as max
                  Match (n:Task  {workflowVersion : max, workflowId:$workflowId, teamId: $teamId})
                  WHERE n.workflowId=$workflowId AND n.teamId = $teamId AND n.taskIndex = $taskIndex 
                 
                  
                  SET n.notes = coalesce(n.notes +", ", "")  + $notes
                  Return n'''
          results,meta = run_cypher_query(query, {'teamId': teamId , 'workflowId':data.workflowId, 'taskIndex':data.taskIndex , 'notes':data.notes })
          if (len(results) ==0):
                  raise HTTPException(status_code=404, detail="Incorrect Input")
          results= results[0][0]
          return results
  else:
      return {"NOT AUTHENTICATED or Invalid Token"} 




# Method to add data or notes to a task in a workflow  
@app.post("/add-metadata", tags=["Add or Edit Metadata"], responses = {
    
 "200": {
                        "description": "Ok",
                        "content": {
                            "application/json": {
                                "schema": {
                                    "type": "object",
                                    "properties": {
                                        "workflowId": {
                                            "type": "string",
                                            "description": "Workflow ID",
                                            "minLength": 1,
                                            "maxLength": 100
                                        },
                                        "taskDateDue": {
                                            "type": "string",
                                            "description": "task Due Date",
                                            "minLength": 1,
                                            "maxLength": 100
                                        },
                                        "sub": {
                                            "type": "string",
                                            "description": "Sub ID of the user APP",
                                            "minLength": 1,
                                            "maxLength": 100
                                        },
                                        "teamId": {
                                            "type": "string",
                                            "description": "Team ID of the user APP",
                                            "minLength": 1,
                                            "maxLength": 100
                                        },
                                        "taskDateCreated": {
                                            "type": "string",
                                            "description": "The date of the task creation",
                                            "minLength": 1,
                                            "maxLength": 100
                                        },
                                        "notes": {
                                            "type": "string",
                                            "description": "The notes of the task",
                                            "minLength": 1,
                                            "maxLength": 100
                                        },
                                        "taskAllowedUser": {
                                                        "type": "array",
                                                        "description": "List of the task allowed user",

                                                        "maxItems": 250,
                                                        "minItems": 1,

                                                        "items": {
                                                            "type": "string"
                                                        },
                                                    },
                                        "workflowDateDue": {
                                            "type": "string",
                                            "description": "Workflow Due Date",
                                            "minLength": 0,
                                            "maxLength": 100
                                        },
                                        "taskInput": {
                                            "type": "string",
                                            "description": "Initial data of the task ",
                                            "minLength": 0,
                                            "maxLength": 100
                                        },
                                         "taskMetadata": {
                                            "type": "string",
                                            "description": "Initial Metadata of the task ",
                                            "minLength": 0,
                                            "maxLength": 100
                                        },
                                        "taskDeliverable": {
                                            "type": "string",
                                            "description": "task Deliverables data",
                                            "minLength": 0,
                                            "maxLength": 100
                                        },
                                        "workflowDateCompleted": {
                                            "type": "string",
                                            "description": "Workflow Date Completed",
                                            "minLength": 0,
                                            "maxLength": 100
                                        },
                                        "taskIndex": {
                                            "type": "integer",
                                            "description": "Task Index",
                                            "format": "int64"
                                        },
                                        "taskSla": {
                                            "type": "integer",
                                            "description": "Task SLA",
                                            "format": "int64"
                                        },
                                        "workflowVersion": {
                                            "type": "integer",
                                            "description": "workflow version",
                                            "format": "int64"
                                        },
                                        "workflowName": {
                                            "type": "string",
                                            "description": "Workflow Name",
                                            "minLength": 0,
                                            "maxLength": 100
                                        },
                                        "taskName": {
                                            "type": "string",
                                            "description": "Task Name",
                                            "minLength": 0,
                                            "maxLength": 100
                                        }
                                    },
                                    "additionalProperties": False
                                }
                            }
                        }
                    },
403: {"description": "Forbidden"}, 
404: {"description": "Not Found"}, 
401: {"description": "Unauthorized"}, 
415: {"description": "Unsupported Media Type"}, 
504: {"description": "Gateway Timeout"},   
400: {"description": "Ok","content": {
             "application/json": {
               "schema": {
                 "$ref": "#/components/schemas/WorkflowData"
               }
             }
           }},
 
})



async def add_metadata( data: Annotated[
 updateMetadata, Body( ),
   ],hasAccess : dict= Depends(hasAccess)):
 
    
  """
  Operation to **Add** the Metadata (Json) of a task in a workflow (latest version) Input:  **Workflow ID**,**Task ID**  ,**Metadata** Note: If MetaData is initalized, this will overide it!  
  """
  
  if hasAccess and hasAccess is not None:
      teamId , _ = hasAccess
      raw_data = data.model_dump(exclude_unset=True)
      data.taskMetadata  = json.dumps(data.taskMetadata)
   
      if "taskMetadata" in raw_data:   
          """
             Operation to **Add** the Metadata (Json) of a task in a workflow (latest version) Input:  **Workflow ID**,**Task ID**  ,**Metadata** Note: If MetaData is initalized, this will overide it!  
          """    
            
          query= '''Match (n:Task  {workflowId:$workflowId}) 
                  WITH max(n.workflowVersion) as max
                  Match (n:Task  {workflowVersion : max, workflowId:$workflowId, teamId: $teamId})
                  WHERE n.workflowId=$workflowId AND n.teamId = $teamId AND n.taskIndex = $taskIndex 
                 
                  
                  SET n.taskMetadata = $taskMetadata
                  Return n'''
          results,meta = run_cypher_query(query, {'teamId': teamId , 'workflowId':data.workflowId, 'taskIndex':data.taskIndex , 'taskMetadata':data.taskMetadata })
          if (len(results) ==0):
                  raise HTTPException(status_code=404, detail="Incorrect Input")
          results= results[0][0]
          return results
     
  else:
      return {"NOT AUTHENTICATED or Invalid Token"} 





# Method to add data or notes to a task in a workflow  
@app.post("/workflow-tags", tags=["Add or Overide Workflow Tags"], responses = {
    
 "200": {
                        "description": "Ok",
                        "content": {
                            "application/json": {
                                "schema": {
                                    "type": "object",
                                    "properties": {
                                        "workflowTags": {
                                            "type": "string",
                                            "description": "Workflow Tags",
                                            "minLength": 1,
                                            "maxLength": 100
                                        }
                                    },
                                    "additionalProperties": False
                                }
                            }
                        }
                    },
403: {"description": "Forbidden"}, 
404: {"description": "Not Found"}, 
401: {"description": "Unauthorized"}, 
415: {"description": "Unsupported Media Type"}, 
504: {"description": "Gateway Timeout"},   
400: {"description": "Ok","content": {
             "application/json": {
               "schema": {
                 "$ref": "#/components/schemas/WorkflowData"
               }
             }
           }},
 
})



async def worklfow_tags( data: Annotated[
 workflowTagsData, Body( ),
   ],hasAccess : dict= Depends(hasAccess)):
 
    
  """
         Operation to **Add** a workflow tag to a worklfow (only the latest version) Input:  **Workflow ID**,**WorkflowTag**  Note: If Input Data is initalized, this will overide it!  
  """
  
  if hasAccess and hasAccess is not None:
    teamId , _ = hasAccess  
    query= '''Match (n:Task  {workflowId:$workflowId}) 
            WITH max(n.workflowVersion) as max
            Match (n:Task  {workflowVersion : max, workflowId:$workflowId, teamId:$teamId})
            WHERE n.workflowId=$workflowId AND n.teamId = $teamId 
            
            
            SET n.workflowTags = $workflowTags
            Return n.workflowTags'''
    results,meta = run_cypher_query(query, {'teamId': teamId , 'workflowId':data.workflowId, 'workflowTags':data.workflowTags })
    if (len(results) ==0):
           raise HTTPException(status_code=404, detail="Incorrect Input")
            
    results= results[0][0]
    return {"workflowTags": results } 

     
  else:
      return {"NOT AUTHENTICATED or Invalid Token"}       

# Method to get the next Task in a workflow
@app.get("/next-task/workflow-id/{workflowId}", tags=["next-task"], responses = {
    
 200: {"description": "Ok","content": {
                            "application/json": {
                                "schema": {
                                    "type": "object",
                                    "properties": {
                                        "items": {
                                            "type": "array",
                                            "minItems": 0,
                                            "maxItems": 1000,
                                            "description": "This key will actually be the workflow ID of the array object inside of it.", 
                                            "items": {
                                                "type": "object",
                                                "properties": {

                                                    "workflowId": {
                                                        "type": "string",
                                                        "description": "Workflow ID",
                                                        "minLength": 0,
                                                        "maxLength": 100
                                                    },
                                                    "taskDateDue": {
                                                        "type": "string",
                                                        "description": "task Due Date",
                                                        "minLength": 0,
                                                        "maxLength": 100
                                                    },
                                                     "workflowDateDue": {
                                                        "type": "string",
                                                        "description": "Workflow Due Date",
                                                        "minLength": 0,
                                                        "maxLength": 100
                                                    },
                                                     "workflowDateCompleted": {
                                                        "type": "string",
                                                        "description": "Workflow Completion Date",
                                                        "minLength": 0,
                                                        "maxLength": 100
                                                    },
                                                    "taskIndex": {
                                                        "type": "integer",
                                                        "description": "Task ID",
                                                        "format": "int64"
                                                    },
                                                     "taskName": {
                                                        "type": "string",
                                                        "description": "Task Name",
                                                        "minLength": 0,
                                                        "maxLength": 100
                                                    },
                                                      "workflowName": {
                                                        "type": "string",
                                                        "description": "workflowName",
                                                        "minLength": 0,
                                                        "maxLength": 100
                                                    }
                                                },
                                                "additionalProperties": False,
                                                "required": [
                                                    "workflowId",
                                                    "taskDateDue",
                                                    "workflowDateDue",
                                                    "taskName",
                                                    "taskIndex",
                                                    "workflowName"

                                                ]
                                            }
                                        }
                                    },
                                    "additionalProperties": False
                                }
                            }
                        }},
403: {"description": "Forbidden"},
404: {"description": "Not Found"}, 
401: {"description": "Unauthorized"}, 
415: {"description": "Unsupported Media Type"}, 
504: {"description": "Gateway Timeout"},   
400: {"description": "Ok","content": {
             "application/json": {
               "schema": {
                 "$ref": "#/components/schemas/WorkflowData"
               }
             }
           }},
 
})


async def next_task( request: Request, workflowId: str  = Path( description="The TeamID should be Passed here", regex='^[A-Za-z0-9]{1,32}$'), task_allowed_user: str= Query( None, description='''The Allowed user role should be Passed here. The syntax should follow this format: {"taskAllowedUser": ["role1","role2"]}''', regex="^.{1,1048}$"), hasAccess : dict= Depends(hasAccess) ):
    """
      Operation to **Retrieve** the next task to do in a workflow (latest version). Input:  **Workflow ID**  
    """
    print(hasAccess)
    query_params = request.query_params
    keys_list = list(query_params.keys())
    for key in keys_list:
      if len(query_params.getlist(key))>1  :
        raise HTTPException(status_code=400, detail="Bad Request can not pass an array")    
    if task_allowed_user and task_allowed_user is not None:
         json_string = task_allowed_user
         try:
            task_allowed_user = json.loads(json_string)  
         except:
            raise HTTPException(status_code=400, detail="Wrong Json Syntax")
         try:
            task_allowed_user= task_allowed_user["taskAllowedUser"]
         except:
            print(task_allowed_user)
            raise HTTPException(status_code=400, detail="task_allowed_user Key was not provided, or key contains a typo")
    output = (await get_next_task(workflowId,task_allowed_user , hasAccess))
    if output == "Incorrect Input: Task, Workflow don't exist!, OR Workflow is already completed":
       raise HTTPException(status_code=404, detail="Incorrect Input")
    return output
# async 
# async def read_root( workflowId: str  = Path( description="The TeamID should be Passed here", regex='^[A-Za-z0-9]{1,32}$'), task_allowed_user: str= Query( None, description="The Allowed user role should be Passed here", regex="^[A-Za-z0-9]{1,32}$"), hasAccess : dict= Depends(hasAccess) ):
    
  
#   """
#    Operation to **Retrieve** the next task to do in a workflow (latest version). Input:  **Workflow ID**  
#   """
  
#   if hasAccess and hasAccess is not None:
#       teamId , _ = hasAccess
#       if task_allowed_user:
          
#           query= '''MATCH (t:Task {workflowId:$workflowId})-[NEXT_TASK]-(b)
#                   WITH max(t.workflowVersion) as max
#                   MATCH (t:Task {workflowVersion : max, workflowId:$workflowId, teamId: $teamId })
#                   WHERE (NOT ()-->(t) AND t.taskDateCompleted is null  AND (t.workflowId= $workflowId AND t.teamId =$teamId AND  ( $taskAllowedUser IN t.taskAllowedUser	 OR (t.taskAllowedUser	 IS NULL OR size(t.taskAllowedUser	) = 0))   ))
#                   OR (t.taskDateCompleted is null AND (t.workflowId= $workflowId AND t.teamId =$teamId AND  ($taskAllowedUser IN t.taskAllowedUser	 OR (t.taskAllowedUser	 IS NULL OR size(t.taskAllowedUser	) = 0)) ) AND ALL(m IN [(m)-->(t) | m] WHERE m.taskDateCompleted is NOT null))
                
#                   RETURN DISTINCT t.taskIndex as taskIndex, t.taskName as taskName, t.taskDateDue as Task_Due_Date
        
#           '''
#           results,meta = run_cypher_query(query, {'teamId': teamId , 'workflowId':workflowId, 'taskAllowedUser': task_allowed_user})
#           if (len(results) ==0):
#                   return {"Incorrect Input: Task, Workflow, or TeamID don't exist!"}
#           Formatted_Results = [{"taskIndex":row[0],"taskName":row[1], "Task_Due_Date": row[2]} for row in results]
        
#           return {"Next Task(s) is/are : ": Formatted_Results }
#       else:
#           query= '''MATCH (t:Task {workflowId:$workflowId})-[NEXT_TASK]-(b)
#                   WITH max(t.workflowVersion) as max
#                   MATCH (t:Task {workflowVersion : max, workflowId:$workflowId, teamId: $teamId})
#                   WHERE (NOT ()-->(t) AND t.taskDateCompleted is null  AND (t.workflowId= $workflowId AND t.teamId =$teamId))
#                   OR (t.taskDateCompleted is null AND (t.workflowId= $workflowId AND t.teamId =$teamId) AND ALL(m IN [(m)-->(t) | m] WHERE m.taskDateCompleted is NOT null))
                
#                   RETURN DISTINCT t.taskIndex as taskIndex, t.taskName as taskName, t.taskDateDue as Task_Due_Date
        
#           '''
#           results,meta = run_cypher_query(query, {'teamId': teamId , 'workflowId':workflowId})
#           if (len(results) ==0):
#                   return {"Incorrect Input: Task, Workflow, or TeamID don't exist!"}
#           Formatted_Results = [{"taskIndex":row[0],"taskName":row[1], "Task_Due_Date": row[2]} for row in results]
        
#           return {"Next Task(s) is/are : ": Formatted_Results }
#   else:
#       return {"NOT AUTHENTICATED or Invalid Token"} 
  
  
# Method to restart the Task 
@app.get("/restart-task/workflow-id/{workflowId}/task-id/{taskIndex}", tags=["restart-task"], responses = {
    
  "200": {
                        "description": "Ok",
                        "content": {
                            "application/json": {
                                "schema": {
                                    "type": "object",
                                    "properties": {
                                       
                                       "workflowVersion": {
                                            "type": "integer",
                                            "description": "Workflow Version number",
                                            "format": "int64"
                                      
                                    }
                                      
                                    },
                                    "additionalProperties": False
                                }
                            }
                        }
                    },
403: {"description": "Forbidden"}, 
404: {"description": "Not Found"}, 
401: {"description": "Unauthorized"}, 
415: {"description": "Unsupported Media Type"}, 
504: {"description": "Gateway Timeout"},   
400: {"description": "Ok","content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/WorkflowData"
                }
              }
            }},
  
})
async def restart_task( request: Request, workflowId: str  = Path( description="The TeamID should be Passed here", regex='^[A-Za-z0-9]{1,32}$'), taskIndex: int= Path( description="The Task ID should be Passed here", ge=1, le=10000), hasAccess : dict= Depends(hasAccess)):

    
  """
   Operation to **Redo a task** in a workflow sets completed date to null and creates a new workflow version with that after . Input:  **Workflow ID**,**Task ID** NOTE: Even if input Task is not started/completed, a new version will be created!  
  """    
  if hasAccess and hasAccess is not None:
    teamId , _ = hasAccess
    query_params = request.query_params
    keys_list = list(query_params.keys())
    for key in keys_list:
        if len(query_params.getlist(key))>1  :
            raise HTTPException(status_code=400, detail="Bad Request can not pass an array")    
    query= '''Match (n:Task  {workflowId:$workflowId}) 
              WITH max(n.workflowVersion) as max
              Match (n:Task  {workflowVersion : max, workflowId:$workflowId, teamId: $teamId})
            WHERE n.workflowId=$workflowId AND n.teamId = $teamId AND n.taskIndex = $taskIndex  AND n.taskDateCompleted is NOT NULL
            
            Return n'''

    results,meta = run_cypher_query(query, {'teamId': teamId , 'workflowId':workflowId, 'taskIndex':taskIndex })
    if (len(results) ==0):
            raise HTTPException(status_code=404, detail="Incorrect Input")
      
  
    query= '''Match (n:Task  {workflowId:$workflowId}) 
                       WITH max(n.workflowVersion) as max
                       Match (n:Task  {workflowVersion : max})
                       WHERE n.workflowId=$workflowId AND n.teamId = $teamId
                       
                       SET n.workflowDateCompleted =  NULL
                       '''
                      
    results,meta = run_cypher_query(query, {'teamId': teamId , 'workflowId':workflowId  })
    # query for patching only last task
    query =''' 
  MATCH  (n:Task {workflowId:$workflowId, teamId:$teamId })

  WITH max(n.taskIndex) as MaxID
  Match (n:Task  {workflowId:$workflowId, teamId:$teamId})
  WHERE n.taskIndex =$taskIndex AND n.taskIndex = MaxID
  Match (n:Task  {workflowId:$workflowId, teamId:$teamId})
  WITH max(n.workflowVersion) as MaxVal
  MATCH (t:Task {workflowId:$workflowId, teamId:$teamId})
  WHERE t.workflowVersion= MaxVal  AND (NOT ()-->(t) )
  MATCH path = (t)-[:NEXT_TASK*]->(node)
  WITH t,  collect(path) as paths
  CALL apoc.refactor.cloneSubgraphFromPaths(paths)
  YIELD  output
  SET output.workflowVersion = output.workflowVersion + 1
  WITH output as output2, max(output.taskIndex) as TaskIdMAx
  MATCH (output2)
  WHERE output2.taskIndex = $taskIndex AND output2.taskIndex =TaskIdMAx
  SET output2.taskDateCompleted = NULL
  SET output2.taskDateStarted = NULL
  SET output2.taskCompletedBy = NULL
  RETURN  output2.workflowVersion LIMIT 1
    
    '''
    results,meta = run_cypher_query(query, {'teamId': teamId , 'workflowId':workflowId, 'taskIndex' : taskIndex})
    if (len(results) ==0):
       
       
      # query for patching evertyhing but last task
        query= '''MATCH  (n:Task {workflowId:$workflowId, teamId:$teamId })
                  WITH max(n.workflowVersion) as MaxVal 
                  MATCH (t:Task {workflowId:$workflowId, teamId:$teamId})
                  WHERE t.workflowVersion =MaxVal AND (NOT ()-->(t) )
                  MATCH path = (t)-[:NEXT_TASK*]->(node)
                  WITH t,  collect(path) as paths
                  CALL apoc.refactor.cloneSubgraphFromPaths(paths)
                  YIELD  output
                  SET output.workflowVersion = output.workflowVersion + 1
                  WITH output as output2
                  MATCH z=(output2 )-[*]->(finish)
                  WHERE   output2.taskIndex = $taskIndex
                  FOREACH (t IN nodes(z) | SET t.taskDateCompleted = NULL, t.taskDateStarted = NULL, t.taskCompletedBy = NULL)
                  RETURN Distinct  output2.workflowVersion LIMIT 1
      
        '''
        results,meta = run_cypher_query(query, {'teamId': teamId , 'workflowId':workflowId, 'taskIndex' : taskIndex})
        if (len(results) ==0):
                raise HTTPException(status_code=404, detail="Incorrect Input")
        
        
        
        return {" workflowVersion: ": results[0][0] }
    else: return {"workflowVersion": results[0][0]}
  else:
    return {"NOT AUTHENTICATED or Invalid Token"} 
  
 

       





@app.post("/new-workflow", tags=["new-workflow"],   responses = {
    
  "200": {
                        "description": "Ok",
                        "content": {
                            "application/json": {
                                "schema": {
                                    "type": "object",
                                    "properties": {
                                       
                                        "workflowId": {
                                            "type": "string",
                                            "description": "The Workflow ID of the newly created Workflow",
                                            "minLength": 0,
                                            "maxLength": 100
                                        }
                                      
                                    },
                                    "additionalProperties": False
                                }
                            }
                        }
                    },
403: {"description": "Forbidden"}, 
404: {"description": "Not Found"}, 
401: {"description": "Unauthorized"}, 
415: {"description": "Unsupported Media Type"}, 
504: {"description": "Gateway Timeout"}, 
404: {"description": "Not Found"}, 
401: {"description": "Unauthorized"}, 
415: {"description": "Unsupported Media Type"}, 
504: {"description": "Gateway Timeout"},   
 400: {"description": "Ok","content": {
             "application/json": {
               "schema": {
                 "$ref": "#/components/schemas/WorkflowData"
               }
             }
           }},
 
}
)
async def new_workflow(  workflow: Annotated[
WorkflowData, Body(  ),
   Field()],
  tasks: Annotated[List[TaskData] ,
      
      
      Body( description=  'Task Data Examples'
      ),
  Field(description='Task Data Examples', max_items =100000, min_items=1 )] , hasAccess : dict= Depends(hasAccess)):
    
    
    """
     Operation to **Create a workflow**. Input: **Json Body** 
    """  
    if hasAccess and hasAccess is not None:
        teamId,sub = hasAccess
        #getting number of total nodes and creating a UUID for the workflow ID
        num_nodes=getNodeCount()
        num_nodes +=1
        uniqueUUID= generateUUID(num_nodes)
        
        # Creating a temporary map where we store temp store the TASK IDS. This is first used to check if the connection value lists are using valid TASK Ids passed 
        # This is then used later in the code to instead of fetch from the DB the taskIndexs for creating relationships, we already have the task ids and nodes to establish connections O(1)
        created_nodes = {}
        
     # Creating a map where we store Connection relationship between nodes. 
        connection = {}
        
     #The next for loop is used to populate the connection map wih connections, and populate the temporary maps where we store TASK IDS
        for node_data in tasks:
            if node_data.taskIndex in created_nodes:
                # return {"ERROR: ALL TASKS SHOULD HAVE DIFFERENT IDS!"}
                raise HTTPException(status_code=404, detail="ERROR: ALL TASKS SHOULD HAVE DIFFERENT IDS!")

            created_nodes[node_data.taskIndex] =1
            if node_data.connectsTo is not None:
                connection[node_data.taskIndex] = node_data.connectsTo
            

         # The next for loops are all validation checks to make sure all Task IDS are different, and that Task IDs created match TaskIds in the conenections

        # The next for loops are all validation checks to make sure all Task IDS are different, and that Task IDs created match TaskIds in the conenections
       
        if not all(key in created_nodes.keys() for key in connection.keys()):
        #    return {"CONNECTIONS IDS AND TASK IDS DON't MATCH"} 
           raise HTTPException(status_code=404, detail="CONNECTIONS IDS AND TASK IDS DON't MATCH") 
        # print (connection.values())
       # condition 2: check if keys of dict1 are present as values in dict2
        for key, values in connection.items():
          # Check if all values for the current key are present as keys in largedictionary
          for value in values:
            if value not in created_nodes:
              # print(f"Value '{value}' for key '{key}' not found in TASKIDS") 
            #   return {"CONNECTIONS VALUES AND TASK IDS DON't MATCH"}  
              raise HTTPException(status_code=404, detail="CONNECTIONS VALUES AND TASK IDS DON't MATCH")
        for key in created_nodes.keys():
            if key not in connection.keys() :
                if not any(key in values for values in connection.values()):
                    # return {"not all Task IDs are represented as Connection Values", key}
                    raise HTTPException(status_code=404, detail="not all Task IDs are represented as Connection Values")
                
        # For loop to create tasks from Json 
        for node_data in tasks:
              
                new_node = Task(  taskAllowedUser= node_data.taskAllowedUser , sub=sub, teamId=teamId, workflowId=uniqueUUID, workflowVersion= 1,  workflowName=workflow.workflowName, workflowDateDue =datetime.strptime(workflow.workflowDateDue       , "%Y-%m-%d %H:%M:%S"), taskName=node_data.taskName,  taskDateDue=datetime.strptime(node_data.taskDateDue, "%Y-%m-%d %H:%M:%S"), taskDateCreated = str(datetime.now().strftime('%Y-%m-%d %H:%M:%S')), notes = node_data.notes , taskSla=node_data.taskSla, taskInput=node_data.taskInput, taskMetadata=node_data.taskMetadata, workflowTags=workflow.workflowTags, taskIndex=node_data.taskIndex).save()
                
                new_node.save()
                created_nodes[new_node.taskIndex]=new_node
        

        # For loop to create Connections from Json 

        for from_taskIndex, to_taskIndexs in connection.items():
            from_task = created_nodes.get(from_taskIndex)
            if from_taskIndex:
                for to_taskIndex in to_taskIndexs:
                    to_task= created_nodes.get(to_taskIndex)
                    from_task.NextTask.connect(to_task)
        # message = "message:" "Tasks are created and connected successfully, Workflow ID: " + uniqueUUID
        return {"workflowId":uniqueUUID}
    else:
        return {"NOT AUTHENTICATED or Invalid Token"} 
