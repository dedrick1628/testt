from fastapi import FastAPI
from fastapi.openapi.utils import get_openapi
from fastapi import FastAPI, Depends, HTTPException, APIRouter, FastAPI, HTTPException, Body, Query, Path
from utils.authentication import hasAccess
from utils.authenv import outputenv

# app = FastAPI(openapi_tags=tags_metadata)

# these are the tags visible to the User seeing the API docs

app = FastAPI( dependencies=[ Depends(hasAccess)])

def custom_openapi():
    if app.openapi_schema:
        return app.openapi_schema
    openapi_schema = get_openapi(
        title="Workflow Executor API",
        version="1.0.0",
        openapi_version="3.0.3",


        # summary="This is a custom API to CRUD workflows and tasks and traverse the workflow as well",
        description="This is a custom API to create and manage workflows and tasks and traverse the workflow as well. This api will store, and establishes version control when user needs to *restart* a task",
       
        routes=app.routes,
    )
    openapi_schema["info"] = {
        
        "title" :"BPMS",
         "version":"1.0.0",

         "contact":{
      "name":"SSG API Workflow Support",
      "url":"http://ssg.verizon.com/web/not/created/yet",
      "email":"mark.farid@verizon.com"
    },
         "description":"This is a custom API to create and manage workflows and tasks and traverse the workflow as well. This api will store, and establishes version control when user needs to *restart* a task",
        
         
         "x-vz-audience": "verizon-private",
         "x-vz-experience":True
        
        
    }
    openapi_schema["security"] = [
        {
            "Oauth2ClientCredentials": [
                "readOnly"
            ]
        }
    ]
    
    openapi_schema["servers"] = [{
      "url": outputenv.sever,
        "description": "API server"
        
        }]
#removing code 422 and replacing it with 400 since 422 isn't supported yet by FirstAPi
#removing and reading code 200 to change the description "successful to Ok" and remove the schema of the response 
    for path in openapi_schema["paths"]:
        for method in openapi_schema["paths"][path]:
            responses = openapi_schema["paths"][path][method]["responses"]
#             if "200" in responses and (path != "/all-workflows") and (path != "/all-workflows/next-task") and (path != "/add-data-or-notes"):
#                 print(path)
#                 responses.pop("200")
#                 responses["200"] = {
#                    "description": "Ok",
#     "content": {
#       "application/json": {
#         "schema": {
#           "type": "object",
#           "properties": {
#             "items": {
#               "type": "string",
#               "maxLength": 250,
#               "minLength": 1,
#               "description": "Ok"
#             }
#           }
#         }
#       }
#     }
#   }
            if "422" in responses:
                responses.pop("422")
                responses["400"] = {
                    
                    "description":"Bad Request"
                    }
        
                
    # for path in openapi_schema["paths"]:
    #      # for method in openapi_schema["paths"][path]:
    #          if "security" in path:
    #              path.pop("security")
                 
    for path in openapi_schema["paths"].values():
        for data in path.values():
            # data.pop("security")
            for method in path.values():       
                method.pop("security")
                
                
           # Fixing the  paths to include dashes inside the parameter name
    paths = openapi_schema.get("paths", {})
    if '/all-workflows' in paths:
        paths['/all-workflows'] = paths['/all-workflows']
        # paths.pop('/all-workflows')
    if '/all-workflows/next-task' in paths:
        paths['/all-workflows/next-task'] = paths['/all-workflows/next-task']
        # paths.pop('/all-workflows')
        
        
    if '/all-tasks/workflow-id/{workflowId}' in paths:
        paths['/all-tasks/workflow-id/{workflow-id}'] = paths['/all-tasks/workflow-id/{workflowId}']
        paths.pop('/all-tasks/workflow-id/{workflowId}')
        
    if '/num-version/workflow-id/{workflowId}' in paths:
        paths['/num-version/workflow-id/{workflow-id}'] = paths['/num-version/workflow-id/{workflowId}']
        paths.pop('/num-version/workflow-id/{workflowId}')    

    if '/get-task/workflow-id/{workflowId}/task-id/{taskIndex}' in paths:
        paths['/get-task/workflow-id/{workflow-id}/task-id/{task-id}'] = paths['/get-task/workflow-id/{workflowId}/task-id/{taskIndex}']
        paths.pop('/get-task/workflow-id/{workflowId}/task-id/{taskIndex}')  
        
        
    if '/start-task/workflow-id/{workflowId}/task-id/{taskIndex}' in paths:
        paths['/start-task/workflow-id/{workflow-id}/task-id/{task-id}'] = paths['/start-task/workflow-id/{workflowId}/task-id/{taskIndex}']
        paths.pop('/start-task/workflow-id/{workflowId}/task-id/{taskIndex}')   

    if '/complete-task/workflow-id/{workflowId}/task-id/{taskIndex}' in paths:
        paths['/complete-task/workflow-id/{workflow-id}/task-id/{task-id}'] = paths['/complete-task/workflow-id/{workflowId}/task-id/{taskIndex}']
        paths.pop('/complete-task/workflow-id/{workflowId}/task-id/{taskIndex}')   

    # if '/edit-notes/workflow-id/{workflowId}/task-id/{taskIndex}/notes/{notes}' in paths:
    #     paths['/edit-notes/workflow-id/{workflow-id}/task-id/{task-id}'] = paths['/edit-notes/workflow-id/{workflowId}/task-id/{taskIndex}/notes/{notes}']
    #     paths.pop('/edit-notes/workflow-id/{workflowId}/task-id/{taskIndex}/notes/{notes}')   


    if '/add-data-or-notes/workflow-id/{workflowId}/task-id/{taskIndex}' in paths:
        paths['/add-data/workflow-id/{workflow-id}/task-id/{task-id}'] = paths['/add-data-or-notes/workflow-id/{workflowId}/task-id/{taskIndex}']
        paths.pop('/add-data-or-notes/workflow-id/{workflowId}/task-id/{taskIndex}')   

    if '/add-metadata/workflow-id/{workflowId}/task-id/{taskIndex}' in paths:
        paths['/add-metadata/workflow-id/{workflow-id}/task-id/{task-id}'] = paths['/add-metadata/workflow-id/{workflowId}/task-id/{taskIndex}']
        paths.pop('/add-metadata/workflow-id/{workflowId}/task-id/{taskIndex}')           
        
    if '/workflow-tags/workflow-id/{workflowId}' in paths:
        paths['/workflow-tags/workflow-id/{workflow-id}/task-id/{task-id}'] = paths['/workflow-tags/workflow-id/{workflowId}']
        paths.pop('/workflow-tags/workflow-id/{workflowId}')   


    if '/next-task/workflow-id/{workflowId}' in paths:
        paths['/next-task/workflow-id/{workflow-id}'] = paths['/next-task/workflow-id/{workflowId}']
        paths.pop('/next-task/workflow-id/{workflowId}')   

    if '/restart-task/workflow-id/{workflowId}/task-id/{taskIndex}' in paths:
        paths['/restart-task/workflow-id/{workflow-id}/task-id/{task-id}'] = paths['/restart-task/workflow-id/{workflowId}/task-id/{taskIndex}']
        paths.pop('/restart-task/workflow-id/{workflowId}/task-id/{taskIndex}')   

    # Fixing the parameters to be dashes instead of camel Case 

    for path in openapi_schema["paths"].values():
        for data in path.values():
            for method in path.values():
                for parameter in method.get("parameters", []):
                    if parameter["name"] == "teamId":
                            parameter["name"] = "client-id"  # Rename to "name" in OpenAPI schema
            #     parameters.pop("teamId")
                    if parameter["name"] == "workflowId":
                            parameter["name"] = "workflow-id"  # Rename to "name" in OpenAPI schema
            #     parameters.pop("teamId")
                    if parameter["name"] == "taskIndex":
                            parameter["name"] = "task-id"  # Rename to "name" in OpenAPI schema
            #     parameters.pop("teamId")
                    if parameter["name"] == "inputData":
                            parameter["name"] = "input-data"  # Rename to "name" in OpenAPI schema
            #     parameters.pop("teamId")
    
    
    
  
    
    # removing the JsonvAlue schema since it causes errors    
    schemas = openapi_schema["components"]["schemas"]

    if 'JsonValue' in schemas:
        schemas.pop("JsonValue")
       
    
    # substituting the old properties of the below schemas to be of type object instead of jsonvalue
    schemas= openapi_schema["components"]["schemas"]["TaskData"]["properties"]
    schemas["taskInput"] =  {
	 "type": "object",
		"description": "taskInput",

     "properties": {
       "items": {
         "type": "string",
         "maxLength": 250,
         "minLength": 1,
         "description": "Ok"
       }
     }
	}
    schemas= openapi_schema["components"]["schemas"]["TaskData"]["properties"]
    schemas["taskMetadata"] =  {
	 "type": "object",
		"description": "taskMetadata",

     "properties": {
       "items": {
         "type": "string",
         "maxLength": 250,
         "minLength": 1,
         "description": "Ok"
       }
     }
	}
    
    schemas= openapi_schema["components"]["schemas"]["TaskData"]["properties"]
    schemas["taskDeliverable"] =  {
	 "type": "object",
		"description": "taskDeliverable",

    "properties": {
      "items": {
        "type": "string",
        "maxLength": 250,
        "minLength": 1,
        "description": "Ok"
      }
    }
}

    
    schemas= openapi_schema["components"]["schemas"]["updateData"]["properties"]
    schemas["taskInput"]=  {
	 "type": "object",
		"description": "taskInput",

     "properties": {
       "items": {
         "type": "string",
         "maxLength": 250,
         "minLength": 1,
         "description": "Ok"
       }
     }
	}  

    schemas= openapi_schema["components"]["schemas"]["updateData"]["properties"]
    schemas["taskDeliverable"]=  {
	 "type": "object",
		"description": "taskDeliverable",

     "properties": {
       "items": {
         "type": "string",
         "maxLength": 250,
         "minLength": 1,
         "description": "Ok"
       }
     }
	}
    schemas= openapi_schema["components"]["schemas"]["updateData"]["properties"]
    schemas["taskMetadata"]=  {
	 "type": "object",
		"description": "taskMetadata",

     "properties": {
       "items": {
         "type": "string",
         "maxLength": 250,
         "minLength": 1,
         "description": "Ok"
       }
     }
	}      
    schemas= openapi_schema["components"]["schemas"]["updateMetadata"]["properties"]
    schemas["taskMetadata"]=  {
	 "type": "object",
		"description": "taskMetadata",

     "properties": {
       "items": {
         "type": "string",
         "maxLength": 250,
         "minLength": 1,
         "description": "Ok"
       }
     }
	} 
    openapi_schema["tags"] = [
        {
            "name": "all-workflows",
            "description": "Operation to get all the Workflows for a Team.  ",
        },
        {
            "name": "all-workflows/next-task",
            "description": "Operation to get all the Workflows and their Next Task for a Team.  ",
        },
        {
            "name": "all-tasks",
            "description": "Operation to get all the Tasks for a specific workflow (latest version). Input:  **Workflow ID**  ",
        },
        
        {
            "name": "num-version",
            "description": "Operation to get the number of versions for a specific workflow. Input:  **Workflow ID** ",
        },
        {
            "name": "task",
            "description": "Operation to get all the info of a specific task in a workflow (latest version). Input:  **Workflow ID**,**Task ID**  ",
        },
        
        {
            "name": "start-task",
            "description": "Operation to **Start** a task in a workflow (latest version). Input:  **Workflow ID**,**Task ID** Note: If Task is already started, operation will return first time task was started, and start date will not be updated! ",
        },
        {
            "name": "complete-task",
            "description": "Operation to **Complete** a task in a workflow (latest version). Input:  **Workflow ID**,**Task ID**  ",
        },
        
        
        
    
        
        
        {
            "name": "next-task",
            "description": "Operation to **Retrieve** the next task to do in a workflow (latest version). Input:  **Workflow ID**  ",
        },
        
        {
            "name": "restart-task",
            "description": "Operation to **Redo a task** in a workflow sets completed date to null and creates a new workflow version with that after . Input:  **Workflow ID**,**Task ID** NOTE: Even if input Task is not started/completed, a new version will be created! ",
        },
        
        {
            "name": "new-workflow",
            "description": "Operation to **Create a workflow**. Input: **Json Body**  ",
        }
        
        ]
       
    # removing schemas that cause issues    
    if "components" in openapi_schema and "schemas" in openapi_schema["components"]:
         openapi_schema["components"]["schemas"].pop("ValidationError")
         openapi_schema["components"]["schemas"].pop("HTTPValidationError")

    app.openapi_schema = openapi_schema
    return app.openapi_schema
    
    schema_for_iteration = deepcopy(openapi_schema)
    openapi_schema["paths"] = {}
    for path, path_definition in schema_for_iteration["paths"].items():
            list_of_path_params_with_underscores = re.findall("{([a-zA-Z_]*)}", path)
            if list_of_path_params_with_underscores:
                # Change the 'path' key and replace _ with -
                new_path = path.replace("_", "-")
                openapi_schema["paths"][new_path] = schema_for_iteration["paths"][path]
                # For each path param with underscores, changes the parameter name
                for path_param in list_of_path_params_with_underscores:
                    new_path_param = path_param.replace("_", "-")
                    for http_verb, http_verb_definition in path_definition.items():
                        for index, param in enumerate(http_verb_definition["parameters"]):
                            if param["name"] == path_param:
                                openapi_schema["paths"][new_path][http_verb]["parameters"][
                                    index
                                ]["name"] = new_path_param
            else:
                # If there are no path params with underscores, take the original definition
                openapi_schema["paths"][path] = schema_for_iteration["paths"][path]
                
app.openapi = custom_openapi
