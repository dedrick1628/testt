import json
import OasSpec
from utils.authentication import hasAccess
from routersUtils.dbquery import run_cypher_query
from routersUtils.nexttaskhelper import get_next_task

# Imporatant imports to get the properties used to generate the Task Class
from fastapi import Request
from datetime import datetime

from fastapi import FastAPI, Depends, HTTPException, APIRouter, FastAPI, HTTPException, Query, Path

import json


router = APIRouter()

app = OasSpec.app
## SHOULD BE THEIR OWN CLASS INHERITED BY ALL ENDPOINTS

# this is used to load the custom openapi json to fit the FirstAPI guidelines












@router.get("/start-task/workflow-id/{workflowId}/task-id/{taskIndex}" , tags=["start-task"], responses = {
    
   "200": {
                        "description": "Ok",
                        "content": {
                            "application/json": {
                                "schema": {
                                    "type": "object",
                                    "properties": {
                                       
                                        "taskStartDate": {
                                            "type": "string",
                                            "description": "The start date of the task",
                                            "minLength": 0,
                                            "maxLength": 100
                                        }
                                      
                                    }, "additionalProperties": False}
                                    
                                }
                            }
                        }
                    ,
403: {"description": "Forbidden"}, 
404: {"description": "Not Found"}, 
401: {"description": "Unauthorized"}, 
415: {"description": "Unsupported Media Type"}, 
504: {"description": "Gateway Timeout"},
   400: {"description": "Ok","content": {
               "application/json": {
                 "schema": {
                   "$ref": "#/components/schemas/WorkflowData"
                 }
               }
             }},}
   
)
async def start_task( request: Request, workflowId: str  = Path( description="The TeamID should be Passed here", regex='^[A-Za-z0-9]{1,32}$'), taskIndex: int= Path( description="The Task ID should be Passed here" ,  ge=1, le=10000), hasAccess : dict= Depends(hasAccess)):

  """
   Operation to **Start** a task in a workflow (latest version). Input:  **Workflow ID**,**Task ID** Note: If Task is already started, operation will throw an error, and start date will not be updated!  
  """  
  if hasAccess and hasAccess is not None:
      teamId , _ = hasAccess
      query_params = request.query_params
      keys_list = list(query_params.keys())
      for key in keys_list:
        if len(query_params.getlist(key))>1  :
            raise HTTPException(status_code=400, detail="Bad Request can not pass an array")
      Startdate = datetime.now()
      
      query= '''MATCH (t:Task {workflowId: $workflowId })-[NEXT_TASK]-(b)
              WITH max(t.workflowVersion) as max
              MATCH (t:Task {workflowVersion : max, workflowId:$workflowId, teamId: $teamId})
              WHERE (NOT ()-->(t) AND t.taskDateCompleted is null  AND t.taskDateStarted is null AND  (t.workflowId= $workflowId AND t.teamId =$teamId))
              OR (t.taskDateCompleted is null AND t.taskDateStarted is null AND (t.workflowId= $workflowId AND t.teamId =$teamId) AND ALL(m IN [(m)-->(t) | m] WHERE m.taskDateCompleted is NOT null))
            
              RETURN DISTINCT t.taskIndex as taskIndex

      '''
      results,meta = run_cypher_query(query, {'teamId': teamId , 'workflowId':workflowId})
      if (len(results) ==0):
              raise HTTPException(status_code=404, detail="Incorrect Input")
      Formatted_Results = [{"taskIndex":row[0]} for row in results]  

      if any(taskIndex in sublist for sublist in results):

      
          query= '''Match (n:Task  {workflowId:$workflowId}) 
          WITH max(n.workflowVersion) as max
          Match (n:Task  {workflowVersion : max,  workflowId:$workflowId, teamId: $teamId})
          WHERE n.workflowId=$workflowId AND n.teamId = $teamId AND n.taskIndex = $taskIndex 
          
          SET n.taskDateStarted = coalesce(n.taskDateStarted,$Startdate) 
          RETURN n.taskDateStarted'''
          results,meta = run_cypher_query(query, {'teamId': teamId , 'workflowId':workflowId, 'taskIndex':taskIndex , 'Startdate':Startdate })

          return {"taskStartDate": results[0][0] }
      else :
          raise HTTPException(status_code=404, detail="Incorrect Input")

      
  else:
      return {"NOT AUTHENTICATED or Invalid Token"} 