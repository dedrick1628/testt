import json
import OasSpec
from utils.authentication import hasAccess
from routersUtils.dbquery import run_cypher_query
from routersUtils.nexttaskhelper import get_next_task

# Imporatant imports to get the properties used to generate the Task Class
from fastapi import Request

from fastapi import FastAPI, Depends, HTTPException, APIRouter, FastAPI, HTTPException, Query, Path

import json


router = APIRouter()

app = OasSpec.app
## SHOULD BE THEIR OWN CLASS INHERITED BY ALL ENDPOINTS

# this is used to load the custom openapi json to fit the FirstAPI guidelines












@router.get("/num-version/workflow-id/{workflowId}" , tags=["num-version"], responses = {
    
   "200": {
                        "description": "Ok",
                        "content": {
                            "application/json": {
                                "schema": {
                                    "type": "object",
                                    "properties": {
                                       
                                        "numVersions": {
                                            "type": "integer",
                                            "description": "Workflow Version number",
                                            "format": "int64"
                                      
                                    }},
                                    "additionalProperties": False
                                
                            }
                        }}
                    },
403: {"description": "Forbidden"}, 
404: {"description": "Not Found"}, 
401: {"description": "Unauthorized"}, 
415: {"description": "Unsupported Media Type"}, 
504: {"description": "Gateway Timeout"},   
   400: {"description": "Ok","content": {
               "application/json": {
                 "schema": {
                   "$ref": "#/components/schemas/WorkflowData"
                 }
               }
             }}
   
})
async def num_versions(request: Request, workflowId: str  = Path( description="The TeamID should be Passed here", regex='^[A-Za-z0-9]{1,32}$'), hasAccess : dict= Depends(hasAccess)):
  
    
  """
   Operation to get the number of versions for a specific workflow. Input:  **Workflow ID**  
  """  
  if hasAccess and hasAccess is not None:
      query_params = request.query_params
      keys_list = list(query_params.keys())
      for key in keys_list:
        if len(query_params.getlist(key))>1  :
            raise HTTPException(status_code=400, detail="Bad Request can not pass an array")
      teamId , _ = hasAccess
      query= '''Match (n:Task  {workflowId:$workflowId, teamId: $teamId}) 
                WITH max(n.workflowVersion) as max
              Return max'''

      results,meta = run_cypher_query(query, {'teamId': teamId , 'workflowId':workflowId })
      if (results[0][0] == None):
              raise HTTPException(status_code=404, detail="Incorrect Input")

      return {"numVersions": results[0][0]}
  else:
      return {"NOT AUTHENTICATED or Invalid Token"}      
 