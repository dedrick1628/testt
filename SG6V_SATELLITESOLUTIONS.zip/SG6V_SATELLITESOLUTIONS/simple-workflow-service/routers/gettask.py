import json
import OasSpec
from routersUtils.miscUtils import date_obj_to_string
from utils.authentication import hasAccess
from routersUtils.dbquery import run_cypher_query
from routersUtils.nexttaskhelper import get_next_task

# Imporatant imports to get the properties used to generate the Task Class
from fastapi import Request

from fastapi import FastAPI, Depends, HTTPException, APIRouter, FastAPI, HTTPException, Query, Path

import json


router = APIRouter()

app = OasSpec.app
## SHOULD BE THEIR OWN CLASS INHERITED BY ALL ENDPOINTS

# this is used to load the custom openapi json to fit the FirstAPI guidelines












@router.get("/get-task/workflow-id/{workflowId}/task-id/{taskIndex}" , tags=["task"], responses = {
    
   "200": {
                        "description": "Ok",
                        "content": {
                            "application/json": {
                                "schema": {
                                    "type": "object",
                                    "properties": {
                                        "workflowId": {
                                            "type": "string",
                                            "description": "Workflow ID",
                                            "minLength": 1,
                                            "maxLength": 100
                                        },
                                        "taskDateDue": {
                                            "type": "string",
                                            "description": "task Due Date",
                                            "minLength": 1,
                                            "maxLength": 100
                                        },
                                        "sub": {
                                            "type": "string",
                                            "description": "Sub ID of the user APP",
                                            "minLength": 1,
                                            "maxLength": 100
                                        },
                                        "teamId": {
                                            "type": "string",
                                            "description": "Team ID of the user APP",
                                            "minLength": 1,
                                            "maxLength": 100
                                        },
                                        "taskDateCreated": {
                                            "type": "string",
                                            "description": "The date of the task creation",
                                            "minLength": 1,
                                            "maxLength": 100
                                        },
                                        "notes": {
                                            "type": "string",
                                            "description": "The notes of the task",
                                            "minLength": 1,
                                            "maxLength": 100
                                        },
                                        "taskAllowedUser": {
                                                        "type": "array",
                                                        "description": "List of the task allowed user",

                                                        "maxItems": 250,
                                                        "minItems": 1,

                                                        "items": {
                                                            "type": "string"
                                                        },
                                                    },
                                        "workflowDateDue": {
                                            "type": "string",
                                            "description": "Workflow Due Date",
                                            "minLength": 0,
                                            "maxLength": 100
                                        },
                                        "taskInput": {
                                            "type": "string",
                                            "description": "Initial data of the task ",
                                            "minLength": 0,
                                            "maxLength": 100
                                        },
                                        "taskDeliverable": {
                                            "type": "string",
                                            "description": "task Deliverables data",
                                            "minLength": 0,
                                            "maxLength": 100
                                        },
                                        "workflowDateCompleted": {
                                            "type": "string",
                                            "description": "Workflow Date Completed",
                                            "minLength": 0,
                                            "maxLength": 100
                                        },
                                        "taskIndex": {
                                            "type": "integer",
                                            "description": "Task Index",
                                            "format": "int64"
                                        },
                                        "taskSla": {
                                            "type": "number",
                                            "description": "Task SLA",
                                            "format": "double"
                                        },
                                        "workflowVersion": {
                                            "type": "integer",
                                            "description": "workflow version",
                                            "format": "int64"
                                        },
                                        "workflowName": {
                                            "type": "string",
                                            "description": "Workflow Name",
                                            "minLength": 0,
                                            "maxLength": 100
                                        },
                                        "taskName": {
                                            "type": "string",
                                            "description": "Task Name",
                                            "minLength": 0,
                                            "maxLength": 100
                                        }
                                    },
                                    "additionalProperties": False
                                }
                            }
                        }
                    },
403: {"description": "Forbidden"}, 
404: {"description": "Not Found"}, 
401: {"description": "Unauthorized"}, 
415: {"description": "Unsupported Media Type"}, 
504: {"description": "Gateway Timeout"},   
    400: {"description": "Ok","content": {
                "application/json": {
                  "schema": {
                    "$ref": "#/components/schemas/WorkflowData"
                  }
                }
              }},
    
})
async def get_task( request: Request, workflowId: str  = Path( description="The TeamID should be Passed here", regex='^[A-Za-z0-9]{1,32}$'), taskIndex: int= Path( description="The Task ID should be Passed here",  ge=1, le=10000), workflow_version : int= Query( None, description="The Workflow Version should be Passed here", ge=1, le=10000), hasAccess : dict= Depends(hasAccess)):
 
  """
        Operation to get all the info of a specific task in a workflow (latest version). Input:  **Workflow ID**,**Task ID**  
  """  
  
  if hasAccess and hasAccess is not None:
      teamId , _ = hasAccess
      query_params = request.query_params
      keys_list = list(query_params.keys())
      for key in keys_list:
        if len(query_params.getlist(key))>1  :
            raise HTTPException(status_code=400, detail="Bad Request can not pass an array")
      if not workflow_version: 
        
          query= '''Match (n:Task  {workflowId:$workflowId, teamId:$teamId, taskIndex : $taskIndex }) 
                    WITH max(n.workflowVersion) as max
                    Match (n:Task  {workflowVersion : max, workflowId:$workflowId, teamId: $teamId, taskIndex : $taskIndex })          
                  Return properties(n)'''
        
          results,meta = run_cypher_query(query, {'teamId': teamId , 'workflowId':workflowId, 'taskIndex':taskIndex })
          if (len(results) ==0):
                  raise HTTPException(status_code=404, detail="Incorrect Input")
          results= results[0][0]
          date_obj_to_string(results)
          return results
      elif workflow_version:
          """
          Operation to get all the info of a specific task and version in a workflow. Input:  **Workflow ID**,**Task ID**,  **Workflow Version** ,
          """  
          
            
          query= '''Match (n) 
                    
                  WHERE n.workflowId=$workflowId AND n.teamId = $teamId AND n.taskIndex = $taskIndex AND n.workflowVersion = $workflowVersion
                  
                  Return properties(n)'''

          results,meta = run_cypher_query(query, {'teamId': teamId , 'workflowId':workflowId, 'taskIndex':taskIndex, 'workflowVersion':workflow_version  })
          if (len(results) ==0):
                  raise HTTPException(status_code=404, detail="Incorrect Input")
          results= results[0][0]        
          date_obj_to_string(results)
          return results
  else:
      return {"NOT AUTHENTICATED or Invalid Token"} 
    
 