import json
import sys
import OasSpec
from routersUtils.miscUtils import is_valid_date
from utils.authentication import hasAccess
from routersUtils.dbquery import run_cypher_query
from routersUtils.nexttaskhelper import get_next_task

# Imporatant imports to get the properties used to generate the Task Class
from fastapi import Request
from datetime import datetime

from fastapi import FastAPI, Depends, HTTPException, APIRouter, FastAPI, HTTPException, Query, Path

import json
from neomodel import config, db
from datetime import datetime
from typing import ClassVar, Optional, List
import json
import OasSpec
from utils.authentication import hasAccess
import re

from pydantic import BaseModel, Field, JsonValue, FiniteFloat, StrictFloat, StrictInt, Extra, ConfigDict, StringConstraints, constr
from typing import List, Dict, Annotated, Any
from datetime import date
import uuid
import os
from dotenv import load_dotenv
# Imporatant imports to get the properties used to generate the Task Class
from neomodel import (config, StructuredNode, StringProperty, IntegerProperty,FloatProperty, UniqueIdProperty, RelationshipTo, StructuredRel, UniqueIdProperty, DateTimeFormatProperty, DateTimeNeo4jFormatProperty ,JSONProperty, ArrayProperty, BooleanProperty)
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from fastapi import Request
from starlette.status import HTTP_400_BAD_REQUEST

from fastapi import FastAPI, Depends, HTTPException
from fastapi import FastAPI, HTTPException, Body, Query, Path
import routers.allworkflows as allworkflows
import routers.allworkflowsnexttask as allworkflowsnexttask
import routers.nexttask as nexttask
import routers.alltasks as alltasks
import routers.numversion as numversion
import routers.gettask as gettask
import routers.starttask as starttask

from fastapi import FastAPI, Depends, HTTPException, APIRouter, FastAPI, HTTPException, Body, Query, Path

import json

router = APIRouter()

app = OasSpec.app
## SHOULD BE THEIR OWN CLASS INHERITED BY ALL ENDPOINTS

# this is used to load the custom openapi json to fit the FirstAPI guidelines
valid_pattern = Annotated [str, StringConstraints(pattern=r"^[A-Za-z0-9_-]{1,32}$")]


def getNodeCount():
    query= 'Match (n) Return count(n) AS node_count'
    results,meta = run_cypher_query(query)
    num_nodes = results[0][0]
    return num_nodes


# function to generate UUID for WorkflowID

def generateUUID(num_nodes):
    UUID = str(uuid.uuid4().hex)
    node_count = str(num_nodes)
    # Calculate the maximum allowed length for UUID
    max_long_length = 32 - len(node_count)
    
    # Truncate UUID if necessary
    if len(UUID) > max_long_length:
        UUID = UUID[:max_long_length]
    
    # Concatenate the strings
    result = UUID + node_count
    return result
# The Task Class 

class Task(StructuredNode):
    workflowId = StringProperty()
    workflowName = StringProperty(unique_index=True, required=True)
    workflowDateDue= DateTimeNeo4jFormatProperty()
    taskName = StringProperty(required=True)
    taskDateDue=DateTimeNeo4jFormatProperty(required=False)
    taskDateCompleted=DateTimeNeo4jFormatProperty()
    taskDateCreated= DateTimeNeo4jFormatProperty()
    taskDateStarted=DateTimeNeo4jFormatProperty()
    taskRequestedDueDate=DateTimeNeo4jFormatProperty()
    taskSla=FloatProperty()
    taskIndex=IntegerProperty( required=True)
    taskInput= JSONProperty(required=False)
    taskDeliverable= JSONProperty(required=False)
    taskAllowedUser = ArrayProperty(required=False)
    workflowTags = ArrayProperty(required=False)
    taskCompletedBy = StringProperty(required=False)
    NextTask = RelationshipTo('Task','NEXT_TASK')
    teamId = StringProperty(required=True)
    sub = StringProperty(required=True)
    taskMetadata = JSONProperty(required=False)
    notes = StringProperty()
    workflowVersion = IntegerProperty()

class TaskData(BaseModel):
    taskName : str = Field(min_length=1, max_length=250 , description='Task Name', pattern=".+" )
    taskDateDue: str = Field(default=None, min_length=1, max_length=250, description='Task Due Date', pattern="^\d{4}-\d{2}-\d{2}\s\d{2}:\d{2}:\d{2}$")
    taskRequestedDueDate: str = Field(default=None, min_length=1, max_length=250, description='Task Due Date', pattern="^\d{4}-\d{2}-\d{2}\s\d{2}:\d{2}:\d{2}$")
    taskIndex: StrictInt = Field(..., format='int32', description='Task ID')
    taskInput:JsonValue = None
    taskMetadata:JsonValue = None
    taskDeliverable:JsonValue = None
    taskCompletedBy :str = Field(default=None,min_length=1, max_length=250, description='Task Completed by Field', pattern="^[a-zA-Z0-9\s\-:_@.]{1,100}$")
    taskAllowedUser : Annotated[ List [valid_pattern], Field ( default=None, min_length=0, max_length=250, description='Task Allowed User, the liist of User Roles permitted to see the Task')] 
    taskSla: FiniteFloat  = Field( default=None, format='double', description='Task SLA', ge=0,le=sys.float_info.max) 
    notes: str = Field(default=None,min_length=1, max_length=250, description='Task Notes', pattern=".+")
    connectsTo: List[int] = Field( default=None, format='int64', min_length=1, max_length=250, description='Task connections') 
    model_config = ConfigDict(extra='forbid')
    

class WorkflowData(BaseModel):
    workflowName : str = Field(min_length=1, max_length=250, description='Workflow Name', pattern=".+")
    workflowDateDue: str = Field(min_length=1, max_length=250, description='Workflow Due Date',  pattern="^\d{4}-\d{2}-\d{2}\s\d{2}:\d{2}:\d{2}$")
    workflowTags : Annotated[ List [valid_pattern], Field ( default=None, min_length=1, max_length=250, description='Task Allowed User, the liist of User Roles permitted to see the Task')] 
    model_config = ConfigDict(extra='forbid')


@router.post("/new-workflow", tags=["new-workflow"],   responses = {
    
  "200": {
                        "description": "Ok",
                        "content": {
                            "application/json": {
                                "schema": {
                                    "type": "object",
                                    "properties": {
                                       
                                        "workflowId": {
                                            "type": "string",
                                            "description": "The Workflow ID of the newly created Workflow",
                                            "minLength": 0,
                                            "maxLength": 100
                                        }
                                      
                                    },
                                    "additionalProperties": False
                                }
                            }
                        }
                    },
403: {"description": "Forbidden"}, 
404: {"description": "Not Found"}, 
401: {"description": "Unauthorized"}, 
415: {"description": "Unsupported Media Type"}, 
504: {"description": "Gateway Timeout"}, 
404: {"description": "Not Found"}, 
401: {"description": "Unauthorized"}, 
415: {"description": "Unsupported Media Type"}, 
504: {"description": "Gateway Timeout"},   
 400: {"description": "Ok","content": {
             "application/json": {
               "schema": {
                 "$ref": "#/components/schemas/WorkflowData"
               }
             }
           }},
 
}
)
async def new_workflow(  workflow: Annotated[
WorkflowData, Body(  ),
   Field()],
  tasks: Annotated[List[TaskData] ,
      
      
      Body( description=  'Task Data Examples'
      ),
  Field(description='Task Data Examples', max_items =100000, min_items=1 )] , hasAccess : dict= Depends(hasAccess)):
    
    
    """
     Operation to **Create a workflow**. Input: **Json Body** 
    """  
    if hasAccess and hasAccess is not None:
        teamId,sub = hasAccess
        #getting number of total nodes and creating a UUID for the workflow ID
        num_nodes=getNodeCount()
        num_nodes +=1
        uniqueUUID= generateUUID(num_nodes)
        
        # Creating a temporary map where we store temp store the TASK IDS. This is first used to check if the connection value lists are using valid TASK Ids passed 
        # This is then used later in the code to instead of fetch from the DB the taskIndexs for creating relationships, we already have the task ids and nodes to establish connections O(1)
        created_nodes = {}
        
     # Creating a map where we store Connection relationship between nodes. 
        connection = {}
        
     #The next for loop is used to populate the connection map wih connections, and populate the temporary maps where we store TASK IDS
        for node_data in tasks:
            if node_data.taskIndex in created_nodes:
                # return {"ERROR: ALL TASKS SHOULD HAVE DIFFERENT IDS!"}
                raise HTTPException(status_code=404, detail="ERROR: ALL TASKS SHOULD HAVE DIFFERENT IDS!")

            created_nodes[node_data.taskIndex] =1
            if node_data.connectsTo is not None:
                connection[node_data.taskIndex] = node_data.connectsTo
            

         # The next for loops are all validation checks to make sure all Task IDS are different, and that Task IDs created match TaskIds in the conenections

        # The next for loops are all validation checks to make sure all Task IDS are different, and that Task IDs created match TaskIds in the conenections
       
        if not all(key in created_nodes.keys() for key in connection.keys()):
        #    return {"CONNECTIONS IDS AND TASK IDS DON't MATCH"} 
           raise HTTPException(status_code=404, detail="CONNECTIONS IDS AND TASK IDS DON't MATCH") 
        # print (connection.values())
       # condition 2: check if keys of dict1 are present as values in dict2
        for key, values in connection.items():
          # Check if all values for the current key are present as keys in largedictionary
          for value in values:
            if value not in created_nodes:
              # print(f"Value '{value}' for key '{key}' not found in TASKIDS") 
            #   return {"CONNECTIONS VALUES AND TASK IDS DON't MATCH"}  
              raise HTTPException(status_code=404, detail="CONNECTIONS VALUES AND TASK IDS DON't MATCH")
        for key in created_nodes.keys():
            if key not in connection.keys() :
                if not any(key in values for values in connection.values()):
                    # return {"not all Task IDs are represented as Connection Values", key}
                    raise HTTPException(status_code=404, detail="not all Task IDs are represented as Connection Values")
                
        workflow.workflowDateDue = is_valid_date(workflow.workflowDateDue)
        # For loop to create tasks from Json 
        for node_data in tasks:
                # date_Field_Formatter =  lambda date: datetime.strptime(date   , "%Y-%m-%d %H:%M:%S") if date else None
                node_data.taskRequestedDueDate = is_valid_date(node_data.taskRequestedDueDate)
                node_data.taskDateDue = is_valid_date(node_data.taskDateDue)

                # new_node = Task(  taskRequestedDueDate = date_Field_Formatter(node_data.taskRequestedDueDate)  ,taskAllowedUser= node_data.taskAllowedUser , sub=sub, teamId=teamId, workflowId=uniqueUUID, workflowVersion= 1,  workflowName=workflow.workflowName, workflowDateDue =date_Field_Formatter(workflow.workflowDateDue), taskName=node_data.taskName,  taskDateDue=date_Field_Formatter(node_data.taskDateDue), taskDateCreated = datetime.now(), notes = node_data.notes , taskSla=node_data.taskSla, taskInput=node_data.taskInput, taskMetadata=node_data.taskMetadata, workflowTags=workflow.workflowTags, taskIndex=node_data.taskIndex).save()
                new_node = Task(  taskRequestedDueDate = node_data.taskRequestedDueDate, taskAllowedUser= node_data.taskAllowedUser , sub=sub, teamId=teamId, workflowId=uniqueUUID, workflowVersion= 1,  workflowName=workflow.workflowName, workflowDateDue =workflow.workflowDateDue, taskName=node_data.taskName,  taskDateDue=node_data.taskDateDue, taskDateCreated = datetime.now(), notes = node_data.notes , taskSla=node_data.taskSla, taskInput=node_data.taskInput, taskMetadata=node_data.taskMetadata, workflowTags=workflow.workflowTags, taskIndex=node_data.taskIndex).save()
                
                new_node.save()
                created_nodes[new_node.taskIndex]=new_node
        

        # For loop to create Connections from Json 

        for from_taskIndex, to_taskIndexs in connection.items():
            from_task = created_nodes.get(from_taskIndex)
            if from_taskIndex:
                for to_taskIndex in to_taskIndexs:
                    to_task= created_nodes.get(to_taskIndex)
                    from_task.NextTask.connect(to_task)
        # message = "message:" "Tasks are created and connected successfully, Workflow ID: " + uniqueUUID
        return {"workflowId":uniqueUUID}
    else:
        return {"NOT AUTHENTICATED or Invalid Token"} 
