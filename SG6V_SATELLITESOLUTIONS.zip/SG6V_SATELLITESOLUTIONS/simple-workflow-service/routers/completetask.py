import json
import OasSpec
from utils.authentication import hasAccess
from routersUtils.dbquery import run_cypher_query
from routersUtils.nexttaskhelper import get_next_task

# Imporatant imports to get the properties used to generate the Task Class
from fastapi import Request
from datetime import datetime

from fastapi import FastAPI, Depends, HTTPException, APIRouter, FastAPI, HTTPException, Query, Path

import json


router = APIRouter()

app = OasSpec.app
## SHOULD BE THEIR OWN CLASS INHERITED BY ALL ENDPOINTS

# this is used to load the custom openapi json to fit the FirstAPI guidelines












@router.get("/complete-task/workflow-id/{workflowId}/task-id/{taskIndex}", tags=["complete-task"], responses = {
    
  "200": {
                        "description": "Ok",
                        "content": {
                            "application/json": {
                                "schema": {
                                    "type": "object",
                                    "properties": {
                                       
                                        "taskCompletionDate": {
                                            "type": "string",
                                            "description": "The start date of the task",
                                            "minLength": 0,
                                            "maxLength": 100
                                        }
                                      
                                    } ,"additionalProperties": False}
                                   
                                }
                            }
        }
                    ,
403: {"description": "Forbidden"}, 
404: {"description": "Not Found"}, 
401: {"description": "Unauthorized"}, 
415: {"description": "Unsupported Media Type"}, 
504: {"description": "Gateway Timeout"},   
400: {"description": "Incorrect Input","content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/WorkflowData"
                }
              }
            }
  
}})
async def complete_task( request: Request, workflowId: str  = Path( description="The TeamID should be Passed here", regex='^[A-Za-z0-9]{1,32}$'), taskIndex: int= Path( description="The Task ID should be Passed here", ge=1, le=10000), task_completed_by: str =Query( None, description="The User completing the role should be passed here", regex="^[a-zA-Z0-9\s\-:_@.]{1,100}$"), hasAccess : dict= Depends(hasAccess) ):

  """
  Operation to **Complete** a task in a workflow (latest version). Input:  **Workflow ID**,**Task ID**  
  """  
  if hasAccess and hasAccess is not None:
      teamId , _ = hasAccess
      query_params = request.query_params
      keys_list = list(query_params.keys())
      for key in keys_list:
        if len(query_params.getlist(key))>1  :
            raise HTTPException(status_code=400, detail="Bad Request can not pass an array")
      if not task_completed_by:
        
          Completedate = datetime.now()
        #   Query to get a list of all next tasks
          query= '''MATCH (t:Task {workflowId:$workflowId})-[NEXT_TASK]-(b)
                  WITH max(t.workflowVersion) as max
                  MATCH (t:Task {workflowVersion : max, workflowId:$workflowId, teamId: $teamId})
                  WHERE (NOT ()-->(t) AND t.taskDateCompleted is null  AND (t.workflowId= $workflowId AND t.teamId =$teamId))
                  OR (t.taskDateCompleted is null AND (t.workflowId= $workflowId AND t.teamId =$teamId ) AND ALL(m IN [(m)-->(t) | m] WHERE m.taskDateCompleted is NOT null))
                
                  RETURN DISTINCT t.taskIndex as taskIndex
        
          '''
          results,meta = run_cypher_query(query, {'teamId': teamId , 'workflowId':workflowId})
          if (len(results) ==0):
              raise HTTPException(status_code=404, detail="Incorrect Input")

          Formatted_Results = [{"taskIndex":row[0]} for row in results]  
# loop across al next tasks and check if *taskIndex* passed is in that list
          if any(taskIndex in sublist for sublist in results):

        # Query to set that task to complete and taskDate started as well if date wasn't in there yet
              query= '''Match (n:Task  {workflowId:$workflowId}) 
                      WITH max(n.workflowVersion) as max
                      Match (n:Task  {workflowVersion : max})
                      WHERE n.workflowId=$workflowId AND n.teamId = $teamId AND n.taskIndex = $taskIndex  
                      
                      SET n.taskDateCompleted = $Completedate 
                      SET n.taskDateStarted = coalesce(n.taskDateStarted,$Completedate)'''
              results,meta = run_cypher_query(query, {'teamId': teamId , 'workflowId':workflowId, 'taskIndex':taskIndex , 'Completedate': Completedate })
            #   Query to check if there are any next tasks in the workflow
              query= '''MATCH (t:Task {workflowId:$workflowId})-[NEXT_TASK]-(b)
                      WITH max(t.workflowVersion) as max
                      MATCH (t:Task {workflowVersion : max, workflowId:$workflowId, teamId: $teamId})
                      WHERE (NOT ()-->(t) AND t.taskDateCompleted is null  AND (t.workflowId= $workflowId AND t.teamId =$teamId))
                      OR (t.taskDateCompleted is null AND (t.workflowId= $workflowId AND t.teamId =$teamId) AND ALL(m IN [(m)-->(t) | m] WHERE m.taskDateCompleted is NOT null))
                    
                      RETURN DISTINCT t.taskIndex as taskIndex, t.taskName as taskName, t.taskDateDue as Task_Due_Date
            
              '''
              results,meta = run_cypher_query(query, {'teamId': teamId , 'workflowId':workflowId})
              if (len(results) ==0):
                  #   If the previous query outputs no results (no more tasks to do, set workflowcompletion date)
                  query= '''Match (n:Task  {workflowId:$workflowId}) 
                          WITH max(n.workflowVersion) as max
                          Match (n:Task  {workflowVersion : max})
                          WHERE n.workflowId=$workflowId AND n.teamId = $teamId
                          
                          SET n.workflowDateCompleted = $Completedate 
                          '''
                         
                  results,meta = run_cypher_query(query, {'teamId': teamId , 'workflowId':workflowId, 'taskIndex':taskIndex , 'Completedate': Completedate })

              return {"taskDateCompleted": Completedate }
          else :
             raise HTTPException(status_code=404, detail="Incorrect Input")
            #   return {"Can't Complete Tasks out of order or Task is already completed"}
# does everything above except with setting the task_completed_by field
      elif task_completed_by:
            Completedate = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            
            query= '''MATCH (t:Task {workflowId:$workflowId})-[NEXT_TASK]-(b)
                    WITH max(t.workflowVersion) as max
                    MATCH (t:Task {workflowVersion : max, workflowId:$workflowId, teamId: $teamId})
                    WHERE (NOT ()-->(t) AND t.taskDateCompleted is null  AND (t.workflowId= $workflowId AND t.teamId =$teamId))
                    OR (t.taskDateCompleted is null AND (t.workflowId= $workflowId AND t.teamId =$teamId ) AND ALL(m IN [(m)-->(t) | m] WHERE m.taskDateCompleted is NOT null))
                  
                    RETURN DISTINCT t.taskIndex as taskIndex
          
            '''
            results,meta = run_cypher_query(query, {'teamId': teamId , 'workflowId':workflowId})
            if (len(results) ==0):
                    raise HTTPException(status_code=404, detail="Incorrect Input")
            Formatted_Results = [{"taskIndex":row[0]} for row in results]  

            if any(taskIndex in sublist for sublist in results):

          
                query= '''Match (n:Task  {workflowId:$workflowId}) 
                        WITH max(n.workflowVersion) as max
                        Match (n:Task  {workflowVersion : max})
                        WHERE n.workflowId=$workflowId AND n.teamId = $teamId AND n.taskIndex = $taskIndex  
                        
                        SET n.taskDateCompleted = $Completedate 
                        SET n.taskDateStarted = coalesce(n.taskDateStarted,$Completedate)
                        SET n.taskCompletedBy = $taskCompletedBy
                        '''
                results,meta = run_cypher_query(query, {'teamId': teamId , 'workflowId':workflowId, 'taskIndex':taskIndex , 'Completedate': Completedate, 'taskCompletedBy':task_completed_by  })
                
                query= '''MATCH (t:Task {workflowId:$workflowId})-[NEXT_TASK]-(b)
                        WITH max(t.workflowVersion) as max
                        MATCH (t:Task {workflowVersion : max, workflowId:$workflowId, teamId: $teamId})
                        WHERE (NOT ()-->(t) AND t.taskDateCompleted is null  AND (t.workflowId= $workflowId AND t.teamId =$teamId))
                        OR (t.taskDateCompleted is null AND (t.workflowId= $workflowId AND t.teamId =$teamId) AND ALL(m IN [(m)-->(t) | m] WHERE m.taskDateCompleted is NOT null))
                      
                        RETURN DISTINCT t.taskIndex as taskIndex, t.taskName as taskName, t.taskDateDue as Task_Due_Date
              
                '''
                results,meta = run_cypher_query(query, {'teamId': teamId , 'workflowId':workflowId})
                if (len(results) ==0):
                    
                    query= '''Match (n:Task  {workflowId:$workflowId}) 
                            WITH max(n.workflowVersion) as max
                            Match (n:Task  {workflowVersion : max})
                            WHERE n.workflowId=$workflowId AND n.teamId = $teamId 
                            
                            SET n.workflowDateCompleted = $Completedate 
                            '''
                           
                    results,meta = run_cypher_query(query, {'teamId': teamId , 'workflowId':workflowId, 'taskIndex':taskIndex , 'Completedate': Completedate })
                return {"taskDateCompleted": Completedate }
            else :
                raise HTTPException(status_code=404, detail="Incorrect Input")


                # return {"Can't Complete Tasks out of order or Task is already completed"}
  else:
      return {"NOT AUTHENTICATED or Invalid Token"} 
  
  


