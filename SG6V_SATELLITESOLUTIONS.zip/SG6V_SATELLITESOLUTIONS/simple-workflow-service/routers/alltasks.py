import json
from typing import List
import OasSpec
from routersUtils.miscUtils import date_obj_to_string
from utils.authentication import hasAccess
from routersUtils.dbquery import run_cypher_query
from routersUtils.nexttaskhelper import get_next_task

# Imporatant imports to get the properties used to generate the Task Class
from fastapi import Request

from fastapi import FastAPI, Depends, HTTPException, APIRouter, FastAPI, HTTPException, Query, Path

import json


router = APIRouter()

app = OasSpec.app
## SHOULD BE THEIR OWN CLASS INHERITED BY ALL ENDPOINTS

# this is used to load the custom openapi json to fit the FirstAPI guidelines





def cypher_where_statement(where_clauses: List):
    try: 
 
      if len(where_clauses)>0:
         print()
         delim = " AND "
         where_statement = " where " + delim.join(map(str, where_clauses))
      

      return where_statement

    except:
        print("error in cypher where function delimeter")







@router.get("/all-tasks/workflow-id/{workflowId}", tags=["all-tasks"], responses = {
    
   200: {"description": "Ok","content": {
                            "application/json": {
                                "schema": {
                                    "type": "object",
                                    "properties": {
                                        "items": {
                                            "type": "array",
                                            "minItems": 0,
                                            "maxItems": 1000,
                                            "description": "This Array of Tasks in a workflow", 
                                            "items": {
                                                "type": "object",
                                               "properties": {
                                        "workflowId": {
                                            "type": "string",
                                            "description": "Workflow ID",
                                            "minLength": 1,
                                            "maxLength": 100
                                        },
                                        "taskDateDue": {
                                            "type": "string",
                                            "description": "task Due Date",
                                            "minLength": 1,
                                            "maxLength": 100
                                        },
                                        "sub": {
                                            "type": "string",
                                            "description": "Sub ID of the user APP",
                                            "minLength": 1,
                                            "maxLength": 100
                                        },
                                        "teamId": {
                                            "type": "string",
                                            "description": "Team ID of the user APP",
                                            "minLength": 1,
                                            "maxLength": 100
                                        },
                                        "taskDateCreated": {
                                            "type": "string",
                                            "description": "The date of the task creation",
                                            "minLength": 1,
                                            "maxLength": 100
                                        },
                                        "notes": {
                                            "type": "string",
                                            "description": "The notes of the task",
                                            "minLength": 1,
                                            "maxLength": 100
                                        },
                                        "taskAllowedUser": {
                                                        "type": "array",
                                                        "description": "List of the task allowed user",

                                                        "maxItems": 250,
                                                        "minItems": 1,

                                                        "items": {
                                                            "type": "string"
                                                        },
                                                    },
                                        "workflowDateDue": {
                                            "type": "string",
                                            "description": "Workflow Due Date",
                                            "minLength": 0,
                                            "maxLength": 100
                                        },
                                        "taskInput": {
                                            "type": "string",
                                            "description": "Initial data of the task ",
                                            "minLength": 0,
                                            "maxLength": 100
                                        },
                                        "taskDeliverable": {
                                            "type": "string",
                                            "description": "task Deliverables data",
                                            "minLength": 0,
                                            "maxLength": 100
                                        },
                                        "workflowDateCompleted": {
                                            "type": "string",
                                            "description": "Workflow Date Completed",
                                            "minLength": 0,
                                            "maxLength": 100
                                        },
                                        "taskIndex": {
                                            "type": "integer",
                                            "description": "Task Index",
                                            "format": "int64"
                                        },
                                        "taskSla": {
                                            "type": "number",
                                            "description": "Task SLA",
                                            "format": "double"
                                        },
                                        "workflowVersion": {
                                            "type": "integer",
                                            "description": "workflow version",
                                            "format": "int64"
                                        },
                                        "workflowName": {
                                            "type": "string",
                                            "description": "Workflow Name",
                                            "minLength": 0,
                                            "maxLength": 100
                                        },
                                        "taskName": {
                                            "type": "string",
                                            "description": "Task Name",
                                            "minLength": 0,
                                            "maxLength": 100
                                        }
                                    },
                                                "additionalProperties": False,
                                                "required": [
                                                    "workflowId",
                                                    "taskDateDue",
                                                    "workflowDateDue",
                                                    "taskName",
                                                    "taskIndex",
                                                    "workflowName"

                                                ]
                                            }
                                        }
                                    },
                                    "additionalProperties": False
                                }
                            }
                        }},
403: {"description": "Forbidden"}, 
404: {"description": "Not Found"}, 
401: {"description": "Unauthorized"}, 
415: {"description": "Unsupported Media Type"}, 
504: {"description": "Gateway Timeout"},   
400: {"description": "Ok","content": {
               "application/json": {
                 "schema": {
                   "$ref": "#/components/schemas/WorkflowData"
                 }
               }
             }},
   
})
async def all_tasks( request: Request, workflowId: str  = Path( description="The TeamID should be Passed here", regex='^[A-Za-z0-9]{1,32}$') , workflow_version : int= Query( None, description="The Workflow Version should be Passed here",  ge=1, le=10000), task_allowed_user: str= Query( None, description='''The Allowed user role should be Passed here. The syntax should follow this format: {"taskAllowedUser": ["role1","role2"]}''', regex="^.{1,1048}$"), hasAccess : dict= Depends(hasAccess) ):
  """
   Operation to get all the Tasks for a specific workflow (latest version). Input:  **Workflow ID**. Not if no User Roles are declaired and assigned during the creation of the workflow, passing data to *task_allowed_user* will not affect the outcome of the results 
  """  
  if hasAccess and hasAccess is not None:
      teamId , _ = hasAccess
      query_params = request.query_params
      keys_list = list(query_params.keys())
      for key in keys_list:
        if len(query_params.getlist(key))>1  :
            raise HTTPException(status_code=400, detail="Bad Request can not pass an array")      
      if task_allowed_user and task_allowed_user is not None:
         json_string = task_allowed_user
         try:
            task_allowed_user = json.loads(json_string)  
         except:
            raise HTTPException(status_code=400, detail="Wrong Json Syntax")
         try:
            task_allowed_user= task_allowed_user["taskAllowedUser"]
         except:
            print(task_allowed_user)
            raise HTTPException(status_code=400, detail="task_allowed_user Key was not provided, or key contains a typo")  
     
      query_start_template = '''Match (n:Task  {workflowId:$workflowId, teamId: $teamId}) 

                 '''      
      output_param = {'teamId': teamId , 'workflowId':workflowId}
      possible_where_clauses = {
        "workflow_version": ''' n.workflowVersion = $workflow_version ''' ,

       "task_allowed_user": ''' ((ANY  (allowedUsers IN $task_allowed_user Where  allowedUsers IN n.taskAllowedUser ))	OR (n.taskAllowedUser	 IS NULL OR size(n.taskAllowedUser	) = 0)) ''' ,
        }
      possible_where_params = {
       "task_allowed_user": task_allowed_user ,
        "workflow_version": workflow_version ,

        }
      output_where_clauses = []
      common_keys = possible_where_clauses.keys() & keys_list
      if "workflow_version" not in common_keys:
          query_start_template = query_start_template + '''   WITH max(n.workflowVersion) as max
                                                             MATCH (n:Task { workflowId:$workflowId, teamId: $teamId, workflowVersion : max})  '''
      for key in common_keys:
           output_where_clauses.append(possible_where_clauses[key])
           output_param[key] = possible_where_params[key]

      if   len(output_where_clauses)>0:
            query_start_template = query_start_template + cypher_where_statement(output_where_clauses) 
      
      
      query_generated = query_start_template  + "  Return properties(n) ORDER BY n.taskIndex "
   
            
      print("query generated: ", query_generated)
      print("query params: " , output_param)
      results,_ = run_cypher_query(query_generated, output_param)
      results = [item for sublist in results for item in sublist]
      if (len(results) ==0):
          raise HTTPException(status_code=404, detail="Incorrect Input")
      date_obj_to_string(results)
      return results 
#       if not workflow_version:
#           if not task_allowed_user:
#                 # query= 'Match (n) WHERE n.workflowId=$workflowId AND n.teamId = $teamId Return n.workflowName AS workflowName,  n.workflowDateDue        as Workflow_DUE_DATE, n.taskName as taskName, n.taskDateDue as Task_Due_Date'
#               query= '''Match (n:Task  {workflowId:$workflowId, teamId: $teamId}) 
#                         WITH max(n.workflowVersion) as max
#                         Match (n:Task  {workflowVersion : max, workflowId:$workflowId, teamId: $teamId })
                     
                      
#                       Return properties(n) ORDER BY n.taskIndex'''
            
#               results,meta = run_cypher_query(query, {'teamId': teamId , 'workflowId':workflowId })
#               if (len(results) ==0):
#                       raise HTTPException(status_code=404, detail="Incorrect Input")
            
#               results = [item for sublist in results for item in sublist]
#               date_obj_to_string(results)
#               return results
#           elif task_allowed_user:
#             query= '''Match (n:Task  {workflowId:$workflowId, teamId: $teamId}) 
#                       WITH max(n.workflowVersion) as max
#                       Match (n:Task  {workflowVersion : max, workflowId:$workflowId, teamId: $teamId })
#                       WHERE   (ANY  (allowedUsers IN $taskAllowedUser Where  allowedUsers IN n.taskAllowedUser ))	OR (n.taskAllowedUser	 IS NULL OR size(n.taskAllowedUser	) = 0)
                   
                    
#                      Return properties(n) ORDER BY n.taskIndex Asc'''
          
#             results,meta = run_cypher_query(query, {'teamId': teamId , 'workflowId':workflowId, 'taskAllowedUser':task_allowed_user })
#             if (len(results) ==0):
#                     raise HTTPException(status_code=404, detail="Incorrect Input")
#             results = [item for sublist in results for item in sublist]
#             date_obj_to_string(results)
#             return  results
#       elif workflow_version:
#           if not task_allowed_user:
#               query= '''Match (n) 
              
#                       WHERE n.workflowId=$workflowId AND n.teamId = $teamId  AND n.workflowVersion = $workflowVersion
                      
#                        Return properties(n) ORDER BY n.taskIndex Asc'''
        
#               results,meta = run_cypher_query(query, {'teamId': teamId , 'workflowId':workflowId, 'workflowVersion':workflow_version })
#               if (len(results) ==0):
#                       raise HTTPException(status_code=404, detail="Incorrect Input")
        
#               results = [item for sublist in results for item in sublist]
#               date_obj_to_string(results)
#               return  results
#           elif   task_allowed_user:
              
#            query= '''Match (n) 
           
#                    WHERE n.workflowId=$workflowId AND n.teamId = $teamId  AND n.workflowVersion = $workflowVersion AND ((ANY  (allowedUsers IN $taskAllowedUser Where  allowedUsers IN n.taskAllowedUser ))	OR (n.taskAllowedUser	 IS NULL OR size(n.taskAllowedUser	) = 0))
                   
#                     Return properties(n) ORDER BY n.taskIndex Asc'''
     
#            results,meta = run_cypher_query(query, {'teamId': teamId , 'workflowId':workflowId, 'workflowVersion':workflow_version,  'taskAllowedUser':task_allowed_user })
#            if (len(results) ==0):
#                 #    return JSONResponse(status_code=404, content = {    "Message": "Incorrect Input"})
#                 raise HTTPException(status_code=404, detail="Incorrect Input")
#            results = [item for sublist in results for item in sublist]
#            date_obj_to_string(results)
#            return  results
#   else:
#     return {"NOT AUTHENTICATED or Invalid Token"}      
