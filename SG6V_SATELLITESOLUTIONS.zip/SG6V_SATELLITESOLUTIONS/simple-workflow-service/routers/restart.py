import json
import OasSpec
from utils.authentication import hasAccess
from routersUtils.dbquery import run_cypher_query
from routersUtils.nexttaskhelper import get_next_task

# Imporatant imports to get the properties used to generate the Task Class
from fastapi import Request
from datetime import datetime

from fastapi import FastAPI, Depends, HTTPException, APIRouter, FastAPI, HTTPException, Query, Path

import json
from neomodel import config, db
from datetime import datetime
from typing import ClassVar, Optional, List
import json
import OasSpec
from utils.authentication import hasAccess
import re

from pydantic import BaseModel, Field, JsonValue, StrictInt, Extra, ConfigDict, StringConstraints, constr
from typing import List, Dict, Annotated, Any
from datetime import date
import uuid
import os
from dotenv import load_dotenv
# Imporatant imports to get the properties used to generate the Task Class
from neomodel import (config, StructuredNode, StringProperty, IntegerProperty, UniqueIdProperty, RelationshipTo, StructuredRel, UniqueIdProperty, DateTimeFormatProperty, JSONProperty, ArrayProperty, BooleanProperty)
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from fastapi import Request
from starlette.status import HTTP_400_BAD_REQUEST

from fastapi import FastAPI, Depends, HTTPException
from fastapi import FastAPI, HTTPException, Body, Query, Path
import routers.allworkflows as allworkflows
import routers.allworkflowsnexttask as allworkflowsnexttask
import routers.nexttask as nexttask
import routers.alltasks as alltasks
import routers.numversion as numversion
import routers.gettask as gettask
import routers.starttask as starttask

from fastapi import FastAPI, Depends, HTTPException, APIRouter, FastAPI, HTTPException, Body, Query, Path

import json

router = APIRouter()

app = OasSpec.app
## SHOULD BE THEIR OWN CLASS INHERITED BY ALL ENDPOINTS

# this is used to load the custom openapi json to fit the FirstAPI guidelines
valid_pattern = Annotated [str, StringConstraints(pattern=r"^[A-Za-z0-9_-]{1,32}$")]

class workflowTagsData(BaseModel):
    workflowTags : Annotated[ List [valid_pattern], Field ( default=None, min_length=1, max_length=250, description='Task Allowed User, the liist of User Roles permitted to see the Task')] 
    workflowId: str = Field(min_length=1, max_length=250 , description='WorkflowID', pattern="^[A-Za-z0-9]{1,32}$")

    model_config = ConfigDict(extra='forbid')







@router.get("/restart-task/workflow-id/{workflowId}/task-id/{taskIndex}", tags=["restart-task"], responses = {
    
  "200": {
                        "description": "Ok",
                        "content": {
                            "application/json": {
                                "schema": {
                                    "type": "object",
                                    "properties": {
                                       
                                       "workflowVersion": {
                                            "type": "integer",
                                            "description": "Workflow Version number",
                                            "format": "int64"
                                      
                                    }
                                      
                                    },
                                    "additionalProperties": False
                                }
                            }
                        }
                    },
403: {"description": "Forbidden"}, 
404: {"description": "Not Found"}, 
401: {"description": "Unauthorized"}, 
415: {"description": "Unsupported Media Type"}, 
504: {"description": "Gateway Timeout"},   
400: {"description": "Ok","content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/WorkflowData"
                }
              }
            }},
  
})
async def restart_task( request: Request, workflowId: str  = Path( description="The TeamID should be Passed here", regex='^[A-Za-z0-9]{1,32}$'), taskIndex: int= Path( description="The Task ID should be Passed here", ge=1, le=10000),  set_task_date_due_null: bool= Query( None, description='''A Boolean when set true (default false) will set all restarted tasks due dates to null''')  ,  set_task_request_due_date_null: bool= Query( None, description='''A Boolean when set true (default false) will set all restarted tasks requested due dates to null''')  , set_task_input_null: bool= Query( None, description='''A Boolean when set true (default false) will set all restarted tasks taskInputData to null''')  ,set_task_deliverable_null: bool= Query( None, description='''A Boolean when set true (default false) will set all restarted tasks  metadata to null''')  , set_task_metadata_null: bool= Query( None, description='''A Boolean when set true (default false) will set all restarted tasks metadata to null''')  ,hasAccess : dict= Depends(hasAccess)):

    
  """
   Operation to **Redo a task** in a workflow sets completed date to null and creates a new workflow version with that after . Input:  **Workflow ID**,**Task ID** NOTE: Even if input Task is not started/completed, a new version will be created!  
  """    
  ## Add setaskRequestedDueDateNull boolean parameter and the settaskRequestedDueDateNull boolean parameter and the setTaskInputDataNull parameter and the setTaskDeliverableDataNull parameter

  # Add more documentation to Cypher Queries here
  if hasAccess and hasAccess is not None:

    teamId , _ = hasAccess
    query_params = request.query_params
    keys_list = list(query_params.keys())
    for key in keys_list:
        if len(query_params.getlist(key))>1  :
            raise HTTPException(status_code=400, detail="Bad Request can not pass an array")    
    query= '''Match (n:Task  {workflowId:$workflowId}) 
              WITH max(n.workflowVersion) as max
              Match (n:Task  {workflowVersion : max, workflowId:$workflowId, teamId: $teamId})
            WHERE n.workflowId=$workflowId AND n.teamId = $teamId AND n.taskIndex = $taskIndex  AND n.taskDateCompleted is NOT NULL
            
            Return n'''

    results,meta = run_cypher_query(query, {'teamId': teamId , 'workflowId':workflowId, 'taskIndex':taskIndex })
    if (len(results) ==0):
            raise HTTPException(status_code=404, detail="Incorrect Input")
      
  
    query= '''Match (n:Task  {workflowId:$workflowId}) 
                       WITH max(n.workflowVersion) as max
                       Match (n:Task  {workflowVersion : max})
                       WHERE n.workflowId=$workflowId AND n.teamId = $teamId
                       
                       SET n.workflowDateCompleted =  NULL
                       '''
                      
    results,meta = run_cypher_query(query, {'teamId': teamId , 'workflowId':workflowId  })

    # query for patching only last task
  #   query =''' 
  # MATCH  (n:Task {workflowId:$workflowId, teamId:$teamId })

  # WITH max(n.taskIndex) as MaxID
  # Match (n:Task  {workflowId:$workflowId, teamId:$teamId})
  # WHERE n.taskIndex =$taskIndex AND n.taskIndex = MaxID
  # Match (n:Task  {workflowId:$workflowId, teamId:$teamId})
  # WITH max(n.workflowVersion) as MaxVal
  # MATCH (t:Task {workflowId:$workflowId, teamId:$teamId})
  # WHERE t.workflowVersion= MaxVal  AND (NOT ()-->(t) )
  # MATCH path = (t)-[:NEXT_TASK*]->(node)
  # WITH t,  collect(path) as paths
  # CALL apoc.refactor.cloneSubgraphFromPaths(paths)
  # YIELD  output
  # SET output.workflowVersion = output.workflowVersion + 1
  # WITH output as output2, max(output.taskIndex) as TaskIdMAx
  # MATCH (output2)
  # WHERE output2.taskIndex = $taskIndex AND output2.taskIndex =TaskIdMAx
  # SET output2.taskDateCompleted = NULL
  # SET output2.taskDateStarted = NULL
  # SET output2.taskCompletedBy = NULL
  # RETURN  output2.workflowVersion LIMIT 1
    
  #   '''
    null_optional_parameters =  lambda bool_parameter,set_statement: set_statement   if bool_parameter else " "
    set_null_taskDateDue_last_task = null_optional_parameters(set_task_date_due_null," SET output2.taskDateDue = NULL ")
    set_null_taskRequestedDueDate_last_task = null_optional_parameters(set_task_request_due_date_null," SET output2.taskRequestedDueDate = NULL ")
    set_null_task_deliverable_last_task = null_optional_parameters(set_task_deliverable_null," SET output2.taskDeliverable = NULL ")
    set_null_task_input_data_last_task = null_optional_parameters(set_task_input_null," SET output2.taskInput = NULL ")
    set_null_task_metadata_last_task = null_optional_parameters(set_task_metadata_null," SET output2.taskMetadata = NULL ")

    set_null_taskDateDue_except_last_task = null_optional_parameters(set_task_date_due_null,"  , t.taskDateDue = NULL ")
    set_null_taskRequestedDueDate_except_last_task = null_optional_parameters(set_task_request_due_date_null," ,  t.taskRequestedDueDate = NULL ")
    set_null_task_deliverable_except_last_task = null_optional_parameters(set_task_deliverable_null," ,  t.taskDeliverable = NULL ")
    set_null_task_input_data_except_last_task = null_optional_parameters(set_task_input_null," ,  t.taskInput = NULL ")
    set_null_task_metadata_except_last_task = null_optional_parameters(set_task_metadata_null," ,  t.taskMetadata = NULL ")

    query =''' 
  MATCH  (n:Task {workflowId:$workflowId, teamId:$teamId })

  WITH max(n.taskIndex) as MaxID
  Match (n:Task  {workflowId:$workflowId, teamId:$teamId})
  WHERE n.taskIndex =$taskIndex AND n.taskIndex = MaxID
  Match (n:Task  {workflowId:$workflowId, teamId:$teamId})
  WITH max(n.workflowVersion) as MaxVal
  MATCH (t:Task {workflowId:$workflowId, teamId:$teamId})
  WHERE t.workflowVersion= MaxVal  AND (NOT ()-->(t) )
  MATCH path = (t)-[:NEXT_TASK*]->(node)
  WITH t,  collect(path) as paths
  CALL apoc.refactor.cloneSubgraphFromPaths(paths)
  YIELD  output
  SET output.workflowVersion = output.workflowVersion + 1
  WITH output as output2, max(output.taskIndex) as TaskIdMAx
  MATCH (output2)
  WHERE output2.taskIndex = $taskIndex AND output2.taskIndex =TaskIdMAx
  SET output2.taskDateCompleted = NULL
  SET output2.taskDateStarted = NULL
  SET output2.taskCompletedBy = NULL''' + set_null_taskDateDue_last_task + set_null_taskRequestedDueDate_last_task + set_null_task_deliverable_last_task+set_null_task_input_data_last_task+ set_null_task_metadata_last_task +'''  RETURN  output2.workflowVersion LIMIT 1
    
    '''
    results,meta = run_cypher_query(query, {'teamId': teamId , 'workflowId':workflowId, 'taskIndex' : taskIndex})
    if (len(results) ==0):
       
       
      # query for patching evertyhing but last task
        query= '''MATCH  (n:Task {workflowId:$workflowId, teamId:$teamId })
                  WITH max(n.workflowVersion) as MaxVal 
                  MATCH (t:Task {workflowId:$workflowId, teamId:$teamId})
                  WHERE t.workflowVersion =MaxVal AND (NOT ()-->(t) )
                  MATCH path = (t)-[:NEXT_TASK*]->(node)
                  WITH t,  collect(path) as paths
                  CALL apoc.refactor.cloneSubgraphFromPaths(paths)
                  YIELD  output
                  SET output.workflowVersion = output.workflowVersion + 1
                  WITH output as output2
                  MATCH z=(output2 )-[*]->(finish)
                  WHERE   output2.taskIndex = $taskIndex
                  FOREACH (t IN nodes(z) | SET t.taskDateCompleted = NULL, t.taskDateStarted = NULL, t.taskCompletedBy = NULL '''  +set_null_taskDateDue_except_last_task+set_null_taskRequestedDueDate_except_last_task+set_null_task_deliverable_except_last_task+set_null_task_input_data_except_last_task+ set_null_task_metadata_except_last_task +''')
                  RETURN Distinct  output2.workflowVersion LIMIT 1
      
        '''
        results,meta = run_cypher_query(query, {'teamId': teamId , 'workflowId':workflowId, 'taskIndex' : taskIndex})
        if (len(results) ==0):
                raise HTTPException(status_code=404, detail="Incorrect Input")
        
        
        
        return {" workflowVersion: ": results[0][0] }
    else: return {"workflowVersion": results[0][0]}
  else:
    return {"NOT AUTHENTICATED or Invalid Token"} 
  
 

       


