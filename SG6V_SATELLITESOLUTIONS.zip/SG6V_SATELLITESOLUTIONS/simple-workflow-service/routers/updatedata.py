import json
import OasSpec
from routersUtils.miscUtils import date_obj_to_string, is_valid_date
from utils.authentication import hasAccess
from routersUtils.dbquery import run_cypher_query
from routersUtils.nexttaskhelper import get_next_task

# Imporatant imports to get the properties used to generate the Task Class
from fastapi import Request
from datetime import datetime

from fastapi import FastAPI, Depends, HTTPException, APIRouter, FastAPI, HTTPException, Query, Path

import json
from neomodel import config, db
from datetime import datetime
from typing import ClassVar, Optional, List
import json
import OasSpec
from utils.authentication import hasAccess
import re

from pydantic import BaseModel, Field, JsonValue, StrictInt, Extra, ConfigDict, StringConstraints, constr
from typing import List, Dict, Annotated, Any
from datetime import date
import uuid
import os
from dotenv import load_dotenv
# Imporatant imports to get the properties used to generate the Task Class
from neomodel import (config, StructuredNode, StringProperty, IntegerProperty, UniqueIdProperty, RelationshipTo, StructuredRel, UniqueIdProperty, DateTimeFormatProperty, JSONProperty, ArrayProperty, BooleanProperty)
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from fastapi import Request
from starlette.status import HTTP_400_BAD_REQUEST

from fastapi import FastAPI, Depends, HTTPException
from fastapi import FastAPI, HTTPException, Body, Query, Path
import routers.allworkflows as allworkflows
import routers.allworkflowsnexttask as allworkflowsnexttask
import routers.nexttask as nexttask
import routers.alltasks as alltasks
import routers.numversion as numversion
import routers.gettask as gettask
import routers.starttask as starttask

from fastapi import FastAPI, Depends, HTTPException, APIRouter, FastAPI, HTTPException, Body, Query, Path

import json

router = APIRouter()

app = OasSpec.app
## SHOULD BE THEIR OWN CLASS INHERITED BY ALL ENDPOINTS

# this is used to load the custom openapi json to fit the FirstAPI guidelines
  
def cypher_set_statement(set_clauses: List):
    try: 
 
      if len(set_clauses)>0:
         print()
         delim = ", "
         set_statement = " SET " + delim.join(map(str, set_clauses))
      

      return set_statement

    except:
        print("error in cypher where function delimeter")
valid_pattern = Annotated [str, StringConstraints(pattern=r"^[A-Za-z0-9_-]{1,32}$")]

class updateData(BaseModel):
    workflowId: str = Field(min_length=1, max_length=250 , description='WorkflowID', pattern="^[A-Za-z0-9]{1,32}$")
    # teamId: str = Field(min_length=1, max_length=250, description='TeamID', pattern="^[A-Za-z0-9]{1,32}$")
    taskIndex: StrictInt = Field(..., format='int64', description='Task ID', ge=0, le=10000)
    taskInput:JsonValue = None
    taskDeliverable:JsonValue = None
    taskMetadata:JsonValue = None

    taskDateDue: str = Field(default=None, min_length=1, max_length=250, description='Task Due Date', pattern="^\d{4}-\d{2}-\d{2}\s\d{2}:\d{2}:\d{2}$")
    taskRequestedDueDate: str = Field(default=None, min_length=1, max_length=250, description='Task Due Date', pattern="^\d{4}-\d{2}-\d{2}\s\d{2}:\d{2}:\d{2}$")
    taskAllowedUser : Annotated[ List [valid_pattern], Field ( default=None, min_length=0, max_length=250, description='Task Allowed User, the list of User Roles permitted to see the Task')] 

    notes: str = Field(default=None,min_length=1, max_length=250, description='Task Notes', pattern=".+")
    model_config = ConfigDict(extra='forbid')










@router.post("/add-data-or-notes", tags=["Add or Edit Data"], responses = {
    
 "200": {
                        "description": "Ok",
                        "content": {
                            "application/json": {
                                "schema": {
                                    "type": "object",
                                    "properties": {
                                        "workflowId": {
                                            "type": "string",
                                            "description": "Workflow ID",
                                            "minLength": 1,
                                            "maxLength": 100
                                        },
                                        "taskDateDue": {
                                            "type": "string",
                                            "description": "task Due Date",
                                            "minLength": 1,
                                            "maxLength": 100
                                        },
                                        "sub": {
                                            "type": "string",
                                            "description": "Sub ID of the user APP",
                                            "minLength": 1,
                                            "maxLength": 100
                                        },
                                        "teamId": {
                                            "type": "string",
                                            "description": "Team ID of the user APP",
                                            "minLength": 1,
                                            "maxLength": 100
                                        },
                                        "taskDateCreated": {
                                            "type": "string",
                                            "description": "The date of the task creation",
                                            "minLength": 1,
                                            "maxLength": 100
                                        },
                                        "notes": {
                                            "type": "string",
                                            "description": "The notes of the task",
                                            "minLength": 1,
                                            "maxLength": 100
                                        },
                                        "taskAllowedUser": {
                                                        "type": "array",
                                                        "description": "List of the task allowed user",

                                                        "maxItems": 250,
                                                        "minItems": 1,

                                                        "items": {
                                                            "type": "string"
                                                        },
                                                    },
                                        "workflowDateDue": {
                                            "type": "string",
                                            "description": "Workflow Due Date",
                                            "minLength": 0,
                                            "maxLength": 100
                                        },
                                        "taskInput": {
                                            "type": "string",
                                            "description": "Initial data of the task ",
                                            "minLength": 0,
                                            "maxLength": 100
                                        },
                                        "taskDeliverable": {
                                            "type": "string",
                                            "description": "task Deliverables data",
                                            "minLength": 0,
                                            "maxLength": 100
                                        },
                                        "workflowDateCompleted": {
                                            "type": "string",
                                            "description": "Workflow Date Completed",
                                            "minLength": 0,
                                            "maxLength": 100
                                        },
                                        "taskIndex": {
                                            "type": "integer",
                                            "description": "Task Index",
                                            "format": "int64"
                                        },
                                        "taskSla": {
                                            "type": "number",
                                            "description": "Task SLA",
                                            "format": "double"
                                        },
                                        "workflowVersion": {
                                            "type": "integer",
                                            "description": "workflow version",
                                            "format": "int64"
                                        },
                                        "workflowName": {
                                            "type": "string",
                                            "description": "Workflow Name",
                                            "minLength": 0,
                                            "maxLength": 100
                                        },
                                        "taskName": {
                                            "type": "string",
                                            "description": "Task Name",
                                            "minLength": 0,
                                            "maxLength": 100
                                        }
                                    },
                                    "additionalProperties": False
                                }
                            }
                        }
                    },
403: {"description": "Forbidden"}, 
404: {"description": "Not Found"}, 
401: {"description": "Unauthorized"}, 
415: {"description": "Unsupported Media Type"}, 
504: {"description": "Gateway Timeout"},   
 400: {"description": "Ok","content": {
             "application/json": {
               "schema": {
                 "$ref": "#/components/schemas/WorkflowData"
               }
             }
           }},
 
})



async def add_data_or_notes( data: Annotated[
 updateData, Body( ),
   ],hasAccess : dict= Depends(hasAccess)):
 
    
  """
  Operation to **Add** the User Input Data (Json) of a task in a workflow (latest version) or to **Add/Update** the notes of a task in a workflow (latest version). Input:  **Workflow ID**,**Task ID**  Note: If Input Data is initalized, this will overide it!  
  """
  
  if hasAccess and hasAccess is not None:
      teamId , _ = hasAccess
      raw_data = data.model_dump(exclude_unset=True)
      data.taskInput  = json.dumps(data.taskInput)
      data.taskDeliverable  = json.dumps(data.taskDeliverable)
      data.taskMetadata  = json.dumps(data.taskMetadata)
      Updated = datetime.now().strftime('%Y-%m-%d %H:%M:%S') 
    #   Validating is tate is valid and returning datetime type
    #   data.taskDateDue = datetime.strptime( data.taskDateDue  , "%Y-%m-%d %H:%M:%S").isoformat()
    # converting datetime type to string isoformat for Neo4j DateTime field
      if data.taskDateDue is not None:
        data.taskDateDue = is_valid_date(data.taskDateDue)
        data.taskDateDue =data.taskDateDue.isoformat()
      if data.taskRequestedDueDate is not None:  
        data.taskRequestedDueDate = is_valid_date(data.taskRequestedDueDate)
        data.taskRequestedDueDate = data.taskRequestedDueDate.isoformat()
    #   data.taskRequestedDueDate = datetime.strptime( data.taskRequestedDueDate  , "%Y-%m-%d %H:%M:%S").isoformat()
      if data.notes is not None:
          data.notes =  Updated+ ": " + data.notes 

      query_start_template = ''' Match (n:Task {teamId:$teamId, workflowId:$workflowId})
                          WITH max(n.workflowVersion) as max
                        MATCH (n:Task {workflowVersion : max, workflowId : $workflowId,teamId:$teamId }) 
                        WHERE n.workflowId=$workflowId AND n.teamId = $teamId AND n.taskIndex = $taskIndex 
 ''' 

      output_param = {'teamId': teamId , 'workflowId':data.workflowId, 'taskIndex':data.taskIndex}
      possible_set_clauses = {
       "taskInput": '''n.taskInput = $taskInput ''' ,
       "taskAllowedUser": '''n.taskAllowedUser = $taskAllowedUser ''' ,
       "taskMetadata": '''n.taskMetadata = $taskMetadata ''' ,
        "taskDeliverable": ''' n.taskDeliverable = $taskDeliverable ''' ,
        "notes":'''n.notes = coalesce(n.notes +", ", "") + $notes ''' ,
        "taskDateDue":''' n.taskDateDue = localdatetime($taskDateDue) ''' ,
        "taskRequestedDueDate":''' n.taskRequestedDueDate = localdatetime($taskRequestedDueDate) ''' 
        }
      
      possible_set_params = {
       "taskInput":  data.taskInput  ,
        "taskDeliverable":  data.taskDeliverable ,
        "taskMetadata":  data.taskMetadata ,
        "notes": data.notes,
        "taskDateDue": data.taskDateDue,
        "taskRequestedDueDate": data.taskRequestedDueDate,
        "taskAllowedUser": data.taskAllowedUser

        }
      
      output_set_clauses = []
      common_keys = possible_set_clauses.keys() & raw_data.keys()
      for key in common_keys:
           output_set_clauses.append(possible_set_clauses[key])
           output_param[key] = possible_set_params[key]

      set_stmnet = cypher_set_statement(output_set_clauses)
      query_generated = query_start_template + set_stmnet + "  Return properties(n) "
      print("query generated: ", query_generated)
      print("query params: " , output_param)
      results,meta = run_cypher_query(query_generated, output_param)
      if (len(results) ==0):
          raise HTTPException(status_code=404, detail="Incorrect Input")
      results= results[0][0]
      date_obj_to_string(results)
      return results 
#       if  "taskInput" in raw_data and "notes"  in raw_data and "taskDeliverable" in raw_data:
#           """
#            Operation to **Add** the User Input Data of a task in a workflow (latest version). Input:  **Workflow ID**,**Task ID**  Note: If Input Data is initalized, this will overide it! 
#           """    
#           Updated = datetime.now().strftime('%Y-%m-%d %H:%M:%S')  
#           data.notes =  Updated+ ": " + data.notes 
  
#           query= '''Match (n:Task  {workflowId:$workflowId}) 
#                   WITH max(n.workflowVersion) as max
#                   Match (n:Task  {workflowVersion : max, workflowId:$workflowId, teamId: $teamId})
#                   WHERE n.workflowId=$workflowId AND n.teamId = $teamId AND n.taskIndex = $taskIndex 
                 
                  
#                   SET n.taskInput = $taskInput, n.taskDeliverable = $taskDeliverable, n.notes = coalesce(n.notes +", ", "") + $notes
#                   Return properties(n)'''
#           results,meta = run_cypher_query(query, {'teamId': teamId , 'workflowId':data.workflowId, 'taskIndex':data.taskIndex , 'taskInput':data.taskInput, 'taskDeliverable':data.taskDeliverable, 'notes':data.notes })
#           if (len(results) ==0):
#                   raise HTTPException(status_code=404, detail="Incorrect Input")
      
#           """
#            Operation to **Add** the User Input Data (Json) of a task in a workflow (latest version) or to **Add/Update** the notes of a task in a workflow (latest version). Input:  **Workflow ID**,**Task ID**  Note: If Input Data is initalized, this will overide it! 
         
#           """    
            

#           results= results[0][0]
#           date_obj_to_string(results)
#           return results 
     
#       if  "taskInput"  in raw_data and "notes"  in raw_data  :
#           """
#            Operation to **Add** the User Input Data of a task in a workflow (latest version). Input:  **Workflow ID**,**Task ID**  Note: If Input Data is initalized, this will overide it! 
#           """    
#           Updated = datetime.now().strftime('%Y-%m-%d %H:%M:%S')  
#           data.notes =  Updated+ ": " + data.notes 
  
#           query= '''Match (n:Task  {workflowId:$workflowId}) 
#                   WITH max(n.workflowVersion) as max
#                   Match (n:Task  {workflowVersion : max, workflowId:$workflowId, teamId: $teamId})
#                   WHERE n.workflowId=$workflowId AND n.teamId = $teamId AND n.taskIndex = $taskIndex 
                 
                  
#                   SET n.taskInput = $taskInput, n.notes = coalesce(n.notes +", ", "") + $notes
#                   Return properties(n)'''
#           results,meta = run_cypher_query(query, {'teamId': teamId , 'workflowId':data.workflowId, 'taskIndex':data.taskIndex , 'taskInput':data.taskInput , 'notes':data.notes })
#           if (len(results) ==0):
#                   raise HTTPException(status_code=404, detail="Incorrect Input")
      
#           """
#            Operation to **Add** the User Input Data (Json) of a task in a workflow (latest version) or to **Add/Update** the notes of a task in a workflow (latest version). Input:  **Workflow ID**,**Task ID**  Note: If Input Data is initalized, this will overide it! 
         
#           """    
#           results= results[0][0]
#           date_obj_to_string(results)
#           return results
     
#       if  "taskDeliverable"  in raw_data and "notes"  in raw_data:
#           """
#            Operation to **Add** the User Input Data of a task in a workflow (latest version). Input:  **Workflow ID**,**Task ID**  Note: If Input Data is initalized, this will overide it! 
#           """    
#           Updated = datetime.now().strftime('%Y-%m-%d %H:%M:%S')  
#           data.notes =  Updated+ ": " + data.notes 
  
#           query= '''Match (n:Task  {workflowId:$workflowId}) 
#                   WITH max(n.workflowVersion) as max
#                   Match (n:Task  {workflowVersion : max, workflowId:$workflowId, teamId: $teamId})
#                   WHERE n.workflowId=$workflowId AND n.teamId = $teamId AND n.taskIndex = $taskIndex 
                 
                  
#                   SET n.taskDeliverable = $taskDeliverable, n.notes = coalesce(n.notes +", ", "") + $notes
#                   Return properties(n)'''
#           results,meta = run_cypher_query(query, {'teamId': teamId , 'workflowId':data.workflowId, 'taskIndex':data.taskIndex , 'taskDeliverable':data.taskDeliverable , 'notes':data.notes })
#           if (len(results) ==0):
#                   raise HTTPException(status_code=404, detail="Incorrect Input")
      
#           """
#            Operation to **Add** the User Input Data (Json) of a task in a workflow (latest version) or to **Add/Update** the notes of a task in a workflow (latest version). Input:  **Workflow ID**,**Task ID**  Note: If Input Data is initalized, this will overide it! 
         
#           """    
#           results= results[0][0]
#           date_obj_to_string(results)
#           return results

     
#       if  "taskInput"  in raw_data and "taskDeliverable" in raw_data :
#           """
#            Operation to **Add** the User Input Data of a task in a workflow (latest version). Input:  **Workflow ID**,**Task ID**  Note: If Input Data is initalized, this will overide it! 
#           """    
#           Updated = datetime.now().strftime('%Y-%m-%d %H:%M:%S')  
            
#           query= '''Match (n:Task  {workflowId:$workflowId}) 
#                   WITH max(n.workflowVersion) as max
#                   Match (n:Task  {workflowVersion : max, workflowId:$workflowId, teamId: $teamId})
#                   WHERE n.workflowId=$workflowId AND n.teamId = $teamId AND n.taskIndex = $taskIndex 
                 
                  
#                   SET n.taskInput = $taskInput, n.taskDeliverable = $taskDeliverable
#                   Return properties(n)'''
#           results,meta = run_cypher_query(query, {'teamId': teamId , 'workflowId':data.workflowId, 'taskIndex':data.taskIndex , 'taskInput':data.taskInput, 'taskDeliverable':data.taskDeliverable })
#           if (len(results) ==0):
#                   raise HTTPException(status_code=404, detail="Incorrect Input")
      
#           """
#            Operation to **Add** the User Input Data (Json) of a task in a workflow (latest version) or to **Add/Update** the notes of a task in a workflow (latest version). Input:  **Workflow ID**,**Task ID**  Note: If Input Data is initalized, this will overide it! 
         
#           """    
#           results= results[0][0]
#           date_obj_to_string(results)
#           return results
     




#       if "taskInput" in raw_data:   
#           """
#          Operation to **Add** the User Input Data (Json) of a task in a workflow (latest version) or to **Add/Update** the notes of a task in a workflow (latest version). Input:  **Workflow ID**,**Task ID**  Note: If Input Data is initalized, this will overide it! 
#           """    
#           Updated = datetime.now().strftime('%Y-%m-%d %H:%M:%S')  
            
#           query= '''Match (n:Task  {workflowId:$workflowId}) 
#                   WITH max(n.workflowVersion) as max
#                   Match (n:Task  {workflowVersion : max, workflowId:$workflowId, teamId: $teamId})
#                   WHERE n.workflowId=$workflowId AND n.teamId = $teamId AND n.taskIndex = $taskIndex 
                 
                  
#                   SET n.taskInput = $taskInput
#                   Return properties(n)'''
#           results,meta = run_cypher_query(query, {'teamId': teamId , 'workflowId':data.workflowId, 'taskIndex':data.taskIndex , 'taskInput':data.taskInput })
#           if (len(results) ==0):
#                   raise HTTPException(status_code=404, detail="Incorrect Input")
#           results= results[0][0]
#           date_obj_to_string(results)
#           return results
#       if "taskDeliverable" in raw_data :   
#           """
#          Operation to **Add** the User Input Data (Json) of a task in a workflow (latest version) or to **Add/Update** the notes of a task in a workflow (latest version). Input:  **Workflow ID**,**Task ID**  Note: If Input Data is initalized, this will overide it! 
#           """    
#           Updated = datetime.now().strftime('%Y-%m-%d %H:%M:%S')  
            
#           query= '''Match (n:Task  {workflowId:$workflowId}) 
#                   WITH max(n.workflowVersion) as max
#                   Match (n:Task  {workflowVersion : max, workflowId:$workflowId, teamId: $teamId})
#                   WHERE n.workflowId=$workflowId AND n.teamId = $teamId AND n.taskIndex = $taskIndex 
                 
                  
#                   SET n.taskDeliverable = $taskDeliverable
#                   Return properties(n)'''
#           results,meta = run_cypher_query(query, {'teamId': teamId , 'workflowId':data.workflowId, 'taskIndex':data.taskIndex , 'taskDeliverable':data.taskDeliverable })
#           if (len(results) ==0):
#                   raise HTTPException(status_code=404, detail="Incorrect Input")
#           results= results[0][0]
#           date_obj_to_string(results)
#           return results  
      
#       if "notes" in raw_data:
#           """
#            Operation to **Add** the User Input Data of a task in a workflow (latest version). Input:  **Workflow ID**,**Task ID**  Note: If Input Data is initalized, this will overide it! 
         
#           """    
            
#           Updated = datetime.now().strftime('%Y-%m-%d %H:%M:%S')  
#           data.notes =  Updated+ ": " + data.notes 
            
#           query= '''Match (n{workflowId:$workflowId}) 
#                   WITH max(n.workflowVersion) as max
#                   Match (n:Task  {workflowVersion : max, workflowId:$workflowId, teamId: $teamId})
#                   WHERE n.workflowId=$workflowId AND n.teamId = $teamId AND n.taskIndex = $taskIndex 
                 
                  
#                   SET n.notes = coalesce(n.notes +", ", "")  + $notes
#                   Return properties(n)'''
#           results,meta = run_cypher_query(query, {'teamId': teamId , 'workflowId':data.workflowId, 'taskIndex':data.taskIndex , 'notes':data.notes })
#           if (len(results) ==0):
#                   raise HTTPException(status_code=404, detail="Incorrect Input")
#           results= results[0][0]
#           date_obj_to_string(results)
#           return results
#   else:
#       return {"NOT AUTHENTICATED or Invalid Token"} 
