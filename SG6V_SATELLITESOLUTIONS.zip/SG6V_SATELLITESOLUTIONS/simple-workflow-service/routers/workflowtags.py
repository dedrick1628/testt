import json
import OasSpec
from utils.authentication import hasAccess
from routersUtils.dbquery import run_cypher_query
from routersUtils.nexttaskhelper import get_next_task

# Imporatant imports to get the properties used to generate the Task Class
from fastapi import Request
from datetime import datetime

from fastapi import FastAPI, Depends, HTTPException, APIRouter, FastAPI, HTTPException, Query, Path

import json
from neomodel import config, db
from datetime import datetime
from typing import ClassVar, Optional, List
import json
import OasSpec
from utils.authentication import hasAccess
import re

from pydantic import BaseModel, Field, JsonValue, StrictInt, Extra, ConfigDict, StringConstraints, constr
from typing import List, Dict, Annotated, Any
from datetime import date
import uuid
import os
from dotenv import load_dotenv
# Imporatant imports to get the properties used to generate the Task Class
from neomodel import (config, StructuredNode, StringProperty, IntegerProperty, UniqueIdProperty, RelationshipTo, StructuredRel, UniqueIdProperty, DateTimeFormatProperty, JSONProperty, ArrayProperty, BooleanProperty)
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from fastapi import Request
from starlette.status import HTTP_400_BAD_REQUEST

from fastapi import FastAPI, Depends, HTTPException
from fastapi import FastAPI, HTTPException, Body, Query, Path
import routers.allworkflows as allworkflows
import routers.allworkflowsnexttask as allworkflowsnexttask
import routers.nexttask as nexttask
import routers.alltasks as alltasks
import routers.numversion as numversion
import routers.gettask as gettask
import routers.starttask as starttask

from fastapi import FastAPI, Depends, HTTPException, APIRouter, FastAPI, HTTPException, Body, Query, Path

import json

router = APIRouter()

app = OasSpec.app
## SHOULD BE THEIR OWN CLASS INHERITED BY ALL ENDPOINTS

# this is used to load the custom openapi json to fit the FirstAPI guidelines
valid_pattern = Annotated [str, StringConstraints(pattern=r"^[A-Za-z0-9_-]{1,32}$")]

class workflowTagsData(BaseModel):
    workflowTags : Annotated[ List [valid_pattern], Field ( default=None, min_length=1, max_length=250, description='Workflow Tags, the list of Tags associated with the Workflow')] 
    workflowId: str = Field(min_length=1, max_length=250 , description='WorkflowID', pattern="^[A-Za-z0-9]{1,32}$")

    model_config = ConfigDict(extra='forbid')







@router.post("/workflow-tags", tags=["Add or Overide Workflow Tags"], responses = {
    
 "200": {
                        "description": "Ok",
                        "content": {
                            "application/json": {
                                "schema": {
                                    "type": "object",
                                    "properties": {
                                        "workflowTags": {
                                            "type": "string",
                                            "description": "Workflow Tags",
                                            "minLength": 1,
                                            "maxLength": 100
                                        }
                                    },
                                    "additionalProperties": False
                                }
                            }
                        }
                    },
403: {"description": "Forbidden"}, 
404: {"description": "Not Found"}, 
401: {"description": "Unauthorized"}, 
415: {"description": "Unsupported Media Type"}, 
504: {"description": "Gateway Timeout"},   
400: {"description": "Ok","content": {
             "application/json": {
               "schema": {
                 "$ref": "#/components/schemas/WorkflowData"
               }
             }
           }},
 
})



async def worklfow_tags( data: Annotated[
 workflowTagsData, Body( ),
   ],hasAccess : dict= Depends(hasAccess)):
 
    
  """
         Operation to **Add** a workflow tag to a worklfow (only the latest version) Input:  **Workflow ID**,**WorkflowTag**  Note: If Input Data is initalized, this will overide it!  
  """
  
  if hasAccess and hasAccess is not None:
    teamId , _ = hasAccess  
    query= '''Match (n:Task  {workflowId:$workflowId}) 
            WITH max(n.workflowVersion) as max
            Match (n:Task  {workflowVersion : max, workflowId:$workflowId, teamId:$teamId})
            WHERE n.workflowId=$workflowId AND n.teamId = $teamId 
            
            
            SET n.workflowTags = $workflowTags
            Return n.workflowTags'''
    results,meta = run_cypher_query(query, {'teamId': teamId , 'workflowId':data.workflowId, 'workflowTags':data.workflowTags })
    if (len(results) ==0):
           raise HTTPException(status_code=404, detail="Incorrect Input")
            
    results= results[0][0]
    return {"workflowTags": results } 

     
  else:
      return {"NOT AUTHENTICATED or Invalid Token"}       
