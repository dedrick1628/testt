import json
import OasSpec
from routersUtils.miscUtils import get_value_from_json_string
from utils.authentication import hasAccess
from routersUtils.dbquery import run_cypher_query
from routersUtils.nexttaskhelper import get_next_task

# Imporatant imports to get the properties used to generate the Task Class
from fastapi import Request

from fastapi import FastAPI, Depends, HTTPException, APIRouter, FastAPI, HTTPException, Query, Path

import json


router = APIRouter()

app = OasSpec.app
## SHOULD BE THEIR OWN CLASS INHERITED BY ALL ENDPOINTS

# this is used to load the custom openapi json to fit the FirstAPI guidelines












@router.get("/next-task/workflow-id/{workflowId}", tags=["next-task"], responses = {
    
 200: {"description": "Ok","content": {
                            "application/json": {
                                "schema": {
                                    "type": "object",
                                    "properties": {
                                        "items": {
                                            "type": "array",
                                            "minItems": 0,
                                            "maxItems": 1000,
                                            "description": "This key will actually be the workflow ID of the array object inside of it.", 
                                            "items": {
                                                "type": "object",
                                                "properties": {

                                                    "workflowId": {
                                                        "type": "string",
                                                        "description": "Workflow ID",
                                                        "minLength": 0,
                                                        "maxLength": 100
                                                    },
                                                    "taskDateDue": {
                                                        "type": "string",
                                                        "description": "task Due Date",
                                                        "minLength": 0,
                                                        "maxLength": 100
                                                    },
                                                     "workflowDateDue": {
                                                        "type": "string",
                                                        "description": "Workflow Due Date",
                                                        "minLength": 0,
                                                        "maxLength": 100
                                                    },
                                                     "workflowDateCompleted": {
                                                        "type": "string",
                                                        "description": "Workflow Completion Date",
                                                        "minLength": 0,
                                                        "maxLength": 100
                                                    },
                                                    "taskIndex": {
                                                        "type": "integer",
                                                        "description": "Task ID",
                                                        "format": "int64"
                                                    },
                                                     "taskName": {
                                                        "type": "string",
                                                        "description": "Task Name",
                                                        "minLength": 0,
                                                        "maxLength": 100
                                                    },
                                                      "workflowName": {
                                                        "type": "string",
                                                        "description": "workflowName",
                                                        "minLength": 0,
                                                        "maxLength": 100
                                                    }
                                                },
                                                "additionalProperties": False,
                                                "required": [
                                                    "workflowId",
                                                    "taskDateDue",
                                                    "workflowDateDue",
                                                    "taskName",
                                                    "taskIndex",
                                                    "workflowName"

                                                ]
                                            }
                                        }
                                    },
                                    "additionalProperties": False
                                }
                            }
                        }},
403: {"description": "Forbidden"},
404: {"description": "Not Found"}, 
204 : {"description": "No Content"}, 

401: {"description": "Unauthorized"}, 
415: {"description": "Unsupported Media Type"}, 
504: {"description": "Gateway Timeout"},   
400: {"description": "Ok","content": {
             "application/json": {
               "schema": {
                 "$ref": "#/components/schemas/WorkflowData"
               }
             }
           }},
 
})


async def next_task( request: Request, workflowId: str  = Path( description="The TeamID should be Passed here", regex='^[A-Za-z0-9]{1,32}$'), task_allowed_user: str= Query( None, description='''The Allowed user role should be Passed here. The syntax should follow this format: {"taskAllowedUser": ["role1","role2"]}''', regex="^.{1,1048}$"), hasAccess : dict= Depends(hasAccess) ):
    """
      Operation to **Retrieve** the next task to do in a workflow (latest version). Input:  **Workflow ID**  
    """
    print(hasAccess)
    query_params = request.query_params
    keys_list = list(query_params.keys())
    for key in keys_list:
      if len(query_params.getlist(key))>1  :
        raise HTTPException(status_code=400, detail="Bad Request can not pass an array")
    if task_allowed_user and task_allowed_user is not None:
      
        task_allowed_user = get_value_from_json_string(task_allowed_user,"taskAllowedUser")
        output = (await get_next_task(workflowId,task_allowed_user , hasAccess))
    else:
        output = (await get_next_task(workflowId,task_allowed_user , hasAccess))

    if output == "Incorrect Input: Workflow doesn't exist!":
       raise HTTPException(status_code=400, detail="All tasks are completed or Workflow doesn't exist")
    if output == "All task are completed":
       raise HTTPException(status_code=204, detail="All task are completed")
    return output
 