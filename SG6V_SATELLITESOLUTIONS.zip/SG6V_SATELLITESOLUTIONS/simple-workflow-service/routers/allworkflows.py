import json
import OasSpec
from routersUtils.miscUtils import date_obj_to_string
from utils.authentication import hasAccess
from routersUtils.dbquery import run_cypher_query

# Imporatant imports to get the properties used to generate the Task Class
from fastapi import Request

from fastapi import FastAPI, Depends, HTTPException, APIRouter, FastAPI, HTTPException, Query

import json


router = APIRouter()
app = FastAPI( dependencies=[ Depends(hasAccess)])
## SHOULD BE THEIR OWN CLASS INHERITED BY ALL ENDPOINTS

# this is used to load the custom openapi json to fit the FirstAPI guidelines
app = OasSpec.app












@router.get("/all-workflows",    tags=['all-workflows'],  responses = {
 200: {"description": "Ok","content": {
                            "application/json": {
                                "schema": {
                                    "type": "object",
                                    "properties": {
                                             "workflows": {
                                                        "type": "array",
                                                        "minItems": 0,
                                                        "maxItems": 1000,
                                                        "description": "Operation to get all the Workflows for a client. Input: **Client**", 
                                                        "items": {
                                                        "type": "object",
                                                        "properties": {
                                                            "workflowName": {
                                                                "type": "string",
                                                                "description": "Workflow Name",
                                                                "minLength": 0,
                                                                "maxLength": 100
                                                            },
                                                            "workflowDateDue": {
                                                                "type": "string",
                                                                "description": "Workflow Due Date",
                                                                "minLength": 0,
                                                                "maxLength": 100
                                                            },
                                                            "workflowId": {
                                                                "type": "string",
                                                                "description": "Workflow ID",
                                                                "minLength": 0,
                                                                "maxLength": 100
                                                            }
                                                        },
                                                        "additionalProperties": False
                                                    }
                                                }

                                             
                                       
                                      
                                    },
                                    "additionalProperties": False
                                }
                            }
                        }},
403: {"description": "Forbidden"}, 
404: {"description": "Not Found"}, 
401: {"description": "Unauthorized"}, 
415: {"description": "Unsupported Media Type"}, 
504: {"description": "Gateway Timeout"}, 
404: {"description": "Not Found"}, 
401: {"description": "Unauthorized"}, 
415: {"description": "Unsupported Media Type"}, 
504: {"description": "Gateway Timeout"},   
400: {"description": "Bad Request"}
 
    
})
# async def read_root(  teamId:  Annotated[str, Path(description="The ID of the item to get" , regex='^[A-Za-z0-9]{1,32}$')], hasAccess : dict= Depends(hasAccess)):

async def all_workflows(   request: Request, workflow_tags: str= Query( None, description='''The workflowTags should be Passed here. The syntax should follow this format: {"workflowTags": ["Tag1","Tag2"]}''', regex="^.{1,1048}$"),task_allowed_user: str= Query( None, description='''The Allowed user role should be Passed here. The syntax should follow this format: {"taskAllowedUser": ["role1","role2"]}''', regex="^.{1,1048}$") ,hasAccess : dict= Depends(hasAccess), skip : int= Query( None, description="The number of items you want to skip should be Passed here",  ge=0, le=1000000), limit : int= Query( None, description="The number of items you want to return should be Passed here",  ge=1, le=100)):
  """
     Operation to get all the Workflows for a client. 
    """  
  if hasAccess and hasAccess is not None:
      print ("TeamID is: ", hasAccess)
      teamId , _ = hasAccess
      query_params = request.query_params
      keys_list = list(query_params.keys())
      for key in keys_list:
        if len(query_params.getlist(key))>1  :
            raise HTTPException(status_code=400, detail="Bad Request can not pass an array")
      if task_allowed_user and task_allowed_user is not None:
         json_string = task_allowed_user 
         try:
            task_allowed_user = json.loads(json_string)  
         except:
            raise HTTPException(status_code=400, detail="Wrong Json Syntax")
         try:
            task_allowed_user= task_allowed_user["taskAllowedUser"]
         except:
            print(task_allowed_user)
            raise HTTPException(status_code=400, detail="task_allowed_user Key was not provided, or key contains a typo")
      if workflow_tags and workflow_tags is not None:
         json_string = workflow_tags 
         try:
            workflow_tags = json.loads(json_string)  
         except:
            raise HTTPException(status_code=400, detail="Wrong Json Syntax")
         try:
            workflow_tags= workflow_tags["workflowTags"]
         except:
            print(workflow_tags)
            raise HTTPException(status_code=400, detail="workflow_tags Key was not provided, or key contains a typo")

      if (limit or skip) and (task_allowed_user is not None )and (workflow_tags is not None):
         if limit is None:
            limit = 100
         if skip is None:
            skip = 0
            
         query= '''Match (n:Task {teamId:$teamId})
          WITH n.workflowId as workflowId, max(n.workflowVersion) as max 
          MATCH (n:Task {workflowVersion : max, workflowId : workflowId,teamId:$teamId })  
          Where (ANY  (allowedUsers IN $taskAllowedUser Where  allowedUsers IN n.taskAllowedUser ) ) AND  (all  (workflowTags IN $workflowTags Where workflowTags IN n.workflowTags ) )
         Return DISTINCT n.workflowName , n.workflowDateDue , n.workflowId
          skip $skip limit $limit '''
         results,meta = run_cypher_query(query, {'teamId': teamId , "skip": skip, "limit": limit, "taskAllowedUser":task_allowed_user , "workflowTags": workflow_tags})


      elif (task_allowed_user is not None) and (workflow_tags is not None):
         if limit is None:
            limit = 100
         if skip is None:
            skip = 0
            
         query= '''Match (n:Task  {teamId:$teamId})
          WITH n.workflowId as workflowId, max(n.workflowVersion) as max 
          Match (n:Task  {workflowVersion : max, workflowId : workflowId,teamId:$teamId })  
          Where (ANY  (allowedUsers IN $taskAllowedUser Where  allowedUsers IN n.taskAllowedUser ) ) AND  (all  (workflowTags IN $workflowTags Where workflowTags IN n.workflowTags ) )
         Return DISTINCT n.workflowName , n.workflowDateDue , n.workflowId
          skip $skip limit $limit '''
         results,meta = run_cypher_query(query, {'teamId': teamId , "skip": skip, "limit": limit, "taskAllowedUser":task_allowed_user , "workflowTags": workflow_tags})

    
      elif (limit or skip) and (task_allowed_user is not None):
         if limit is None:
            limit = 100
         if skip is None:
            skip = 0
            
         query= '''Match (n:Task  {teamId:$teamId})
          WITH n.workflowId as workflowId, max(n.workflowVersion) as max 
          Match (n:Task  {workflowVersion : max, workflowId : workflowId,teamId:$teamId })  
          Where (ANY  (allowedUsers IN $taskAllowedUser Where  allowedUsers IN n.taskAllowedUser ) ) 
          Return DISTINCT n.workflowName , n.workflowDateDue , n.workflowId
          skip $skip limit $limit '''
         results,meta = run_cypher_query(query, {'teamId': teamId , "skip": skip, "limit": limit, "taskAllowedUser":task_allowed_user })
         
      elif (limit or skip) and (workflow_tags is not None):
         if limit is None:
            limit = 100
         if skip is None:
            skip = 0
            
         query= '''Match (n:Task  {teamId:$teamId})
          WITH n.workflowId as workflowId, max(n.workflowVersion) as max 
          Match (n:Task  {workflowVersion : max, workflowId : workflowId,teamId:$teamId })  
          Where (all  (workflowTags IN $workflowTags Where workflowTags IN n.workflowTags ) )
          Return DISTINCT n.workflowName , n.workflowDateDue , n.workflowId
          skip $skip limit $limit '''
         results,meta = run_cypher_query(query, {'teamId': teamId , "skip": skip, "limit": limit, "workflowTags":workflow_tags })
      elif (limit or skip) :
         if limit is None:
            limit = 100
         if skip is None:
            skip = 0
         query= '''Match (n:Task  {teamId:$teamId})
          WITH n.workflowId as workflowId, max(n.workflowVersion) as max 
          Match (n:Task  {workflowVersion : max, workflowId : workflowId,teamId:$teamId })  
            
          Return DISTINCT n.workflowName , n.workflowDateDue , n.workflowId
          skip $skip limit $limit '''        
         results,meta = run_cypher_query(query, {'teamId': teamId , "skip": skip, "limit": limit})
      elif  (task_allowed_user is not None):
         if limit is None:
            limit = 100
         if skip is None:
            skip = 0
            
         query= '''Match (n:Task  {teamId:$teamId})
          WITH n.workflowId as workflowId, max(n.workflowVersion) as max 
          Match (n:Task  {workflowVersion : max, workflowId : workflowId,teamId:$teamId })  
          Where (ANY  (allowedUsers IN $taskAllowedUser Where  allowedUsers IN n.taskAllowedUser ) ) 
          Return DISTINCT n.workflowName , n.workflowDateDue , n.workflowId
          skip $skip limit $limit '''
         results,meta = run_cypher_query(query, {'teamId': teamId , "skip": skip, "limit": limit, "taskAllowedUser":task_allowed_user })      

      elif  workflow_tags is not None:
         if limit is None:
            limit = 100
         if skip is None:
            skip = 0
            
         query= '''Match (n:Task  {teamId:$teamId})
          WITH n.workflowId as workflowId, max(n.workflowVersion) as max 
          Match (n:Task  {workflowVersion : max, workflowId : workflowId,teamId:$teamId })  
          Where (all  (workflowTags IN $workflowTags Where workflowTags IN n.workflowTags ) )
        Return DISTINCT n.workflowName , n.workflowDateDue , n.workflowId
          skip $skip limit $limit '''
         results,meta = run_cypher_query(query, {'teamId': teamId , "skip": skip, "limit": limit, "workflowTags":workflow_tags })          
      else:  
        query= '''Match (n:Task  {teamId:$teamId})
                WITH n.workflowId as workflowId, max(n.workflowVersion) as max 
                Match (n:Task  {workflowVersion : max, workflowId : workflowId,teamId:$teamId })   
                 Return DISTINCT n.workflowName , n.workflowDateDue , n.workflowId
                limit 100
               '''
        results,meta = run_cypher_query(query, {'teamId': teamId })
      if (len(results) ==0):
              raise HTTPException(status_code=404, detail="Incorrect Input")
      Formatted_Results = [{"workflowName":row[0], "workflowDateDue": row[1], "workflowId" : row[2]} for row in results]
      date_obj_to_string(Formatted_Results)
      return {"workflows": Formatted_Results}
  else :
      return {"NOT AUTHENTICATED or Invalid Token"}



