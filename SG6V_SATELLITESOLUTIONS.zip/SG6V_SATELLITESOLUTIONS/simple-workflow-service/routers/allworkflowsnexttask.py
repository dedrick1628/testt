import json
import OasSpec
from routersUtils.cypherGenAllWrkfNxtTsk import cypher_engine
# from routersUtils.cypherGen import add_allowed_user_to_cypher_query
from utils.authentication import hasAccess
from routersUtils.dbquery import run_cypher_query
from routersUtils.nexttaskhelper import get_next_task
# Imporatant imports to get the properties used to generate the Task Class
from fastapi import Request
from routersUtils.miscUtils import date_obj_to_string, get_json_obj_from_json_string, get_value_from_json_string

from fastapi import FastAPI, Depends, HTTPException, APIRouter, FastAPI, HTTPException, Query

import json

router = APIRouter()

app = OasSpec.app
## SHOULD BE THEIR OWN CLASS INHERITED BY ALL ENDPOINTS

# this is used to load the custom openapi json to fit the FirstAPI guidelines












@router.get("/all-workflows/next-task",  tags=["all-workflows/next-task"], responses = {
 
  200: {
                        "description": "Ok",
                        "content": {
                            "application/json": {
                                "schema": {
                                    "type": "object",
                                    "properties": {
                                        "allWorkflows": {
                                            "type": "array",
                                            "minItems": 0,
                                            "maxItems": 1000,
                                            "description": "This key will actually be the workflow ID of the array object inside of it.",
                                            "items": {
                                                "type": "array",
                                                "minItems": 0,
                                                "maxItems": 1000,
                                                "description": "This key will actually be the workflow ID of the array object inside of it.",
                                                "items": {
                                                    "type": "object",
                                                    "properties": {
                                                        "workflowId": {
                                                            "type": "string",
                                                            "description": "Workflow ID",
                                                            "minLength": 0,
                                                            "maxLength": 100
                                                        },
                                                        "taskDateDue": {
                                                            "type": "string",
                                                            "description": "task Due Date",
                                                            "minLength": 0,
                                                            "maxLength": 100
                                                        },
                                                        "workflowDateDue": {
                                                            "type": "string",
                                                            "description": "Workflow Due Date",
                                                            "minLength": 0,
                                                            "maxLength": 100
                                                        },
                                                        "workflowDateCompleted": {
                                                            "type": "string",
                                                            "description": "Workflow Completion Date",
                                                            "minLength": 0,
                                                            "maxLength": 100
                                                        },
                                                        "taskIndex": {
                                                            "type": "integer",
                                                            "description": "Task ID",
                                                            "format": "int64"
                                                        },
                                                        "taskName": {
                                                            "type": "string",
                                                            "description": "Task Name",
                                                            "minLength": 0,
                                                            "maxLength": 100
                                                        },
                                                        "workflowName": {
                                                            "type": "string",
                                                            "description": "workflowName",
                                                            "minLength": 0,
                                                            "maxLength": 100
                                                        },
                                                        "taskMetadata": {
                                                            "type": "string",
                                                            "description": "workflowName",
                                                            "minLength": 0,
                                                            "maxLength": 10000
                                                        }
                                                    },
                                                    "additionalProperties": False,
                                                    "required": [
                                                        "workflowId",
                                                        "taskDateDue",
                                                        "workflowDateDue",
                                                        "taskName",
                                                        "taskIndex",
                                                        "workflowName"
                                                    ]
                                                },
                                                "additionalProperties": False
                                            },
                                            "additionalProperties": False
                                        }
                                    },
                                    "additionalProperties": False
                                }
                            }
                        }
                    },
403: {"description": "Forbidden"}, 
404: {"description": "Not Found"}, 
401: {"description": "Unauthorized"}, 
415: {"description": "Unsupported Media Type"}, 
504: {"description": "Gateway Timeout"},   
400: {"description": "Bad Request"}
 
    
})

async def all_workflows_next_task(  request: Request, filter: str= Query( None, description='''The filter json should be passed here. The syntax is flexible. ie: "taskMetadata": {"assignedUser": {"name": "alpha", "email": "alpha@email.com"}}, "taskName":"ACCEPT_ACCESS_ORDER"''', regex="^.{1,4096}$"), sort: str= Query( None, description='''The sort variable should be Passed here. Output can be sorted by ONE of the following: taskmetadata, taskDateDue, workflowDateDue, taskName, and workflowId ''', regex="^.{1,1048}$")  , sort_by_ascending: str= Query( None, description='''The a boolean string should be passed here to indicate Ascending or Descending (Default Ascending if not used)''', regex="^.{1,5}$")  ,hasAccess : dict= Depends(hasAccess), skip : int= Query( None, description="The number of items you want to skip should be Passed here",  ge=0, le=1000000), limit : int= Query( None, description="The number of items you want to return should be Passed here",  ge=1, le=100)):
  """
     Operation to get all the Workflows for a client. 
    """  
  if hasAccess and hasAccess is not None:
      print ("TeamID is: ", hasAccess)
      teamId , _ = hasAccess
      _ = get_json_obj_from_json_string(filter)
      try:
       results,meta = cypher_engine(request,teamId)
      except:

         print("Something wrong with the cypher_engine")

      if (len(results) ==0):
              return []

      results  = [sub[0] for sub in results]  
      date_obj_to_string(results)
      return  {"allWorkflows":results}
  else :
      return {"NOT AUTHENTICATED or Invalid Token"}





