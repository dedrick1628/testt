# from neomodel import config, db
from datetime import datetime
from typing import ClassVar, Optional, List
import json
# from utils.authentication import hasAccess
import neo4j.time
from pydantic import BaseModel, Field, JsonValue, StrictInt, Extra, ConfigDict, StringConstraints, constr
from typing import List, Dict, Annotated, Any
from datetime import date
import uuid
import os
from dotenv import load_dotenv
# Imporatant imports to get the properties used to generate the Task Class
# from neomodel import (config, StructuredNode, StringProperty, IntegerProperty, UniqueIdProperty, RelationshipTo, StructuredRel, UniqueIdProperty, DateTimeFormatProperty, JSONProperty, ArrayProperty, BooleanProperty)
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from fastapi import Request
from starlette.status import HTTP_400_BAD_REQUEST

from fastapi import FastAPI, Depends, HTTPException, APIRouter, FastAPI, HTTPException, Body, Query, Path

import json



def get_value_from_json_string(json_string, key):
  """Converts a JSON string to a dictionary and returns the value associated with the given key.

  Args:
    json_string: The JSON string to parse.
    key: The key to search for in the JSON object.

  Returns:
    The value associated with the key in the JSON object, or None if the key is not found.
  """
  try:
    data = json.loads(json_string)
  except json.JSONDecodeError:
        raise HTTPException(status_code=400, detail="Wrong Json Syntax")
  try:
    return data.get(key)
  except:
       print(key)
       raise HTTPException(status_code=400, detail=" parameter Key was not provided, or key contains a typo")
  


def get_json_obj_from_json_string(json_string):
  """Converts a JSON string to a dictionary and returns a dictionary

  Args:
    json_string: The JSON string to parse.
    key: The key to search for in the JSON object.

  Returns:
    The dictionary
  """
  if json_string:
    try:
      data = json.loads(json_string)
    except json.JSONDecodeError:
          raise HTTPException(status_code=400, detail="Wrong Json Syntax")
    return data
  else: 
    return None 
  


def formats_string(date):
  #  year = date["_DateTime__date"]["_Date__year"]
  #  month = date["_DateTime__date"]["_Date__month"]
  #  day = date["_DateTime__date"]["_Date__day"]
  #  hour = date["_DateTime__time"]["_Time__hour"]
  #  min = date["_DateTime__time"]["_Time__minute"]
  #  sec = date["_DateTime__time"]["_Time__second"]
  #  my_date = datetime(year, month, day,hour,min,sec)
   my_date = date.to_native()
   my_date = datetime.strftime(my_date, "%Y-%m-%d %H:%M:%S")
#    list_keys =[]
#    for key,_ in dates.items():
#         list_keys.append(key)
#    print(type(dates))
#    if isinstance(dates, str):
#        print(dates)
   return my_date



def date_obj_to_string(data_structure):


    keys= ["taskDateDue","taskDateCreated","taskDateCompleted","taskDateStarted","workflowDateDue","workflowDateCompleted", "taskRequestedDueDate"]

    if isinstance(data_structure, dict):
        for key, value in data_structure.items():
            # Check if the current key is one of the target keys
            if(key in keys)  & (isinstance(value,neo4j.time.DateTime) ): # For efficiency, pass target_keys as a set
                 data_structure[key] = formats_string(value)

            # Regardless of whether the key was a target,
            # if the value is a collection, recurse into it.
            if isinstance(value, (dict, list)):
                date_obj_to_string(value)

    elif isinstance(data_structure, list):
        for item in data_structure:
            # If an item in the list is a collection, recurse into it.
            # The "target_keys" logic applies when the recursion hits a dictionary.
            if isinstance(item, (dict, list)):
                date_obj_to_string(item)
    return data_structure
def is_valid_date(date: str) -> datetime:
  try:
      if date is not None:
        date =   datetime.strptime(date   , "%Y-%m-%d %H:%M:%S")
        return date
      else:
        date = None
        return date
  except ValueError:
      raise HTTPException(status_code=400, detail="One or more of the dates are not valid. Please use this syntax: YYYY MM DD HH:MM:SS")


# json_string = ''' [
#     {
#         "sub": "28a46595-7606-488f-bd30-3c5f430f391c",
#         "taskIndex": 1,
#         "taskAllowedUser": [
#             "ROLE_PROJECT_MANAGER"
#         ],
#         "workflowName": "ACCESS",
#         "taskDateDue": "2025-01-27 10:30:00",
#         "taskDateCreated": {
#             "_DateTime__date": {
#                 "_Date__ordinal": 739392,
#                 "_Date__year": 2025,
#                 "_Date__month": 5,
#                 "_Date__day": 21
#             },
#             "_DateTime__time": {
#                 "_Time__ticks": 75373601403000,
#                 "_Time__hour": 20,
#                 "_Time__minute": 56,
#                 "_Time__second": 13,
#                 "_Time__nanosecond": 601403000,
#                 "_Time__tzinfo": null
#             }
#         },
#         "workflowDateDue": "2025-01-20 10:30:00",
#         "teamId": "7cb04344-f715-4ff0-a9c8-a71e9a5f1d78",
#         "taskName": "ACCEPT_ACCESS_ORDER",
#         "workflowVersion": 1,
#         "workflowTags": [
#             "Active"
#         ],
#         "taskSla": 1,
#         "workflowId": "34100c8ddc32414ca85419592f458057"
#     },
#     {
#         "sub": "28a46595-7606-488f-bd30-3c5f430f391c",
#         "taskIndex": 2,
#         "taskAllowedUser": [
#             "ROLE_PROJECT_MANAGER"
#         ],
#         "workflowName": "ACCESS",
#         "taskDateDue": "2025-01-20 10:30:00",
#         "taskDateCreated": {
#             "_DateTime__date": {
#                 "_Date__ordinal": 739392,
#                 "_Date__year": 2025,
#                 "_Date__month": 5,
#                 "_Date__day": 21
#             },
#             "_DateTime__time": {
#                 "_Time__ticks": 75373661503000,
#                 "_Time__hour": 20,
#                 "_Time__minute": 56,
#                 "_Time__second": 13,
#                 "_Time__nanosecond": 661503000,
#                 "_Time__tzinfo": null
#             }
#         },
#         "workflowDateDue": "2025-01-20 10:30:00",
#         "teamId": "7cb04344-f715-4ff0-a9c8-a71e9a5f1d78",
#         "taskName": "ENTER_ESP_INFORMATION",
#         "workflowVersion": 1,
#         "workflowTags": [
#             "Active"
#         ],
#         "taskSla": 1,
#         "workflowId": "34100c8ddc32414ca85419592f458057"
#     },
#     {
#         "sub": "28a46595-7606-488f-bd30-3c5f430f391c",
#         "taskIndex": 3,
#         "taskAllowedUser": [
#             "ROLE_PROJECT_MANAGER",
#             "ROLE_CIRCUIT_ACTIVATION"
#         ],
#         "workflowName": "ACCESS",
#         "taskDateDue": "2025-01-20 10:30:00",
#         "taskDateCreated": {
#             "_DateTime__date": {
#                 "_Date__ordinal": 739392,
#                 "_Date__year": 2025,
#                 "_Date__month": 5,
#                 "_Date__day": 21
#             },
#             "_DateTime__time": {
#                 "_Time__ticks": 75373717540000,
#                 "_Time__hour": 20,
#                 "_Time__minute": 56,
#                 "_Time__second": 13,
#                 "_Time__nanosecond": 717540000,
#                 "_Time__tzinfo": null
#             }
#         },
#         "workflowDateDue": "2025-01-20 10:30:00",
#         "teamId": "7cb04344-f715-4ff0-a9c8-a71e9a5f1d78",
#         "taskName": "GENERATE_SITE_CODE",
#         "workflowVersion": 1,
#         "workflowTags": [
#             "Active"
#         ],
#         "taskSla": 1,
#         "workflowId": "34100c8ddc32414ca85419592f458057"
#     },
#     {
#         "sub": "28a46595-7606-488f-bd30-3c5f430f391c",
#         "taskIndex": 4,
#         "taskAllowedUser": [
#             "ROLE_CIRCUIT_ACTIVATION"
#         ],
#         "workflowName": "ACCESS",
#         "taskDateDue": "2025-01-20 10:30:00",
#         "taskDateCreated": {
#             "_DateTime__date": {
#                 "_Date__ordinal": 739392,
#                 "_Date__year": 2025,
#                 "_Date__month": 5,
#                 "_Date__day": 21
#             },
#             "_DateTime__time": {
#                 "_Time__ticks": 75373767740000,
#                 "_Time__hour": 20,
#                 "_Time__minute": 56,
#                 "_Time__second": 13,
#                 "_Time__nanosecond": 767740000,
#                 "_Time__tzinfo": null
#             }
#         },
#         "workflowDateDue": "2025-01-20 10:30:00",
#         "teamId": "7cb04344-f715-4ff0-a9c8-a71e9a5f1d78",
#         "taskName": "ACTIVATE_CIRCUIT",
#         "workflowVersion": 1,
#         "workflowTags": [
#             "Active"
#         ],
#         "taskSla": 1,
#         "workflowId": "34100c8ddc32414ca85419592f458057"
#     },
#     {
#         "sub": "28a46595-7606-488f-bd30-3c5f430f391c",
#         "taskIndex": 5,
#         "taskAllowedUser": [
#             "ROLE_PROJECT_MANAGER",
#             "ROLE_QA"
#         ],
#         "workflowName": "ACCESS",
#         "taskDateDue": "2025-01-20 10:30:00",
#         "taskDateCreated": {
#             "_DateTime__date": {
#                 "_Date__ordinal": 739392,
#                 "_Date__year": 2025,
#                 "_Date__month": 5,
#                 "_Date__day": 21
#             },
#             "_DateTime__time": {
#                 "_Time__ticks": 75373794617000,
#                 "_Time__hour": 20,
#                 "_Time__minute": 56,
#                 "_Time__second": 13,
#                 "_Time__nanosecond": 794617000,
#                 "_Time__tzinfo": null
#             }
#         },
#         "workflowDateDue": "2025-01-20 10:30:00",
#         "teamId": "7cb04344-f715-4ff0-a9c8-a71e9a5f1d78",
#         "taskName": "ENTER_ESP_DNS_ENTITY",
#         "workflowVersion": 1,
#         "workflowTags": [
#             "Active"
#         ],
#         "taskSla": 1,
#         "workflowId": "34100c8ddc32414ca85419592f458057"
#     },
#     {
#         "sub": "28a46595-7606-488f-bd30-3c5f430f391c",
#         "taskIndex": 6,
#         "taskAllowedUser": [
#             "ROLE_QA"
#         ],
#         "workflowName": "ACCESS",
#         "taskDateDue": "2025-01-20 10:30:00",
#         "taskDateCreated": {
#             "_DateTime__date": {
#                 "_Date__ordinal": 739392,
#                 "_Date__year": 2025,
#                 "_Date__month": 5,
#                 "_Date__day": 21
#             },
#             "_DateTime__time": {
#                 "_Time__ticks": 75373822058000,
#                 "_Time__hour": 20,
#                 "_Time__minute": 56,
#                 "_Time__second": 13,
#                 "_Time__nanosecond": 822058000,
#                 "_Time__tzinfo": null
#             }
#         },
#         "workflowDateDue": "2025-01-20 10:30:00",
#         "teamId": "7cb04344-f715-4ff0-a9c8-a71e9a5f1d78",
#         "taskName": "VALIDATE_CIRCUIT",
#         "workflowVersion": 1,
#         "workflowTags": [
#             "Active"
#         ],
#         "taskSla": 1,
#         "workflowId": "34100c8ddc32414ca85419592f458057"
#     },
#     {
#         "sub": "28a46595-7606-488f-bd30-3c5f430f391c",
#         "taskIndex": 7,
#         "taskAllowedUser": [
#             "ROLE_NETWORK_MANAGEMENT_CENTER"
#         ],
#         "workflowName": "ACCESS",
#         "taskDateDue": "2025-01-20 10:30:00",
#         "taskDateCreated": {
#             "_DateTime__date": {
#                 "_Date__ordinal": 739392,
#                 "_Date__year": 2025,
#                 "_Date__month": 5,
#                 "_Date__day": 21
#             },
#             "_DateTime__time": {
#                 "_Time__ticks": 75373830261000,
#                 "_Time__hour": 20,
#                 "_Time__minute": 56,
#                 "_Time__second": 13,
#                 "_Time__nanosecond": 830261000,
#                 "_Time__tzinfo": null
#             }
#         },
#         "workflowDateDue": "2025-01-20 10:30:00",
#         "teamId": "7cb04344-f715-4ff0-a9c8-a71e9a5f1d78",
#         "taskName": "ACCEPT_FOR_MANAGEMENT",
#         "workflowVersion": 1,
#         "workflowTags": [
#             "Active"
#         ],
#         "taskSla": 1,
#         "workflowId": "34100c8ddc32414ca85419592f458057"
#     }
# ]'''
# python_dict = json.loads(json_string)

# date_obj_to_string(python_dict)
# print(python_dict)      