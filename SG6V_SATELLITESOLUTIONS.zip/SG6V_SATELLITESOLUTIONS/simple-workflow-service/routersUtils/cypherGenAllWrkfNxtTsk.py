from neomodel import config, db
from datetime import datetime
from typing import ClassVar, Optional, List
import json
from routersUtils.dbquery import run_cypher_query
from utils.authentication import hasAccess
import re

from pydantic import BaseModel, Field, JsonValue, StrictInt, Extra, ConfigDict, StringConstraints, constr
from typing import List, Dict, Annotated, Any
from datetime import date
import uuid
import os
from dotenv import load_dotenv
# Imporatant imports to get the properties used to generate the Task Class
from neomodel import (config, StructuredNode, StringProperty, IntegerProperty, UniqueIdProperty, RelationshipTo, StructuredRel, UniqueIdProperty, DateTimeFormatProperty, JSONProperty, ArrayProperty, BooleanProperty)
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from fastapi import Request
from starlette.status import HTTP_400_BAD_REQUEST

from fastapi import FastAPI, Depends, HTTPException
from fastapi import FastAPI, HTTPException, Body, Query, Path
from fastapi import FastAPI, Depends, HTTPException, APIRouter, FastAPI, HTTPException, Body, Query, Path
from routersUtils.miscUtils import get_json_obj_from_json_string, get_value_from_json_string, is_valid_date
import json



## class that contains operations needed for handling filtering parameters
class filter_json_input:


# constant dictionary to match the parameter key received by the user to the parameter key expected by Neo4j DB
   API_native_parameters_to_Cypher_parameters ={
   "taskAllowedUser":  '''((ANY  (allowedUsers IN $taskAllowedUser Where  allowedUsers IN n.taskAllowedUser ) ) OR (n.taskAllowedUser	 IS NULL OR size(n.taskAllowedUser	) = 0)) ''' ,
   "workflowTags":'''(all  (workflowTags IN $workflowTags Where workflowTags IN n.workflowTags ) ) ''', 
   "workflowId": ''' LOWER(n.workflowId) contains LOWER($workflowId)  ''',
   "workflowName": ''' LOWER(n.workflowName) contains LOWER($workflowName)  ''',
   "workflowDateDue": ''' n.workflowDateDue = $workflowDateDue  ''',
   "taskName": ''' LOWER(n.taskName) contains  LOWER($taskName)  ''',
   "taskDateDue": ''' n.taskDateDue = $taskDateDue  ''',
   "taskDateCreated": ''' n.taskDateCreated = $taskDateCreated  ''',
   "taskDateStarted": ''' n.taskDateStarted = $taskDateStarted  ''',
   "taskRequestedDueDate": ''' n.taskRequestedDueDate = $taskRequestedDueDate  ''',
   "taskSla": ''' n.taskSla = $taskSla  ''',
   "taskCompletedBy": ''' n.taskCompletedBy = $taskCompletedBy  ''',
   "notes": ''' n.notes = $notes  ''',
   }
   API_native_parameters_to_Cypher_parameters_conditional_date_approved_keys = {

        "taskDateStarted": ["gt", "lt", "gte", "lte" , "nin"],
      "taskDateDue": ["gt", "lt", "gte", "lte" , "nin"],
      "taskDateCreated": ["gt", "lt", "gte", "lte" , "nin"]
   }
   API_native_parameters_to_Cypher_parameters_conditional_numbers_approved_keys ={
      # "taskDateStarted": ["gt", "lt", "gte", "lte" , "nin"],
      # "taskDateDue": ["gt", "lt", "gte", "lte" , "nin"],
      # "taskDateCreated": ["gt", "lt", "gte", "lte" , "nin"],
      "taskSla": ["gt", "lt", "gte", "lte" , "nin"]
   }

   TYPE_OPERATOR_COMPATIBILITY = {
    'numeric': {'eq', 'ne', 'gt', 'gte', 'lt', 'lte', 'in', 'isNull', 'isNotNull'},
    'string': {'eq', 'ne', 'in', 'startsWith', 'endsWith', 'contains', 'regex', 'isNull', 'isNotNull'},
    'localdatetime': {'eq', 'ne', 'gt', 'gte', 'lt', 'lte', 'isNull', 'isNotNull'},
    'date': {'eq', 'ne', 'gt', 'gte', 'lt', 'lte', 'isNull', 'isNotNull'},
    'boolean': {'eq', 'ne', 'isNull', 'isNotNull'}
    # Using sets for efficient 'in' checks
}
   FIELD_TYPE_MAP = {
    # Datetime fields
    'taskDateCreated': 'localdatetime',
    'taskDateStarted': 'localdatetime',
    'workflowDateDue': 'localdatetime',
    'taskDateDue': 'localdatetime',
    'taskRequestedDueDate': 'localdatetime',

    # Numeric fields
    'taskSla': 'numeric',

    # Default is string, so we don't have to list them all
    'workflowId': 'string',
    'workflowName': 'string',
    'taskName': 'string',
    'taskCompletedBy': 'string',
    'notes': 'string'
}
   OPERATORS = {
    # -------------------------------------
    # Standard Comparison Operators
    # -------------------------------------
    "eq": "=",                  # Equal
    "ne": "<>",                 # Not Equal
    "lt": "<",                  # Less Than
    "lte": "<=",                # Less Than or Equal To
    "gt": ">",                  # Greater Than
    "gte": ">=",                # Greater Than or Equal To

    # -------------------------------------
    # String Comparison Operators
    # -------------------------------------
    # Note: These are case-sensitive in Cypher.
    # For case-insensitivity, you would typically use lower() or upper()
    # on both sides, or use regex with a case-insensitive flag.
    "startsWith": "STARTS WITH", # String starts with a given substring
    "endsWith": "ENDS WITH",     # String ends with a given substring
    "contains": "CONTAINS",      # String contains a given substring
    "regex": "=~",               # Matches a regular expression (e.g., "n.name =~ 'Tim.*'")


    # These operators typically don't take a value, so your builder
    # logic will need to handle them differently (i.e., not add a parameter).
    "isNull": "IS NULL",          # Property's value is null (or property does not exist)
    "isNotNull": "IS NOT NULL"    # Property exists and its value is not null
}
   API_native_parameters_to_Cypher_parameters_conditional_approved_keys = API_native_parameters_to_Cypher_parameters_conditional_date_approved_keys | API_native_parameters_to_Cypher_parameters_conditional_numbers_approved_keys
   operational_conditions_to_cypher = {
    # The lambda function takes 'prop_name' and 'param_name' as arguments
    "gt":  lambda prop_name : f" n.{prop_name} > ${prop_name} ",
    "lt":  lambda prop_name : f" n.{prop_name} < ${prop_name} ",
    "eq":  lambda prop_name : f" n.{prop_name} = ${prop_name} ",
    "in":  lambda prop_name: f" n.{prop_name} IN ${prop_name} ",
    "startsWith": lambda prop_name: f"n.{prop_name} STARTS WITH ${prop_name}"
    }
   TYPE_FUNCTIONS = {
    'localdatetime': lambda param: f"localdatetime(${param})",
}
   API_complex_parameters_to_Cypher_parameters ={   "taskMetadata": '''  with n, apoc.json.path(n.taskMetadata, $path) AS output Where output = $dataValue '''
}
# function that takes in the parameter key and the value passed to the endpoint and returns the partial Cypher query, the parameter key and the parameter value to Neo4j
   def filter_native_key(key,value):
      try:
            # matching the given parameter key to the neo4j parameter key needed
            mapped_key = key
            print("mapped_key",mapped_key )
            print("passed function value parameter", value)
            # converting the value given (string encoded json) and returns the value of the json value to the given disregarding the key 
            # passed_value = get_value_from_json_string(value,mapped_key)
            try:

               if key in filter_json_input.FIELD_TYPE_MAP:
                  if isinstance(value,dict):
                     for operation in value:
                        try:
    # 1. Get the operator symbol
                           operator_symbol = filter_json_input.OPERATORS.get(operation)
                           if not operator_symbol:
                              raise ValueError(f"Unknown operator: '{operation}'")

                           # 2. Get the property type
                           prop_type = filter_json_input.FIELD_TYPE_MAP.get(mapped_key, 'string')

                           # 3. *** NEW VALIDATION STEP ***
                           # Check if the operator is valid for the determined property type.
                           valid_operators_for_type = filter_json_input.TYPE_OPERATOR_COMPATIBILITY.get(prop_type)
                           if not valid_operators_for_type or operation not in valid_operators_for_type:
                              # This is where you catch the error!
                              raise ValueError(f"Operator '{operation}' is not valid for property '{mapped_key}' of type '{prop_type}'.")

                           # 4. Get the type-casting function (if any)
                           type_function = filter_json_input.TYPE_FUNCTIONS.get(prop_type)
                           print(type_function,"__ type function")
                           # 5. Determine the right-hand side of the expression
                           # (Handling for operators that don't take a value)
                           if operation == 'isNull':
                              if value[operation]: # Corresponds to "$isNull": true
                                 cypher_op = filter_json_input.OPERATORS['isNull']
                              else: # Corresponds to "$isNull": false
                                 cypher_op = filter_json_input.OPERATORS['isNotNull']
                              cypher_condition = f"n.{mapped_key} {cypher_op}"
                              partial_query = cypher_condition
                              partial_params_key ="no_key"
                              partial_params_val = "no_value"
                              return partial_query, partial_params_key,partial_params_val

                           if type_function:
                              right_hand_side = type_function(mapped_key)
                           else:
                              right_hand_side = f"${mapped_key}"

                           # 6. Compose the final Cypher clause
                           cypher_condition = f"n.{mapped_key} {operator_symbol} {right_hand_side}".strip()
                           
                           print(f"Successfully generated Cypher: {cypher_condition}")
                           if prop_type == "localdatetime":
                              print(" Date field added")
                              value[operation] = is_valid_date(value[operation])
                              value[operation] = value[operation].isoformat()
                           partial_query = cypher_condition
                           partial_params_key = mapped_key
                           partial_params_val = value[operation]
                           print("THIS IS THE TYPE OF PARTIAL -----", type(partial_params_val))




                           return partial_query, partial_params_key,partial_params_val
                        except ValueError as e:
                           # In a real API, you would catch this and return a 400 Bad Request
                           print(f"Error: {e}")
                        # if operation in filter_json_input.OPERATORS:
                        #    print("test")
                        #    print("key:", operation, filter_json_input.operational_conditions_to_cypher[operation](mapped_key))

                        #    # partial_query = filter_json_input.operational_conditions_to_cypher[operation](mapped_key)
                        #    # partial_params_key = mapped_key
                        #    # if mapped_key in filter_json_input.API_native_parameters_to_Cypher_parameters_conditional_date_approved_keys:
                        #    #       value[operation] = is_valid_date(value[operation])
                        #    #       value[operation] = value[operation].isoformat()
                        #    # partial_params_val = value[operation]
                        #    return partial_query, partial_params_key,partial_params_val




            except:
               print("error with deconstructing conditional json", key, "to output values and conditions ")   

            passed_value = value
            print("passed value is",passed_value )

            partial_query = filter_json_input.API_native_parameters_to_Cypher_parameters[key]
            partial_params_key = mapped_key
            partial_params_val = passed_value

               



            return partial_query, partial_params_key,partial_params_val
      except:
         print("error adding native", key, "to cypher query")   


   def json_path_generator(data, path ="$"):
      json_paths=[]
      values=[]
      if isinstance(data,dict):
         for key, val in data.items():
            new_path = f"{path}.{key}"
            sub_path, sub_val = filter_json_input.json_path_generator(val, new_path)
            json_paths.extend(sub_path)
            values.extend(sub_val)
      elif isinstance(data,list):
         for index, item in enumerate(data):
            new_path = f"{path}.{index}"
            sub_path, sub_val = filter_json_input.json_path_generator(item, new_path)
            json_paths.extend(sub_path)
            values.extend(sub_val)
      else:
         json_paths.append(path)
         values.append(data)
      return json_paths, values


   def filter_object_key (key,value):
      try:
            # matching the given parameter key to the neo4j parameter key needed
            mapped_key = key
            # converting the value given (string encoded json) and returns the value of the json value to the given disregarding the key 
            print("value is: ", value)
            # passed_value = get_json_obj_from_json_string(value)
            passed_value = value
            print("passed value is",passed_value )
            partial_query_list = []
            partial_params_val = []
            partial_params_key = []

            json_paths_list, values_list = filter_json_input.json_path_generator(passed_value,path ="$")
            print("Json_path_lists are: ", json_paths_list)
            print("values_list are: ", values_list )
            for index ,item in enumerate(json_paths_list):
               path = filter_json_input.API_complex_parameters_to_Cypher_parameters[mapped_key]
               key = item
               key = key.replace(".","", 1)
               key = key.replace(".","_")
               

               item= "\"" + item + "\""
               path = path.replace("$path", item)
               path = path.replace("$dataValue",key  )
               partial_query_list.append(path)
               try:
                  print("value that will we be added: ", values_list[index])
               except:
                  print("something wrong with values_list")
               partial_params_val.append(values_list[index])
               key = key.replace("$","")

               partial_params_key.append(key) 
               print("partial_query_list: ",partial_query_list)
               print("partial_params_key: ",partial_params_key)
               print("partial_params_val: ",partial_params_val)
            return partial_query_list, partial_params_key ,partial_params_val
      except:
         print("error adding complex ", key, "to cypher query")   



# This is the cypher query template starting that takes in the teamId, and automatically searches for tasks in the most recent workflow 
query_start_template = ''' Match (n:Task {teamId:$teamId})
          WITH n.workflowId as workflowId, max(n.workflowVersion) as max
          MATCH (n:Task {workflowVersion : max, workflowId : workflowId,teamId:$teamId })  ''' 

# Helper function to get all the parameter keys and values from a request passed to the endpoint          
def get_all_params(request: Request):
    try:
      query_params = request.query_params
      keys_list = list(query_params.keys())
      key_value_pair = {}
      for key in keys_list:

         if len(query_params.getlist(key))>1:
            raise HTTPException(status_code=400, detail="Bad Request can not pass an array")
         else:
            key_value_pair[key] = query_params.getlist(key)[0]
      return key_value_pair
    except:
       print("error getting all params")

# helper function that takes in the API reqeust as input and outputs the paging cypher statement as well as the parameterized values needed by neo4j       
def return_cypher_paging(request: Request):
   print(request)
   key_value_pair="this is empty"
   key_value_pair = get_all_params(request)
   cypher_query_list = []
   cypher_param_list = {}
   # sort_direction = " ASC "

   try:
    
        
      for key in query_pageing:
         if key in key_value_pair:
            return_stment,param_key,param_val = query_pageing[key](key_value_pair[key])
            cypher_query_list.append(return_stment)
            cypher_param_list[param_key] = param_val
      if "limit" not in key_value_pair:
         return_stment,param_key,param_val = query_pageing["limit"](100)
         cypher_param_list["limit"]   = param_val
         # possibly needs to be -1 to put at end of lis
         cypher_query_list.append(return_stment)
      seperator = " "
      paging_statement = seperator.join(cypher_query_list)
      return paging_statement, cypher_param_list
   except:
      print("error returning cypher paging: ", key_value_pair,cypher_query_list)


# helper function that takes in the API reqeust as input and outputs the filtering cypher statement as well as the parameterized values needed by neo4j       
      
def return_cypher_filter_and_params(request: Request):
   try:
     cypher_query_list = []
     cypher_param_list = {}
     key_value_pair = {}
     try:      
            allParams = get_all_params(request)
            print("allParams are: ",allParams)
            filters_obj = get_jsonOBj_from_request_params_key("filter", allParams)
            print("result of filters obj", filters_obj)
            if filters_obj is not None:
                   print("filters_obj is not NONE!")
                   key_value_pair = get_json_obj_from_json_string(filters_obj)
                   print("key value pair filter", key_value_pair)

     except:
         print("issue with parameterization")
     for key in complex_param_handlers_filters:
        if  key in key_value_pair:
           list_return_stment,list_param_key, list_param_val  = complex_param_handlers_filters[key](key,key_value_pair[key])
           for index,item in enumerate(list_return_stment):
                  cypher_query_list.append(item)
                  cypher_param_list[list_param_key[index]] = list_param_val[index]
     for key in primitive_param_handlers_filters:
        if key in key_value_pair:
            return_stment,param_key, param_val  = primitive_param_handlers_filters[key](key,key_value_pair[key])
            cypher_query_list.append(return_stment)
            cypher_param_list[param_key] = param_val
     return cypher_query_list, cypher_param_list
   except:
      print("error returning cypher filter and params")
def return_cypher_sort(request: Request):
   print(request)
   key_value_pair="this is empty"
   key_value_pair = get_all_params(request)

   sort_direction = " ASC "          
   sortbyAscending =  key_value_pair.get("sort_by_ascending")
   if sortbyAscending is not None:
      sortbyAscending =  sortbyAscending.lower()
      if(sortbyAscending == "false"):
         sort_direction = " Desc "
      else:
         sort_direction = " ASC "
   try:
         sort = key_value_pair.get("sort")
         if sort in  query_pageing:
            return_stment = query_pageing[sort](sort)
            
            try: 
               return_stment = return_stment + sort_direction

               return return_stment
            except:
                  print("error with sortbyAscending parameter")   
         else:
            if sort is not None and "." in sort:
               json_path = sort[sort.find("."):]
               node_pr = sort[:sort.find(".")]
               sort =  "$" +json_path
               return_stment = f"with Distinct n, apoc.json.path(n.{node_pr}, '{json_path}') AS targetValue ORDER BY targetValue" + sort_direction
               return return_stment
            else:
               return "Order by n.workflowId Asc"


   except:
         print("There's an issue with the sort")  
# helper function that constructs and outputs limit statement, and the parametrized variables (key and value) given the limit input (str or int) 
def add_query_limit( limit_input):
    try:
       
      limit = limit_input
      if isinstance(limit, str):
         limit  = int(limit)
      return_statement = "limit $limit"
      partial_params_key = "limit"
      partial_params_val = limit

      return  return_statement, partial_params_key, partial_params_val

    except:
       print(" error adding query limit")
 # helper function that constructs and outputs limit statement, and the parametrized variables (key and value) given the limit input (str or int) 
      
def add_query_skip(skip_input):
    try:
      skip = skip_input
      if isinstance(skip, str):
         skip = int(skip)
      return_statement = "skip $skip"
      partial_params_key = "skip"
      partial_params_val = skip
      
      return  return_statement, partial_params_key, partial_params_val
    except:
       print("error adding query skip")


def add_query_sort(sort_input:str):
    try:
      excludedSpace =" "
      sort = "n." + sort_input
      return_statement = "Order by " + sort
      
      return return_statement
    except:
       print("error adding query skip")


# dictionary that calls the filter function (input: parameter key) to help construct the filter statement for each condition passed as a parameter 
query_filters ={
"task_allowed_user" : filter_json_input.filter_native_key,
"workflow_tags" : filter_json_input.filter_native_key,
}


def get_jsonOBj_from_request_params_key ( paramKey:str ,key_value_pair: dict):
   values =  key_value_pair.get(paramKey)
   return values


 




primitive_param_handlers_filters = {
"workflowId" : filter_json_input.filter_native_key,
"workflowName" : filter_json_input.filter_native_key,
"workflowDateDue" : filter_json_input.filter_native_key,
"taskName" : filter_json_input.filter_native_key,
"taskDateDue" : filter_json_input.filter_native_key,
"taskDateCreated" : filter_json_input.filter_native_key,
"taskDateStarted" : filter_json_input.filter_native_key,
"taskSla" : filter_json_input.filter_native_key,
"taskAllowedUser" : filter_json_input.filter_native_key,
"taskCompletedBy" : filter_json_input.filter_native_key,
"notes" : filter_json_input.filter_native_key,
# "workflowVersion" : filter_json_input.filter_native_key,
"workflowTags":filter_json_input.filter_native_key,

}


complex_param_handlers_filters = {
"taskMetadata" : filter_json_input.filter_object_key,
"taskDeliverable" : filter_json_input.filter_object_key,
"taskInput" : filter_json_input.filter_object_key,
}

query_pageing = {
"taskMetadata": add_query_sort,
"taskDateDue": add_query_sort,
"workflowDateDue": add_query_sort,
"taskName":add_query_sort,
"workflowName":add_query_sort,
"workflowId":add_query_sort,
"skip": add_query_skip,
"limit": add_query_limit,
}

query_sort = {

"limit": add_query_limit,
}



def cypher_where_statement(where_clauses: List):
    try: 
      where_statement = ""
      listOfWithStmnts = []
      withStmnts =""
      if len(where_clauses)>0:
         print()
         for item in where_clauses:
            if "with" in item:
               listOfWithStmnts.append(item)
            else: 
               break   
         if len(listOfWithStmnts)>0:
            for item in listOfWithStmnts:
               withStmnts = " " + withStmnts + item + " "
            where_statement =  withStmnts 
            for item in where_clauses:
               if "with" not in item:
                  where_statement = where_statement + " AND " + item
         else:
            where_statement = " WHERE n.workflowDateCompleted is Null "
            for item in where_clauses:
               if "with" not in item:
                  where_statement = where_statement + " AND " + item
      else:
         where_statement = " WHERE n.workflowDateCompleted is Null "
      

      return where_statement

    except:
        print("error in cypher where function delimeter")

# helper function that glues the where cypher clauses, paging clauses and all the parameters clauses and sends the query and params to the DB
def cypher_gluer(where_clauses: List,  cypher_param_list: dict, paging_clause: str, paging_param_list: dict , sort:str = None):
   try:
      query_ending= " with Distinct n  " +" with n.workflowId as wfId, collect(n) as tasksInWorkflow with wfId, tasksInWorkflow "+ ''' UNWIND tasksInWorkflow as n
MATCH (n )-[NEXT_TASK]-(b)
WHERE (NOT ()-->(n) AND n.taskDateCompleted is null  ) OR (n.taskDateCompleted is null  AND ALL(m IN [(m)-->(n) | m] WHERE m.taskDateCompleted is NOT null))
with Distinct n ''' + sort + '''  With n.workflowId as wfId, collect( {taskIndex: n.taskIndex, workflowId: n.workflowId, taskName: n.taskName, taskDateDue: n.taskDateDue,  workflowDateDue: n.workflowDateDue, workflowName: n.workflowName, taskMetadata: n.taskMetadata}) as filteredTasks

Return (filteredTasks) ''' +  paging_clause
      query = query_start_template+cypher_where_statement(where_clauses) + query_ending
      params = cypher_param_list | paging_param_list
      print("the query is: ", query)
      print("the params are: ", params)
      return run_cypher_query(query,params)

   except:   
      print("error in cypher gluer")


      
# callable function that creates, calls and returns the cypher qeury result to be used by the router
def cypher_engine(request: Request, teamId):

   try:
      sort  = return_cypher_sort( request)
      paging_statement, cypher_param_list_paging = return_cypher_paging(request)
      print("paging statment:", paging_statement )
      cypher_query_list, cypher_param_list_where = return_cypher_filter_and_params(request)
      print("cypher query list", cypher_query_list )
      cypher__param_template = {'teamId': teamId}
      cypher_param_list_where.update(cypher__param_template)
      return cypher_gluer(cypher_query_list,cypher_param_list_where,paging_statement,cypher_param_list_paging, sort)
   except:
      print("error in cypher engine")


