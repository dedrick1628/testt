import sys
from neomodel import config, db
from datetime import datetime
from typing import ClassVar, Optional, List
import json
import OasSpec
from utils.authentication import hasAccess
import re

from pydantic import BaseModel, Field, FiniteFloat, JsonValue, StrictInt, Extra, ConfigDict, StringConstraints, constr
from typing import List, Dict, Annotated, Any
from datetime import date
import uuid
import os
from dotenv import load_dotenv
# Imporatant imports to get the properties used to generate the Task Class
from neomodel import (config, StructuredNode, StringProperty, IntegerProperty, UniqueIdProperty, RelationshipTo, StructuredRel, UniqueIdProperty, DateTimeFormatProperty, JSONProperty, ArrayProperty, BooleanProperty)
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from fastapi import Request
from starlette.status import HTTP_400_BAD_REQUEST

from fastapi import FastAPI, Depends, HTTPException
from fastapi import FastAPI, HTTPException, Body, Query, Path
from fastapi import FastAPI, Depends, HTTPException, APIRouter, FastAPI, HTTPException, Body, Query, Path

import json

valid_pattern = Annotated [str, StringConstraints(pattern=r"^[A-Za-z0-9_-]{1,32}$")]

class TaskData(BaseModel):
    taskName : str = Field(min_length=1, max_length=250 , description='Task Name', pattern=".+" )
    taskDateDue: str = Field(min_length=1, max_length=250, description='Task Due Date', pattern="^\d{4}-\d{2}-\d{2}\s\d{2}:\d{2}:\d{2}$")
    taskIndex: StrictInt = Field(..., format='int32', description='Task ID')
    taskInput:JsonValue = None
    taskMetadata:JsonValue = None
    taskDeliverable:JsonValue = None
    taskCompletedBy :str = Field(default=None,min_length=1, max_length=250, description='Task Completed by Field', pattern="^[a-zA-Z0-9\s\-:_@.]{1,100}$")
    taskAllowedUser : Annotated[ List [valid_pattern], Field ( default=None, min_length=1, max_length=250, description='Task Allowed User, the liist of User Roles permitted to see the Task')] 
    taskSla: FiniteFloat  = Field( default=None, format='double', description='Task SLA', ge=0,le=sys.float_info.max) 
    notes: str = Field(default=None,min_length=1, max_length=250, description='Task Notes', pattern=".+")
    connectsTo: List[int] = Field( default=None, format='int64', min_length=1, max_length=250, description='Task connections') 
    model_config = ConfigDict(extra='forbid')

 # This is a class created for FastAPI to generate variables as json fields, passed in the POST statement.    

class WorkflowData(BaseModel):
    workflowName : str = Field(min_length=1, max_length=250, description='Workflow Name', pattern=".+")
    workflowDateDue: str = Field(min_length=1, max_length=250, description='Workflow Due Date',  pattern="^\d{4}-\d{2}-\d{2}\s\d{2}:\d{2}:\d{2}$")
    workflowTags : Annotated[ List [valid_pattern], Field ( default=None, min_length=1, max_length=250, description='Task Allowed User, the liist of User Roles permitted to see the Task')] 
    model_config = ConfigDict(extra='forbid')


class response(BaseModel):
    response : str = Field(min_length=1, max_length=250, default= "Response Worked")
    


class updateData(BaseModel):
    workflowId: str = Field(min_length=1, max_length=250 , description='WorkflowID', pattern="^[A-Za-z0-9]{1,32}$")
    # teamId: str = Field(min_length=1, max_length=250, description='TeamID', pattern="^[A-Za-z0-9]{1,32}$")
    taskIndex: StrictInt = Field(..., format='int64', description='Task ID', ge=0, le=10000)
    taskInput:JsonValue = None
    taskDeliverable:JsonValue = None

    notes: str = Field(default=None,min_length=1, max_length=250, description='Task Notes', pattern=".+")
    model_config = ConfigDict(extra='forbid')

class updateMetadata(BaseModel):
    workflowId: str = Field(min_length=1, max_length=250 , description='WorkflowID', pattern="^[A-Za-z0-9]{1,32}$")
    taskIndex: StrictInt = Field(..., format='int64', description='Task ID' , ge=0, le=10000)
    taskMetadata:JsonValue = None
    model_config = ConfigDict(extra='forbid')    

class workflowTagsData(BaseModel):
    workflowTags : Annotated[ List [valid_pattern], Field ( default=None, min_length=1, max_length=250, description='Task Allowed User, the liist of User Roles permitted to see the Task')] 
    workflowId: str = Field(min_length=1, max_length=250 , description='WorkflowID', pattern="^[A-Za-z0-9]{1,32}$")

    model_config = ConfigDict(extra='forbid')

