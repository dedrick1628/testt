import json
import OasSpec
from routersUtils.miscUtils import date_obj_to_string
from utils.authentication import hasAccess
from routersUtils.dbquery import run_cypher_query

# Imporatant imports to get the properties used to generate the Task Class
from fastapi import Request

from fastapi import FastAPI, Depends, HTTPException, APIRouter, FastAPI, HTTPException, Query, Path
from neomodel import config, db
from datetime import datetime
from typing import ClassVar, Optional, List
import json
import OasSpec
from utils.authentication import hasAccess
import re

from pydantic import BaseModel, Field, JsonValue, StrictInt, Extra, ConfigDict, StringConstraints, constr
from typing import List, Dict, Annotated, Any
from datetime import date
import uuid
import os
from dotenv import load_dotenv
# Imporatant imports to get the properties used to generate the Task Class
from neomodel import (config, StructuredNode, StringProperty, IntegerProperty, UniqueIdProperty, RelationshipTo, StructuredRel, UniqueIdProperty, DateTimeFormatProperty, JSONProperty, ArrayProperty, BooleanProperty)
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from fastapi import Request
from starlette.status import HTTP_400_BAD_REQUEST

from fastapi import FastAPI, Depends, HTTPException
from fastapi import FastAPI, HTTPException, Body, Query, Path
import routers.allworkflows as allworkflows
from fastapi import FastAPI, Depends, HTTPException, APIRouter, FastAPI, HTTPException, Body, Query, Path

import json

import json
from routersUtils.dbquery import run_cypher_query


router = APIRouter(
    prefix="/all-workflows",
    tags=['all-workflows']
)
app = OasSpec.app
## SHOULD BE THEIR OWN CLASS INHERITED BY ALL ENDPOINTS

# this is used to load the custom openapi json to fit the FirstAPI guidelines


valid_pattern = Annotated [str, StringConstraints(pattern=r"^[A-Za-z0-9_-]{1,32}$")]

async def get_next_task( workflowId: str  = Path( description="The TeamID should be Passed here", regex='^[A-Za-z0-9]{1,32}$'), task_allowed_user:  List [valid_pattern] = Query ( default=None, min_length=1, max_length=250, description='Task Allowed User, the dyt of User Roles permitted to see the Task'), hasAccess : dict= Depends(hasAccess) ):
    
  
  """
   Operation to **Retrieve** the next task to do in a workflow (latest version). Input:  **Workflow ID**  
  """
  
  if hasAccess and hasAccess is not None:
      teamId , _ = hasAccess
      query= '''MATCH (t:Task {workflowId:$workflowId, teamId: $teamId })
                

                RETURN DISTINCT t.workflowId

        '''
      results,meta = run_cypher_query(query, {'teamId': teamId , 'workflowId':workflowId})
      if (len(results) ==0):
                incorrect_out = "Incorrect Input: Workflow doesn't exist!"
                return incorrect_out      
      if task_allowed_user is not None:
          
          query= '''MATCH (t:Task {workflowId:$workflowId})-[NEXT_TASK]-(b)
                  WITH max(t.workflowVersion) as max
                  MATCH (t:Task {workflowVersion : max, workflowId:$workflowId, teamId: $teamId })
                  WHERE (NOT ()-->(t) AND t.taskDateCompleted is null  AND (t.workflowId= $workflowId AND t.teamId =$teamId AND  ( ANY  (allowedUsers IN $taskAllowedUser Where  allowedUsers IN t.taskAllowedUser ) 	)    ))
                  OR (t.taskDateCompleted is null AND (t.workflowId= $workflowId AND t.teamId =$teamId AND  (ANY  (allowedUsers IN $taskAllowedUser Where  allowedUsers IN t.taskAllowedUser ) 	 ) ) AND ALL(m IN [(m)-->(t) | m] WHERE m.taskDateCompleted is NOT null))
                
                  RETURN DISTINCT t.workflowId as workflowId,t.taskIndex as taskIndex, t.taskName as taskName, t.taskDateDue as Task_Due_Date, t.workflowDateDue,  t.workflowName, t.taskMetadata
          '''
   
          results,meta =run_cypher_query(query, {'teamId': teamId , 'workflowId':workflowId, 'taskAllowedUser': task_allowed_user})

          if (len(results) ==0):
                incorrect_out = "All task are completed"
                return incorrect_out
        #   Formatted_Results = [{"workflowId": row[0], "taskIndex":row[1],"taskName":row[2], "taskDateDue": row[3],"workflowDateDue": row[4],"workflowDateCompleted": row[5], "workflowName": row[6] } for row in results]


          Formatted_Results = [{"workflowId": row[0], "taskIndex":row[1],"taskName":row[2], "taskDateDue": row[3],"workflowDateDue": row[4], "workflowName": row[5], "taskMetadata": row[6] } for row in results]
          date_obj_to_string(Formatted_Results)

          return Formatted_Results 
      else:
          query= '''MATCH (t:Task {workflowId:$workflowId})-[NEXT_TASK]-(b)
                  WITH max(t.workflowVersion) as max
                  MATCH (t:Task {workflowVersion : max, workflowId:$workflowId, teamId: $teamId})
                  WHERE (NOT ()-->(t) AND t.taskDateCompleted is null  AND (t.workflowId= $workflowId AND t.teamId =$teamId))
                  OR (t.taskDateCompleted is null AND (t.workflowId= $workflowId AND t.teamId =$teamId) AND ALL(m IN [(m)-->(t) | m] WHERE m.taskDateCompleted is NOT null))
                
                  RETURN DISTINCT t.workflowId as workflowId,t.taskIndex as taskIndex, t.taskName as taskName, t.taskDateDue as Task_Due_Date, t.workflowDateDue, t.workflowName, t.taskMetadata
        
          '''
          results,meta = run_cypher_query(query, {'teamId': teamId , 'workflowId':workflowId})
          if (len(results) ==0):
                  incorrect_out = "All task are completed"
                  return incorrect_out

          Formatted_Results = [{"workflowId": row[0], "taskIndex":row[1],"taskName":row[2], "taskDateDue": row[3],"workflowDateDue": row[4], "workflowName": row[5] , "taskMetadata": row[6]  } for row in results]
          date_obj_to_string(Formatted_Results)

          return  Formatted_Results 
  else:
      return {"NOT AUTHENTICATED or Invalid Token"} 
