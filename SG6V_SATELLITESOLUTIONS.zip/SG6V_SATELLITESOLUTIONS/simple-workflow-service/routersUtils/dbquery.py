from neomodel import config, db
from datetime import datetime
from typing import ClassVar, Optional, List
import json
import OasSpec
from utils.authentication import hasAccess

from pydantic import BaseModel, Field, JsonValue, StrictInt, Extra, ConfigDict, StringConstraints, constr
from typing import List, Dict, Annotated, Any
from datetime import date
import uuid
import os
from dotenv import load_dotenv
# Imporatant imports to get the properties used to generate the Task Class
from neomodel import (config, StructuredNode, StringProperty, IntegerProperty, UniqueIdProperty, RelationshipTo, StructuredRel, UniqueIdProperty, DateTimeFormatProperty, JSONProperty, ArrayProperty, BooleanProperty)
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from fastapi import Request
from starlette.status import HTTP_400_BAD_REQUEST

from fastapi import FastAPI, Depends, HTTPException, APIRouter, FastAPI, HTTPException, Body, Query, Path

import json


def run_cypher_query(query, parameters = None):
   if  parameters is not None:
     try:
         results,meta = db.cypher_query(query, parameters)
         return results, meta
     except:
         raise HTTPException(status_code=503, detail="Database is down. We're working on bringing it back up")

   else:
     try:
         results,meta = db.cypher_query(query)
         return results, meta
     except:
         raise HTTPException(status_code=503, detail="Database is down. We're working on bringing it back up")

