import Axios from "axios";
import apiUrls from "./apiURLConstants";

export default Axios.create({
  withCredentials: false,
  headers: {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET,PUT,POST,DELETE,PATCH,OPTIONS",
  },
});

async function handleResponse(response) {
  if (
    (response.ok || response.status === 200) &&
    response.headers.get("Content-Type") === "application/vnd.ms-excel"
  )
    return response.blob();
  if (
    (response.ok || response.status === 200) &&
    response.headers.get("Content-Type") === "application/json"
  )
    return response.json();
  if (response.ok || response.status === 200) return response.text();
  if (response.status === 404) return response.json();
  if (response.status === 400) {
    const error = await response.text();
    throw new Error(error);
  }
  throw new Error("Network Error!!!");
}

async function handleXmlResponse(response) {
  if (response.ok || response.status === 200) return response.text();
  if (response.status === 404) return response.json();
  if (response.status === 400) {
    const error = await response.text();
    throw new Error(error);
  }
  throw new Error("Network Error!!!");
}

async function handleByteResponse(response) {
  return response;
}

async function handleError(error) {
  console.error("API Call Failed ." + error.message);
  throw new Error("Network Error!!!");
}

export function get(url, eventReq = {}) {
  const selectedEnv = sessionStorage.getItem("selectedEnvironment");

  let req = {
    userName: sessionStorage?.getItem("order360UserName") || "",
    pageName: eventReq.pageName,
    tabName: eventReq.tabName,
    action: eventReq.action,
    url: url,
    sessionId: sessionStorage?.getItem("order360sessionId") || "",
  };
  if (
    !url.includes("flowthru/trendCount") &&
    !url.includes("flowthru/layout/segment?flowType")
  ) {
    if (url.includes("job?userid")) {
      req = {
        userName: sessionStorage?.getItem("order360UserName") || "",
        pageName: "Programs",
        tabName: "Reports",
        action: "getuserid",
        url: url,
        request: "userid",
        sessionId: sessionStorage?.getItem("order360sessionId") || "",
      };
      postLogging(req);
    } else if (url.includes("actions/category/PENDING")) {
      req = {
        userName: sessionStorage?.getItem("order360UserName") || "",
        pageName: "Pending Orders",
        tabName: "Fallout Orders",
        action: "Fetch Pending Orders",
        url: url,
        request: "",
        sessionId: sessionStorage?.getItem("order360sessionId") || "",
      };
      postLogging(req);
    } else if (url.includes("flowthru/layout/flowType?userid")) {
      req = {
        userName: sessionStorage?.getItem("order360UserName") || "",
        pageName: "Funnels View",
        tabName: "Funnels",
        action: "Fetch All Reports Name",
        url: url,
        request: "",
        sessionId: sessionStorage?.getItem("order360sessionId") || "",
      };
      postLogging(req);
    } else if (url.includes("getFalconReflowDetails?date")) {
      req = {
        userName: sessionStorage?.getItem("order360UserName") || "",
        pageName: "Correction Queue",
        tabName: "Correction Queue",
        action: "Fetch All Pipelines",
        url: url,
        request: "",
        sessionId: sessionStorage?.getItem("order360sessionId") || "",
      };
      postLogging(req);
    } else postLogging(req);
  }

  // const env = selectedEnv ? selectedEnv : 'prod';
  const env = selectedEnv ? selectedEnv : apiUrls.defaultEnv;
  return fetch(url, {
    method: "GET",
    headers: {
      "Content-Type": "application/json",
      "Access-Control-Allow-Origin": "*",
      env: env,
    },
  })
    .then(handleResponse)
    .catch(handleError);
}

export function post(
  url,
  request,
  eventReq = {},
  contentType = "application/json"
) {
  const selectedEnv = sessionStorage.getItem("selectedEnvironment");

  let req = {
    userName: sessionStorage?.getItem("order360UserName") || "",
    pageName: eventReq.pageName,
    tabName: eventReq.tabName,
    action: eventReq.action,
    url: url,
    request: request,
    sessionId: sessionStorage?.getItem("order360sessionId") || "",
  };
  if (
    !url.includes("flowthru") &&
    !url.includes("flowthru/trendCount") &&
    !url.includes("flowthru/layout/flowType") &&
    Object.keys(eventReq)?.length > 0
  ) {
    if (url.includes("getDashboardData")) {
      req = {
        userName: sessionStorage?.getItem("order360UserName") || "",
        pageName: "SWITCH FALLOUTS",
        tabName: "Monitoring",
        action: "get switch fallouts",
        url: url,
        request: "",
        sessionId: sessionStorage?.getItem("order360sessionId") || "",
      };
      postLogging(req);
    } else if (url.includes("recordorder/statistics")) {
      req = {
        userName: sessionStorage?.getItem("order360UserName") || "",
        pageName: "Record Order Audit",
        tabName: "Monitoring",
        action: "get record order audit",
        url: url,
        request: "",
        sessionId: sessionStorage?.getItem("order360sessionId") || "",
      };
      postLogging(req);
    } else if (url.includes("summary/visa-card/get-metrics-data")) {
      if (request.reportName === "FWA") {
        req = {
          userName: sessionStorage?.getItem("order360UserName") || "",
          pageName: "FWA",
          tabName: "Monitoring",
          action: "Fetch FWA Metrics",
          url: url,
          request: "",
          sessionId: sessionStorage?.getItem("order360sessionId") || "",
        };
        postLogging(req);
      } else if (request.reportName === "VISACARD")
        req = {
          userName: sessionStorage?.getItem("order360UserName") || "",
          pageName: "Visa Card",
          tabName: "Monitoring",
          action: "Fetch Visa Card Summary",
          url: url,
          request: "",
          sessionId: sessionStorage?.getItem("order360sessionId") || "",
        };
      postLogging(req);
    } else {
      postLogging(req);
    }
  }

  // const env = selectedEnv ? selectedEnv : 'prod';
  const env = selectedEnv ? selectedEnv : apiUrls.defaultEnv;
  let headers = {
    "Content-Type": contentType,
    "Access-Control-Allow-Origin": "localhost:3000",
    env: env,
  };
  if (contentType === "application/pdf") {
    headers = { env: env };
  } else if (contentType === "multipart") {
    headers = { Accept: "application/json" };
  }
  return fetch(url, {
    method: "POST",
    headers,
    body:
      contentType === "application/json" ? JSON.stringify(request) : request,
  })
    .then(handleResponse)
    .catch(handleError);
}

// Below method is for text response
export function postCall(url, request, contentType = "application/json") {
  const selectedEnv = sessionStorage.getItem("selectedEnvironment");
  const env = selectedEnv ? selectedEnv : apiUrls.defaultEnv;
  let headers = {
    "Content-Type": contentType,
    "Access-Control-Allow-Origin": "localhost:3000",
    env: env,
  };
  return fetch(url, {
    method: "POST",
    headers,
    body:
      contentType === "application/json" ? JSON.stringify(request) : request,
  })
    .then(async (response) => {
      return await response?.text();
    })
    .catch(handleError);
}

export function patch(url, request) {
  const selectedEnv = sessionStorage.getItem("selectedEnvironment");

  let req = {
    userName: sessionStorage?.getItem("order360UserName") || "",
    dashboard: "",
    tabName: "",
    url: url,
    request: request,
    sessionId: sessionStorage?.getItem("order360sessionId") || "",
  };
  postLogging(req);

  // const env = selectedEnv ? selectedEnv : 'prod';
  const env = selectedEnv ? selectedEnv : apiUrls.defaultEnv;
  return fetch(url, {
    method: "PATCH",
    headers: {
      "Content-Type": "application/json",
      "Access-Control-Allow-Origin": "*",
      env: env,
    },
    body: JSON.stringify(request),
  })
    .then(handleResponse)
    .catch(handleError);
}

export function putCall(url, request) {
  const selectedEnv = sessionStorage.getItem("selectedEnvironment");
  let req = {
    userName: sessionStorage?.getItem("order360UserName") || "",
    dashboard: "",
    tabName: "",
    url: url,
    request: request,
    sessionId: sessionStorage?.getItem("order360sessionId") || "",
  };
  postLogging(req);
  const env = selectedEnv ? selectedEnv : apiUrls.defaultEnv;
  // const env = selectedEnv ? selectedEnv : 'prod';
  return fetch(url, {
    method: "PUT",
    headers: {
      "Content-Type": "application/json",
      "Access-Control-Allow-Origin": "*",
      env: env,
    },
    body: JSON.stringify(request),
  })
    .then(handleResponse)
    .catch(handleError);
}

export function deleteCall(url) {
  const selectedEnv = sessionStorage.getItem("selectedEnvironment");

  let req = {
    userName: sessionStorage?.getItem("order360UserName") || "",
    dashboard: "delete call",
    tabName: "",
    url: url,
    request: "",
    sessionId: sessionStorage?.getItem("order360sessionId") || "",
  };
  postLogging(req);

  // const env = selectedEnv ? selectedEnv : 'prod';
  const env = selectedEnv ? selectedEnv : apiUrls.defaultEnv;
  return fetch(url, {
    method: "DELETE",
    headers: {
      "Content-Type": "application/json",
      "Access-Control-Allow-Origin": "*",
      env: env,
    },
  })
    .then(handleResponse)
    .catch(handleError);
}

export function deleteApi(url, request) {
  const selectedEnv = sessionStorage.getItem("selectedEnvironment");

  let req = {
    userName: sessionStorage?.getItem("order360UserName") || "",
    dashboard: "delete call",
    tabName: "",
    url: url,
    request: "",
    sessionId: sessionStorage?.getItem("order360sessionId") || "",
  };
  postLogging(req);

  // const env = selectedEnv ? selectedEnv : 'prod';
  const env = selectedEnv ? selectedEnv : apiUrls.defaultEnv;
  return fetch(url, {
    method: "DELETE",
    headers: {
      "Content-Type": "application/json",
      "Access-Control-Allow-Origin": "*",
      env: env,
    },
    body: JSON.stringify(request),
  })
    .then(handleResponse)
    .catch(handleError);
}

export function fetchbyte(url, request) {
  const selectedEnv = sessionStorage.getItem("selectedEnvironment");

  let req = {
    userName: sessionStorage?.getItem("order360UserName") || "",
    dashboard: "",
    tabName: "",
    url: url,
    request: request,
    sessionId: sessionStorage?.getItem("order360sessionId") || "",
  };
  postLogging(req);

  const env = selectedEnv ? selectedEnv : apiUrls.defaultEnv;
  // const env = selectedEnv ? selectedEnv : 'prod';
  return fetch(url, {
    method: "POST",
    responseType: "blob",
    headers: {
      "Content-Type": "application/json",
      "Access-Control-Allow-Origin": "*",
      env: env,
    },
    body: JSON.stringify(request),
  })
    .then((response) => {
      return response.blob();
    })
    .then(handleByteResponse)
    .catch(handleError);
}

export function fetchXml(url, request) {
  const selectedEnv = sessionStorage.getItem("selectedEnvironment");

  let req = {
    userName: sessionStorage?.getItem("order360UserName") || "",
    dashboard: "",
    tabName: "",
    url: url,
    request: request,
    sessionId: sessionStorage?.getItem("order360sessionId") || "",
  };
  postLogging(req);

  // const env = selectedEnv ? selectedEnv : 'prod';
  const env = selectedEnv ? selectedEnv : apiUrls.defaultEnv;
  return fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Access-Control-Allow-Origin": "*",
      env: env,
    },
    body: JSON.stringify(request),
  })
    .then(handleXmlResponse)
    .catch(handleError);
}

export function fetchFile(url, request, file) {
  const selectedEnv = sessionStorage.getItem("selectedEnvironment");

  let req = {
    userName: sessionStorage?.getItem("order360UserName") || "",
    dashboard: "",
    tabName: "",
    url: url,
    request: request,
    sessionId: sessionStorage?.getItem("order360sessionId") || "",
  };
  postLogging(req);

  // const env = selectedEnv ? selectedEnv : 'prod';
  const env = selectedEnv ? selectedEnv : apiUrls.defaultEnv;
  let filename = file || "";
  return fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Expose-Headers": "Content-Disposition",
      env: env,
    },
    body: JSON.stringify(request),
  })
    .then((response) => {
      const disposition = response.headers.get("content-disposition");
      if (disposition) {
        filename = disposition.match(/filename=(.+)/)[1];
      }
      return response.blob();
    })
    .then((blob) => {
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = filename;
      document.body.appendChild(a); // we need to append the element to the dom -> otherwise it will not work in firefox
      a.click();
      a.remove(); //afterwards we remove the element again
    });
}

export function postGetJWT(url, request, authorization) {
  const selectedEnv = sessionStorage.getItem("selectedEnvironment");
  // const env = selectedEnv ? selectedEnv : 'prod';
  const env = selectedEnv ? selectedEnv : apiUrls.defaultEnv;
  return fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: authorization,
    },
    body: JSON.stringify(request),
  })
    .then(handleResponse)
    .catch(handleError);
}

export function postLogging(request) {
  let url = apiUrls.kibanalogging;
  const selectedEnv = sessionStorage.getItem("selectedEnvironment");

  const signout_time = sessionStorage.getItem("signout_time");
  console.log("signout_time:", signout_time);
  if (signout_time && signout_time < Date.now) {
    console.log("signout done....");
    url = apiUrls.searchUrl;
  }

  // const env = selectedEnv ? selectedEnv : 'prod';
  const env = selectedEnv ? selectedEnv : apiUrls.defaultEnv;
  return fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Access-Control-Allow-Origin": "*",
      env: env,
    },
    body: JSON.stringify(request),
  })
    .then(handleResponse)
    .catch(handleError);
}

export function callVsadVsMlmo(requestBody) {
  const selectedEnv = sessionStorage.getItem("selectedEnvironment");
  const env = selectedEnv ? selectedEnv : apiUrls.defaultEnv;
  const request = {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Access-Control-Allow-Origin": "*",
      env: env,
    },
    body: JSON.stringify(requestBody),
  };
  const url = apiUrls.compareVasdVsMlmo;

  return fetch(url, request);
}

async function handleFunnelResponse(response) {
  if (
    (response.ok || response.status === 200) &&
    response.headers.get("Content-Type") === "application/vnd.ms-excel"
  )
    return response.blob();
  if (
    (response.ok || response.status === 200) &&
    response.headers.get("Content-Type") === "application/json"
  )
    return response.json();
  if (response.ok || response.status === 200) return response.text();
  if (response.status >= 400 && response.status < 500) {
    const error = "400";
    return error;
  } else if (
    response.status >= 500 &&
    response.status < 600 &&
    response.status !== 504
  ) {
    const error = "500";
    return error;
  } else if (response.status === 504) {
    const error = "504";
    throw new Error(error);
  } else {
    return "Error";
  }
}

async function handleFunnelError(error) {
  console.error("API Call Failed ." + error);
  throw new Error(error);
}

export function postFunnelCall(
  url,
  request,
  eventReq = {},
  contentType = "application/json"
) {
  const selectedEnv = sessionStorage.getItem("selectedEnvironment");
  // const env = selectedEnv ? selectedEnv : 'prod';
  const env = selectedEnv ? selectedEnv : apiUrls.defaultEnv;
  let headers = {
    "Content-Type": contentType,
    "Access-Control-Allow-Origin": "localhost:3000",
    env: env,
  };
  if (contentType === "application/pdf") {
    headers = { env: env };
  } else if (contentType === "multipart") {
    headers = { Accept: "application/json" };
  }

  return fetch(url, {
    method: "POST",
    headers,
    body:
      contentType === "application/json" ? JSON.stringify(request) : request,
  })
    .then(handleFunnelResponse)
    .catch(handleFunnelError);
}

async function handleFunnelByteResponse(response) {
  if (response.status === 200) return response.blob();
  if (response.status === 404) return response;
  if (response.status === 400) {
    const error = await response.text();
    throw new Error(error);
  } else if (response.status === 504) {
    const error = "504";
    throw new Error(error);
  }
  throw new Error("Network Error!!!");
}

export function funnelFetchbyte(url, request) {
  const selectedEnv = sessionStorage.getItem("selectedEnvironment");

  let req = {
    userName: sessionStorage?.getItem("order360UserName") || "",
    dashboard: "",
    tabName: "",
    url: url,
    request: request,
    sessionId: sessionStorage?.getItem("order360sessionId") || "",
  };
  postLogging(req);

  const env = selectedEnv ? selectedEnv : apiUrls.defaultEnv;
  // const env = selectedEnv ? selectedEnv : 'prod';
  return fetch(url, {
    method: "POST",
    responseType: "blob",
    headers: {
      "Content-Type": "application/json",
      "Access-Control-Allow-Origin": "*",
      env: env,
    },
    body: JSON.stringify(request),
  })
    .then((response) => {
      return response;
    })
    .then(handleFunnelByteResponse)
    .catch(handleError);
}
