import React, { useState } from 'react';

// --- Default Data for Convenience ---
const initialJsonPayload = {
    "CTC": { "FLAG": "Y", "TIMESTAMP": "2025-09-05T12:00:00Z" },
    "MLMO": { "FLAG": "Y", "TIMESTAMP": "2025-09-05T10:00:00Z", "ACTIVATION": { "FLAG": "Y", "TIMESTAMP": "2025-09-05T10:01:00Z", "DETAILS": {} } },
    "SWITCH_ERROR": { "FLAG": "Y", "TIMESTAMP": "2025-09-05T09:00:00Z", "DETAILS": {} },
    "SIM_CHANGE": { "FLAG": "N", "TIMESTAMP": "2025-09-05T09:00:00Z", "DETAILS": {} },
    "IMEI_CHANGE": { "FLAG": "N", "TIMESTAMP": "2025-09-05T09:00:00Z", "DETAILS": {} },
    "SMDP_STATUS": { "FIRST_STATE": "D0", "FIRST_TIMESTAMP": "2025-09-05T09:30:00Z", "LAST_STATE": "IE", "LAST_TIMESTAMP": "2025-09-05T09:45:00Z" },
    "PRE_MLMO_ERROR": { "FLAG": "N", "TIMESTAMP": "2025-09-05T09:00:00Z", "DETAILS": {} },
    "PAYMENT_ISSUE": { "FLAG": "N", "TIMESTAMP": "2025-09-05T08:00:00Z", "DETAILS": {} },
    "SHIPMENT_ISSUE": { "FLAG": "N", "TIMESTAMP": "2025-09-05T09:00:00Z", "DETAILS": {} },
    "SEG2_ISSUE": { "FLAG": "N", "TIMESTAMP": "2025-09-05T09:00:00Z", "DETAILS": {} }
};


// --- Helper Component for Rendering Results ---
const ResultCard = ({ title, data }) => {
    if (!data) return null;

    const color = data.COLOR || 'gray';
    const colorClasses = {
        green: 'border-green-500 bg-green-50',
        red: 'border-red-500 bg-red-50',
        gray: 'border-gray-300 bg-gray-50'
    };

    return (
        <div className={`p-4 rounded-lg border-l-4 ${colorClasses[color]}`}>
            <h3 className="text-lg font-semibold text-gray-800">{title}</h3>
            <div className="mt-2 space-y-1 text-sm text-gray-700">
                {Object.entries(data).map(([key, value]) => {
                    if (typeof value === 'object' && value !== null) {
                        return (
                            <div key={key} className="mt-3 pl-4 border-l-2 border-gray-200">
                                <ResultCard title={key} data={value} />
                            </div>
                        );
                    }
                    if (key === 'COLOR') return null; // Don't display the color key itself

                    let displayValue = String(value);
                    if (key === 'STATUS') {
                        const statusColor = value === 'Success' ? 'text-green-700' : (value === 'Failure' ? 'text-red-700' : 'text-gray-700');
                        displayValue = <span className={`font-bold ${statusColor}`}>{value}</span>;
                    }

                    return (
                        <div key={key}>
                            <strong className="font-medium text-gray-500 w-32 inline-block">{key}:</strong>
                            {displayValue}
                        </div>
                    );
                })}
            </div>
        </div>
    );
};


// --- Main App Component ---
export default function RuleEngine() {
    const [jsonInput, setJsonInput] = useState(JSON.stringify(initialJsonPayload, null, 2));
    const [results, setResults] = useState(null);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState(null);

    const handleAnalyse = async () => {
        setIsLoading(true);
        setResults(null);
        setError(null);

        let parsedInput;
        try {
            parsedInput = JSON.parse(jsonInput);
        } catch (err) {
            setError('Invalid JSON format in the request payload.');
            setIsLoading(false);
            return;
        }

        try {
            // This is the API call to your Spring Boot backend
            const response = await fetch('http://localhost:8080/cxp-backoffice-services/api/process', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(parsedInput),
            });

            if (!response.ok) {
                throw new Error(`API Error: ${response.status} ${response.statusText}`);
            }

            const data = await response.json();
            setResults(data);

        } catch (err) {
            setError(`Failed to connect to the rule engine API. Make sure your Java backend is running. Details: ${err.message}`);
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="p-4 sm:p-6 lg:p-8 font-sans bg-gray-50 min-h-screen">
            <div className="max-w-7xl mx-auto">
                <header className="mb-8">
                    <h1 className="text-3xl font-bold text-gray-800">CTC Analysis Rule Engine</h1>
                    <p className="text-gray-600 mt-1">Paste your signal data, run the analysis, and view the processed results from the live backend.</p>
                </header>

                <main className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                    <div className="bg-white p-6 rounded-lg shadow-md">
                        <h2 className="text-xl font-semibold text-gray-700 mb-4">Request Payload</h2>
                        <textarea
                            id="json-input"
                            className="w-full h-96 p-4 border border-gray-300 rounded-md font-mono text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition"
                            value={jsonInput}
                            onChange={(e) => setJsonInput(e.target.value)}
                        />
                        <div className="mt-4 flex justify-end">
                            <button
                                id="analyse-button"
                                className="px-6 py-2 bg-blue-600 text-white font-semibold rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition duration-150 ease-in-out flex items-center disabled:bg-blue-400 disabled:cursor-not-allowed"
                                onClick={handleAnalyse}
                                disabled={isLoading}
                            >
                                {isLoading ? (
                                    <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                                    </svg>
                                ) : (
                                    <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01"></path></svg>
                                )}
                                {isLoading ? 'Analysing...' : 'Analyse Data'}
                            </button>
                        </div>
                    </div>

                    <div className="bg-white p-6 rounded-lg shadow-md">
                        <h2 className="text-xl font-semibold text-gray-700 mb-4">Analysis Results</h2>
                        <div id="results-container" className="space-y-4">
                            {isLoading && (
                                <div className="text-center text-gray-500 py-16">
                                    <p>Contacting API and processing rules...</p>
                                </div>
                            )}
                            {error && (
                                <div className="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 rounded-md" role="alert">
                                    <p className="font-bold">Error</p>
                                    <p>{error}</p>
                                </div>
                            )}
                            {results && !isLoading && !error && (
                                Object.entries(results).map(([key, value]) => (
                                    <ResultCard key={key} title={key} data={value} />
                                ))
                            )}
                            {!results && !isLoading && !error && (
                                <div className="text-center text-gray-500 py-16">
                                    <p>Click "Analyse Data" to see the results from your backend.</p>
                                </div>
                            )}
                        </div>
                    </div>
                </main>
            </div>
        </div>
    );
}
