import React, { useState, useEffect, useMemo, Suspense } from 'react';
import Grid from '@mui/material/Grid';
import Paper from '@mui/material/Paper';
import { Avatar, Button, Link, TextField, Typography } from '@mui/material';
import LockOutlinedIcon from '@mui/icons-material/LockOutlined';
import FormControlLabel from '@mui/material/FormControlLabel';
import Checkbox from '@mui/material/Checkbox';
import LocationCityIcon from '@mui/icons-material/LocationCity';


const Home=()=>{
   
    const [username, setuserName] = useState('')
    const [pass, setPass] = useState('')
    const paperStyle={padding :20,height:'70vh',width:280,margin:"19px auto" ,backgroundColor:'#E6F4F1', borderRadius: '12px', boxShadow: '0px 0px 8px rgba(0, 0, 0, 25)'}
    const avatarStyle={backgroundColor:'#D9D9D9'}
    const btnstyle={backgroundColor:'#1B6DA1',margin:'12px 0'}
    const logoStyle={backgroundColor:'#D9D9D9', margin:'10px 0', width: 70, height: 70}
      
    const authUser = () => {
       if(username == 'CXP_MONITORING' && pass == 'm@_CXP##@495') {
            sessionStorage.setItem('auth', 'true')
            document.location.href = '/esim'
            
       } else {
        sessionStorage.setItem('auth', 'false')
       }
    }
    return(
        
        <Grid>
                <Grid align='center'>
                    
                    <h2>CXP-Stability</h2>
                </Grid>  
             
            
            <Paper elavation={12} style={paperStyle}>
                <Grid align='center'>
                    <Avatar style={avatarStyle}><LockOutlinedIcon style={{ color: '#002A57' }}/></Avatar>
                    <h2>Login</h2>
                </Grid>
                <TextField id="standard-basic" label="Username" variant="standard" placeholder='Enter Your Username' fullWidth required onChange={(evt) => setuserName(evt.target.value)}/>
                <TextField id="standard-basic" label="Password" variant="standard" placeholder='Enter Your Password' type='password' fullWidth required onChange={(evt) => setPass(evt.target.value)}/>
                <FormControlLabel control={<Checkbox defaultChecked />} label="Remember Me" />

                <Button style={btnstyle} type='submit' color='primary' variant="contained" fullWidth onClick={(evt) => authUser()}>Login</Button>
                
            </Paper>
        </Grid>
        
    )
}

export default Home