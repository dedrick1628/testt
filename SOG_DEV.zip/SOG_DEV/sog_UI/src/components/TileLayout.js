import React, {useState} from "react";
import "./TileLayout.css"

const TileLayout = (props) => {
    const [selectedTile, setSelectedTile] = useState(0)
    const [isModalOpen, setIsModalOpen] = useState(false)
    const [modalContent, setModalContent] = useState("")
    
    const openModal =() => {
        setModalContent("test");
        setIsModalOpen(true);
    }
    const closeModal = () => {
        setIsModalOpen(false);
        setModalContent("")
    }
    
    return(
        <div className="tile-container-wrapper">
        <div className="tile-container" >
            {(props?.transactionData?.map((tile, index) => (
                <div className={`tile ${selectedTile === index ? "selected": ""}`} key={tile.TRANSACTION_ID}
                style={{"backgroundColor" : tile['TRANSACTION_BGCOLOR'], "color": tile['TRANSACTION_TEXTCOLOR']}}>
                    <div className="tile-content">
                        {tile.TRANSACTION_NAME}
                    </div>

                </div>
            )))}
        </div>
        {isModalOpen && (
            <div className="modal">
                <div className="modal-content">
                    <span className="close-btn" onClick={closeModal}>
                        &times;
                    </span>
                    <div className="modal-body">
                        <div>
                            {modalContent}
                        </div>
                    </div>
                </div>
            </div>
        )}
        </div>
        
    )
}
export default TileLayout;