import React, { useState, useRef, useEffect, useCallback, useMemo } from "react";
import { 
    Box, 
    TextField, 
    Typography, 
    Paper, 
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    CircularProgress,
    IconButton,
    Tooltip,
    Modal,
    Fade,
    Snackbar,
    TablePagination,
    Link,
    Alert as MuiAlert
} from "@mui/material";
import RefreshIcon from '@mui/icons-material/Refresh';
import CloseIcon from '@mui/icons-material/Close';
import Button  from "react-bootstrap/Button";
import { Navbar, Container } from 'react-bootstrap';
import Logo from "../assets/images/vz.png";
import { Image } from "react-bootstrap";
import 'bootstrap/dist/css/bootstrap.min.css';


const API_ENDPOINTS = {
    searchAll: `http://cxpops.verizon.com:8080/cxp-backoffice-services/clicktocall/search`,
    // searchById is no longer needed for the UI, filtering is done client-side.
    submitMtns: `http://cxpops.verizon.com:8080/cxp-backoffice-services/clicktocall/submit-mtns`,
    upload: `http://cxpops.verizon.com:8080/cxp-backoffice-services/clicktocall/upload`,
    summary: (reqId) => `http://cxpops.verizon.com:8080/cxp-backoffice-services/clicktocall/summary/${reqId}`,
    viewDetails: (reqId) => `http://cxpops.verizon.com:8080/cxp-backoffice-services/clicktocall/viewdetails/${reqId}`,
    rerun: (reqId) => `http://cxpops.verizon.com:8080/cxp-backoffice-services/clicktocall/rerun/${reqId}`,
    runRules: (reqId) => `http://cxpops.verizon.com:8080/cxp-backoffice-services/clicktocall/runRules/${reqId}`,
    rerunRules: (reqId) => `http://cxpops.verizon.com:8080/cxp-backoffice-services/clicktocall/rerunRules/${reqId}`,
};

const Alert = React.forwardRef(function Alert(props, ref) {
    return <MuiAlert elevation={6} ref={ref} variant="filled" {...props} />;
});

const formatDateForApi = (dateString) => {
    if (!dateString) return '';
    const date = new Date(dateString + 'T00:00:00');
    const day = String(date.getDate()).padStart(2, '0');
    const month = date.toLocaleString('en-US', { month: 'short' });
    const year = date.getFullYear();
    const capitalizedMonth = month.charAt(0).toUpperCase() + month.slice(1);
    return `${day}-${capitalizedMonth}-${year}`;
};

const formatTimestamp = (timestamp) => {
    if (!timestamp) return 'N/A';
    try {
        if (typeof timestamp === 'string' && timestamp.match(/^\d{4}-\d{2}-\d{2}$/)) {
             return new Date(timestamp + 'T00:00:00').toLocaleDateString();
        }
        return new Date(timestamp).toLocaleString();
    } catch (e) {
        return 'Invalid Date';
    }
};

const formatSummaryKey = (key) => {
    if (!key) return '';
    return key
        .split('_')
        .map(word => word.charAt(0).toUpperCase() + word.slice(1))
        .join(' ');
};

const modalStyle = {
    position: 'absolute',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    width: '80%',
    maxWidth: 900, 
    bgcolor: 'background.paper',
    border: '2px solid #000',
    boxShadow: 24,
    p: 4,
};

const htmlModalStyle = {
    position: 'absolute',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    width: '90%',
    maxWidth: 1200,
    bgcolor: 'background.paper',
    border: '2px solid #000',
    boxShadow: 24,
    p: 4,
};


const ClickToCallContainer = () => {

     // NEW: Helper to format dates for the input fields
     const formatDateForInput = (date) => {
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');
        return `${year}-${month}-${day}`;
    };

    // NEW: Calculate default dates
    const getInitialDates = () => {
        const today = new Date();
        const sevenDaysAgo = new Date();
        sevenDaysAgo.setDate(today.getDate() - 7);
        return {
            start: formatDateForInput(sevenDaysAgo),
            end: formatDateForInput(today)
        };
    };

    const initialDates = getInitialDates();

    // --- State for File Upload section ---
    const [selectedFile, setSelectedFile] = useState(null);
    const [uploadStatus, setUploadStatus] = useState("");
    const [uploadLoading, setUploadLoading] = useState(false);
    const [uploadStartDate, setUploadStartDate] = useState(initialDates.start);
    const [uploadEndDate, setUploadEndDate] = useState(initialDates.end);
    
    // --- State for MTN Submission section ---
    const [mtnInput, setMtnInput] = useState('');
    const [mtnStatus, setMtnStatus] = useState("");
    const [mtnLoading, setMtnLoading] = useState(false);
    const [mtnStartDate, setMtnStartDate] = useState(initialDates.start);
    const [mtnEndDate, setMtnEndDate] = useState(initialDates.end);

    // --- State for History Table ---
    const [originalRequestHistory, setOriginalRequestHistory] = useState([]);
    const [requestHistory, setRequestHistory] = useState([]);
    const [historyLoading, setHistoryLoading] = useState(true);
    const [historyError, setHistoryError] = useState('');
    const [historyPage, setHistoryPage] = useState(0);
    const [historyFilters, setHistoryFilters] = useState({ UPLOAD_REQ_ID: '' });

    // --- State for Modals and Details ---
    const [isSummaryModalOpen, setIsSummaryModalOpen] = useState(false);
    const [summaryData, setSummaryData] = useState(null);
    const [summaryLoading, setSummaryLoading] = useState(false);
    const [summaryError, setSummaryError] = useState('');
    
    const [detailsData, setDetailsData] = useState([]);
    const [detailsLoading, setDetailsLoading] = useState(false);
    const [detailsError, setDetailsError] = useState('');
    const [detailsPage, setDetailsPage] = useState(0);
    const [selectedDetailsRequestId, setSelectedDetailsRequestId] = useState(null);
    const [detailsFilters, setDetailsFilters] = useState({
        CARTID: '', ORDERNUMBER: '', LOCATIONCODE: '', MTN: '',
    });

    const [isJsonModalOpen, setIsJsonModalOpen] = useState(false);
    const [jsonContent, setJsonContent] = useState('');
    const [isHtmlModalOpen, setIsHtmlModalOpen] = useState(false);
    const [htmlContent, setHtmlContent] = useState('');

    const [snackbar, setSnackbar] = useState({ open: false, message: '', severity: 'info' });
    const fileInputRef = useRef(null);

    // UPDATED: fetchHistory now uses { cache: 'no-cache' } to prevent 304 errors
    const fetchHistory = useCallback(async () => {
        setHistoryLoading(true);
        setHistoryError('');
        setHistoryFilters({ UPLOAD_REQ_ID: '' });
        try {
            const response = await fetch(API_ENDPOINTS.searchAll, { cache: 'no-cache' });
            if (!response.ok) {
                const errorText = await response.text();
                throw new Error(`HTTP error ${response.status}: ${errorText}`);
            }
            const data = await response.json();
            setOriginalRequestHistory(data);
            setRequestHistory(data);
        } catch (error) {
            console.error("Failed to fetch request history:", error);
            setHistoryError(`Failed to fetch request history: ${error.message}`);
        } finally {
            setHistoryLoading(false);
        }
    }, []);

    useEffect(() => {
        fetchHistory();
    }, [fetchHistory]);

    useEffect(() => {
        const lowercasedFilter = historyFilters.UPLOAD_REQ_ID.toLowerCase();
        const filteredData = originalRequestHistory.filter(item =>
            String(item.UPLOAD_REQ_ID || '').toLowerCase().includes(lowercasedFilter)
        );
        setRequestHistory(filteredData);
        setHistoryPage(0);
    }, [historyFilters, originalRequestHistory]);

    const handleFileChange = (event) => {
        setUploadStatus("");
        setSelectedFile(event.target.files[0]);
    };

    const handleChooseFileClick = () => {
        fileInputRef.current.click();
    };

    const handleUpload = async () => {
        if (!selectedFile || !uploadStartDate || !uploadEndDate) {
            setUploadStatus("Error: Please select a file and both start and end dates.");
            return;
        }
        const formData = new FormData();
        formData.append("file", selectedFile);
        const dateFilter = {
            startDate: formatDateForApi(uploadStartDate) + " 00:00:01",
            endDate: formatDateForApi(uploadEndDate) + " 23:59:59"
        };
        formData.append("dateFilter", JSON.stringify(dateFilter));
        setUploadStatus("Uploading...");
        setUploadLoading(true);
        try {
            const response = await fetch(API_ENDPOINTS.upload, { method: "POST", body: formData });
            const responseText = await response.text();
            if (response.ok) {
                try {
                    const result = JSON.parse(responseText);
                    setUploadStatus(`Upload successful! Request ID: ${result.UploadRequestId || 'N/A'}`);
                    setSelectedFile(null);
                    setUploadStartDate(initialDates.start);
                    setUploadEndDate(initialDates.end);
                    if (fileInputRef.current) fileInputRef.current.value = null;
                    fetchHistory(); 
                } catch (e) {
                    setUploadStatus(`Upload error: Invalid response from server. Received: ${responseText}`);
                }
            } else {
                setUploadStatus(`Upload failed: ${response.status} - ${responseText}`);
            }
        } catch (error) {
            setUploadStatus(`Upload error: ${error.message}`);
        } finally {
            setUploadLoading(false);
        }
    };

    const handleMtnSubmit = async () => {
        const mtns = mtnInput.split(/[\n,]/).map(m => m.trim()).filter(m => m);
        if (mtns.length === 0 || !mtnStartDate || !mtnEndDate) {
            setMtnStatus("Error: Please enter at least one MTN and select both start and end dates.");
            return;
        }
        setMtnStatus("Submitting...");
        setMtnLoading(true);
        const payload = {
            mtns: mtns,
            dateFilter: {
                startDate: formatDateForApi(mtnStartDate) + " 00:00:01",
                endDate: formatDateForApi(mtnEndDate) + " 23:59:59"
            }
        };
        try {
            const response = await fetch(API_ENDPOINTS.submitMtns, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });
            const responseText = await response.text();
            if (response.ok) {
                // FIX: The backend returns a plain text string (the ID), not JSON.
                // We use the response text directly instead of trying to parse it.
                setMtnStatus(`Submission successful! Request ID: ${responseText}`);
                setMtnInput('');
                setMtnStartDate(initialDates.start);
                setMtnEndDate(initialDates.end);
                fetchHistory();
            } else {
                setMtnStatus(`Submission failed: ${response.status} - ${responseText}`);
            }
        } catch (error) {
            setMtnStatus(`Submit error: ${error.message}`);
        } finally {
            setMtnLoading(false);
        }
    };

    const handleHistoryFilterChange = (e) => {
        const { name, value } = e.target;
        setHistoryFilters(prev => ({ ...prev, [name]: value }));
    };

    const handleViewSummary = async (reqId) => {
        setIsSummaryModalOpen(true);
        setSummaryLoading(true);
        setSummaryError('');
        setSummaryData(null);
        try {
            const response = await fetch(API_ENDPOINTS.summary(reqId));
            if (!response.ok) throw new Error(`HTTP error ${response.status}: ${await response.text()}`);
            setSummaryData(await response.json());
        } catch (error) {
            setSummaryError(`Failed to fetch summary: ${error.message}`);
        } finally {
            setSummaryLoading(false);
        }
    };

    const handleViewDetails = async (reqId) => {
        if (selectedDetailsRequestId === reqId) {
            setSelectedDetailsRequestId(null);
            setDetailsData([]);
            return;
        }
        setSelectedDetailsRequestId(reqId);
        setDetailsLoading(true);
        setDetailsError('');
        setDetailsData([]);
        setDetailsPage(0);
        try {
            const response = await fetch(API_ENDPOINTS.viewDetails(reqId), { method: 'POST' });
            if (!response.ok) throw new Error(`HTTP error ${response.status}: ${await response.text()}`);
            setDetailsData(await response.json());
        } catch (error) {
            console.error("Failed to fetch details:", error);
            setDetailsError(`Failed to fetch details: ${error.message}`);
            setSelectedDetailsRequestId(null);
        } finally {
            setDetailsLoading(false);
        }
    };
    
    const handlePostAction = async (reqId, endpoint, actionName) => {
        setSnackbar({ open: true, message: `Triggering ${actionName} for ${reqId}...`, severity: 'info' });
        try {
            const response = await fetch(endpoint(reqId), { method: 'POST' });
            const responseText = await response.text();

            if (!response.ok) {
                let errorMessage = responseText;
                try {
                    const errorJson = JSON.parse(responseText);
                    errorMessage = errorJson.error || errorMessage;
                } catch (e) {
                    // Not a JSON error body, use the raw text
                }
                throw new Error(errorMessage);
            }
            
            setSnackbar({ open: true, message: `${actionName} successful for ${reqId}`, severity: 'success' });
            setTimeout(fetchHistory, 1000); 
        } catch (error) {
            setSnackbar({ open: true, message: `${actionName} failed: ${error.message}`, severity: 'error' });
            console.error(`Failed to ${actionName} request:`, error);
        }
    };

    const handleRerun = (reqId) => {
        setSelectedDetailsRequestId(null);
        handlePostAction(reqId, API_ENDPOINTS.rerun, 'rerun');
    };
    const handleRunRules = (reqId) => handlePostAction(reqId, API_ENDPOINTS.runRules, 'run rules');
    const handleRerunRules = (reqId) => {
        setSelectedDetailsRequestId(null);
        handlePostAction(reqId, API_ENDPOINTS.rerunRules, 'rerun rules');
    };
    const handleSyncAceStatus = (reqId) => {
        setSelectedDetailsRequestId(null);
        handlePostAction(reqId, API_ENDPOINTS.syncAceStatus, 'ACE status sync')
    };


    const handleCloseSnackbar = (event, reason) => {
        if (reason === 'clickaway') return;
        setSnackbar({ ...snackbar, open: false });
    };
    
    const showJson = (jsonString) => {
        try {
            setJsonContent(JSON.stringify(JSON.parse(jsonString), null, 2));
        } catch (e) {
            setJsonContent("Invalid JSON content");
        }
        setIsJsonModalOpen(true);
    };

    const showHtml = (htmlString) => {
        setHtmlContent(htmlString);
        setIsHtmlModalOpen(true);
    };

    const handleDetailsFilterChange = (e) => {
        const { name, value } = e.target;
        setDetailsFilters(prev => ({ ...prev, [name]: value }));
    };

    const filteredDetailsData = useMemo(() => {
        return detailsData.filter(row => 
            Object.keys(detailsFilters).every(key => 
                String(row[key] || '').toLowerCase().includes(detailsFilters[key].toLowerCase())
            )
        );
    }, [detailsData, detailsFilters]);

    useEffect(() => {
        setDetailsPage(0);
    }, [filteredDetailsData]);

    const paperStyles = { p: 4, borderRadius: 2, flex: 1, minWidth: 0, display: 'flex', flexDirection: 'column', height: '100%' };
    
    const historyRowsPerPage = 5;
    const historyPageData = requestHistory.slice(historyPage * historyRowsPerPage, historyPage * historyRowsPerPage + historyRowsPerPage);

    const detailsRowsPerPage = 10;
    const detailsPageData = filteredDetailsData.slice(detailsPage * detailsRowsPerPage, detailsPage * detailsRowsPerPage + detailsRowsPerPage);

    return (
        <div>
        <Navbar sticky="top" bg="black" data-bs-theme="dark">
            <Container fluid className="mx-2">
              <Navbar.Brand href="/cxp-backoffice-ui/clicktocall" className="d-flex align-items-center">
                <Image src={Logo} alt="Logo" width={35} />
                <h5 className="mx-2 fw-bold my-0">CXP OPS Buddy</h5>
              </Navbar.Brand>
            </Container>
          </Navbar>
        <Box sx={{ p: 2 }}>
            <Snackbar open={snackbar.open} autoHideDuration={6000} onClose={handleCloseSnackbar}>
                <Alert onClose={handleCloseSnackbar} severity={snackbar.severity} sx={{ width: '100%' }}>
                    {snackbar.message}
                </Alert>
            </Snackbar>

            <Box sx={{ display: 'flex', flexDirection: { xs: 'column', md: 'row' }, gap: 3, alignItems: 'stretch' }}>
                {/* --- MTN Submission Panel (Now First) --- */}
                <Paper elevation={3} sx={paperStyles}>
                    <Typography variant="h5" gutterBottom sx={{ fontWeight: 'bold', color: 'black' }}>Click to Call - MTN</Typography>
                    <TextField
                        label="Enter MTNs (one per line or comma-separated)"
                        multiline
                        rows={2}
                        value={mtnInput}
                        onChange={(e) => setMtnInput(e.target.value)}
                        variant="outlined"
                        fullWidth
                        sx={{ mt: 2 }}
                    />
                    <Box sx={{ display: "flex", flexWrap: 'wrap', alignItems: "center", gap: 2, mt: 2 }}>
                        <TextField label="Start Date" type="date" size="small" value={mtnStartDate} onChange={(e) => setMtnStartDate(e.target.value)} InputLabelProps={{ shrink: true }} sx={{ minWidth: 150, flexGrow: 1 }}/>
                        <TextField label="End Date" type="date" size="small" value={mtnEndDate} onChange={(e) => setMtnEndDate(e.target.value)} InputLabelProps={{ shrink: true }} sx={{ minWidth: 150, flexGrow: 1 }}/>
                        <Button className="bg bg-dark" onClick={handleMtnSubmit} disabled={mtnLoading}>
                            {mtnLoading ? "Submitting..." : "Submit"}
                        </Button>
                    </Box>
                    {mtnStatus && (
                        <Typography variant="body2" sx={{ mt: 2, fontWeight: 500, color: mtnStatus.includes("successful") ? "green" : (mtnStatus.includes("Error") || mtnStatus.includes("failed")) ? "red" : "text.secondary" }}>
                            {mtnStatus}
                        </Typography>
                    )}
                </Paper>

                {/* --- File Upload Panel (Now Second) --- */}
                <Paper elevation={3} sx={paperStyles}>
                    <Typography variant="h5" gutterBottom sx={{ fontWeight: 'bold', color: 'black' }}>Click to Call - Upload</Typography>
                    <Box sx={{ display: "flex", flexWrap: 'wrap', alignItems: "center", gap: 2, mt: 3 }}>
                        <Box sx={{ display: 'flex', flexGrow: 1, minWidth: '250px' }}>
                            <TextField size="small" variant="outlined" fullWidth label="No file selected" value={selectedFile ? selectedFile.name : ""} InputProps={{ readOnly: true }}/>
                            <Button variant="outline-secondary" onClick={handleChooseFileClick} style={{ whiteSpace: 'nowrap' }}>Choose File</Button>
                        </Box>
                        <input type="file" ref={fileInputRef} hidden onChange={handleFileChange}/>
                        <TextField label="Start Date" type="date" size="small" value={uploadStartDate} onChange={(e) => setUploadStartDate(e.target.value)} InputLabelProps={{ shrink: true }} sx={{ minWidth: 150 }}/>
                        <TextField label="End Date" type="date" size="small" value={uploadEndDate} onChange={(e) => setUploadEndDate(e.target.value)} InputLabelProps={{ shrink: true }} sx={{ minWidth: 150 }}/>
                        <Button className="bg bg-dark" onClick={handleUpload} disabled={!selectedFile || !uploadStartDate || !uploadEndDate || uploadLoading}>
                            {uploadLoading ? "Uploading..." : "Upload"}
                        </Button>
                    </Box>
                    {uploadStatus && (
                        <Typography variant="body2" sx={{ mt: 2, fontWeight: 500, color: uploadStatus.includes("successful") ? "green" : (uploadStatus.includes("Error") || uploadStatus.includes("failed")) ? "red" : "text.secondary" }}>
                            {uploadStatus}
                        </Typography>
                    )}
                </Paper>
            </Box>

            {/* --- History Table --- */}
            <Paper elevation={3} sx={{ p: 4, borderRadius: 2, mt: 3 }}>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
                    <Typography variant="h5" gutterBottom sx={{ fontWeight: 'bold', color: 'black' }}>Recent Upload Requests</Typography>
                    <Tooltip title="Refresh History">
                        <IconButton onClick={fetchHistory} disabled={historyLoading}>
                            <RefreshIcon />
                        </IconButton>
                    </Tooltip>
                </Box>
                <TableContainer component={Paper}>
                    <Table stickyHeader size="small" aria-label="request history table">
                        <TableHead>
                            <TableRow>
                                <TableCell sx={{ fontWeight: 'bold' }}>Upload Request ID</TableCell>
                                <TableCell sx={{ fontWeight: 'bold' }}>Upload Request Date</TableCell>
                                <TableCell sx={{ fontWeight: 'bold' }}>Upload Status</TableCell>
                                <TableCell sx={{ fontWeight: 'bold' }}>Start Time</TableCell>
                                <TableCell sx={{ fontWeight: 'bold' }}>End Time</TableCell>
                                <TableCell sx={{ fontWeight: 'bold' }}>Req Start Date</TableCell>
                                <TableCell sx={{ fontWeight: 'bold' }}>Req End Date</TableCell>
                                <TableCell sx={{ fontWeight: 'bold' }}>Req MTNs</TableCell>
                                <TableCell sx={{ fontWeight: 'bold' }}>Error Source</TableCell>
                                <TableCell sx={{ fontWeight: 'bold' }}>Error Message</TableCell>
                                <TableCell sx={{ fontWeight: 'bold' }}>Actions</TableCell> 
                            </TableRow>
                            <TableRow>
                                <TableCell>
                                    <TextField 
                                        name="UPLOAD_REQ_ID" 
                                        value={historyFilters.UPLOAD_REQ_ID} 
                                        onChange={handleHistoryFilterChange} 
                                        variant="standard" 
                                        placeholder="Filter by ID..." 
                                        fullWidth
                                    />
                                </TableCell>
                                <TableCell colSpan={10}/>
                            </TableRow>
                        </TableHead>
                        <TableBody>
                            {historyLoading ? (
                                <TableRow><TableCell colSpan={11} align="center"><CircularProgress /></TableCell></TableRow>
                            ) : historyError ? (
                                <TableRow><TableCell colSpan={11} align="center" sx={{ color: 'red' }}>{historyError}</TableCell></TableRow>
                            ) : historyPageData.length === 0 ? (
                                <TableRow><TableCell colSpan={11} align="center">No recent requests found.</TableCell></TableRow>
                            ) : (
                                historyPageData.map((row) => (
                                    <TableRow key={row.UPLOAD_REQ_ID} hover>
                                        <TableCell><Tooltip title={row.UPLOAD_REQ_ID}><Typography variant="body2">{row.UPLOAD_REQ_ID}</Typography></Tooltip></TableCell>
                                        <TableCell>{formatTimestamp(row.REQ_DATE)}</TableCell>
                                        <TableCell>{row.REQ_STATUS}</TableCell>
                                        <TableCell>{formatTimestamp(row.EXECUTION_START_TIME)}</TableCell>
                                        <TableCell>{formatTimestamp(row.EXECUTION_END_TIME)}</TableCell>
                                        <TableCell>{formatTimestamp(row.REQ_START_TIMESTAMP)}</TableCell>
                                        <TableCell>{formatTimestamp(row.REQ_END_TIMESTAMP)}</TableCell>
                                        <TableCell sx={{ maxWidth: 150, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }} title={row.REQ_MTNS}>
                                            {row.REQ_MTNS || 'N/A'}
                                        </TableCell>
                                        <TableCell>{row.ERROR_SOURCE_ID || 'N/A'}</TableCell>
                                        <TableCell sx={{ maxWidth: 150, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }} title={row.ERROR_MESSG}>
                                            {row.ERROR_MESSG || 'N/A'}
                                        </TableCell>
                                        <TableCell>
                                            <Box sx={{ display: 'flex', flexDirection: 'row', gap: 1, alignItems: 'center' }}>
                                                <Box sx={{ width: '110px' }}>
                                                    {(row.REQ_STATUS === 'ERROR' || row.REQ_STATUS === 'RULES_COMPLETED') && ( <Button variant="outline-danger" size="sm" onClick={() => handleRerun(row.UPLOAD_REQ_ID)}>RerunUpload</Button> )}
                                                </Box>
                                                <Box sx={{ width: '120px' }}>
                                                    {['ERROR', 'COMPLETED', 'RULES_ERROR', 'RULES_INPROGRESS', 'RULES_COMPLETED'].includes(row.REQ_STATUS) ? (
                                                        <Button variant="outline-success" size="sm" onClick={() => handleViewSummary(row.UPLOAD_REQ_ID)}>View Summary</Button>
                                                    ) : ( <Button variant="outline-secondary" size="sm" disabled>View Summary</Button> )}
                                                </Box>
                                                <Box sx={{ width: '110px' }}>
                                                    {row.REQ_STATUS === 'COMPLETED' && ( <Button variant="outline-primary" size="sm" onClick={() => handleRunRules(row.UPLOAD_REQ_ID)}>Run Rules</Button> )}
                                                    {row.REQ_STATUS === 'RULES_ERROR' && ( <Button variant="outline-danger" size="sm" onClick={() => handleRerunRules(row.UPLOAD_REQ_ID)}>Rerun Rules</Button> )}
                                                    {row.REQ_STATUS === 'RULES_COMPLETED' && ( <Button variant="outline-warning" size="sm" onClick={() => handleRerunRules(row.UPLOAD_REQ_ID)}>Rerun Rules</Button> )}
                                                </Box>
                                                <Box sx={{ width: '110px' }}>
                                                    {row.REQ_STATUS === 'RULES_COMPLETED' && ( <Button variant="outline-dark" size="sm" onClick={() => handleViewDetails(row.UPLOAD_REQ_ID)}>View Details</Button> )}
                                                </Box>
                                            </Box>
                                        </TableCell>
                                    </TableRow>
                                ))
                            )}
                        </TableBody>
                    </Table>
                </TableContainer>
                <TablePagination
                    rowsPerPageOptions={[5]}
                    component="div"
                    count={requestHistory.length}
                    rowsPerPage={historyRowsPerPage}
                    page={historyPage}
                    onPageChange={(e, newPage) => setHistoryPage(newPage)}
                />
            </Paper>

            {/* --- Details Panel --- */}
            {selectedDetailsRequestId && (
                <Paper elevation={3} sx={{ p: 4, borderRadius: 2, mt: 3 }}>
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
                        <Typography variant="h5" gutterBottom sx={{ fontWeight: 'bold', color: 'black' }}>
                            Details for Request ID: {selectedDetailsRequestId}
                        </Typography>
                        <IconButton onClick={() => setSelectedDetailsRequestId(null)}>
                            <CloseIcon />
                        </IconButton>
                    </Box>
                    {detailsLoading ? <Box sx={{display: 'flex', justifyContent: 'center', my: 3}}><CircularProgress /></Box>
                    : detailsError ? <Typography color="error" sx={{mt: 2}}>{detailsError}</Typography>
                    : detailsData.length > 0 ? (
                        <>
                            <TableContainer component={Paper}>
                                <Table size="small">
                                    <TableHead>
                                        <TableRow>
                                            <TableCell>Cart ID</TableCell>
                                            <TableCell>Order Number</TableCell>
                                            <TableCell>Location Code</TableCell>
                                            <TableCell>MTN</TableCell>
                                            <TableCell>CREATED_DATE(PST)</TableCell>
                                            <TableCell>Request</TableCell>
                                            <TableCell>Summary</TableCell>
                                        </TableRow>
                                        <TableRow>
                                            <TableCell><TextField name="CARTID" value={detailsFilters.CARTID} onChange={handleDetailsFilterChange} variant="standard" placeholder="Search..." fullWidth/></TableCell>
                                            <TableCell><TextField name="ORDERNUMBER" value={detailsFilters.ORDERNUMBER} onChange={handleDetailsFilterChange} variant="standard" placeholder="Search..." fullWidth/></TableCell>
                                            <TableCell><TextField name="LOCATIONCODE" value={detailsFilters.LOCATIONCODE} onChange={handleDetailsFilterChange} variant="standard" placeholder="Search..." fullWidth/></TableCell>
                                            <TableCell><TextField name="MTN" value={detailsFilters.MTN} onChange={handleDetailsFilterChange} variant="standard" placeholder="Search..." fullWidth/></TableCell>
                                            <TableCell/>
                                            <TableCell/>
                                            <TableCell/>
                                        </TableRow>
                                    </TableHead>
                                    <TableBody>
                                        {detailsPageData.map((row, index) => (
                                            <TableRow key={index}>
                                                <TableCell>{row.CARTID}</TableCell>
                                                <TableCell>{row.ORDERNUMBER}</TableCell>
                                                <TableCell>{row.LOCATIONCODE}</TableCell>
                                                <TableCell>{row.MTN}</TableCell>
                                                <TableCell>{formatTimestamp(row.CREATED_DATE)}</TableCell>
                                                <TableCell>
                                                    {row.RULES_JSON_REQ ? (
                                                        <Link component="button" variant="body2" onClick={() => showJson(row.RULES_JSON_REQ)}>View Request</Link>
                                                    ) : 'N/A'}
                                                </TableCell>
                                                <TableCell>
                                                    {row.RULES_HTML_RESP ? (
                                                        <Link component="button" variant="body2" onClick={() => showHtml(row.RULES_HTML_RESP)}>View Summary</Link>
                                                    ) : 'N/A'}
                                                </TableCell>
                                            </TableRow>
                                        ))}
                                    </TableBody>
                                </Table>
                            </TableContainer>
                            <TablePagination
                                rowsPerPageOptions={[10]}
                                component="div"
                                count={filteredDetailsData.length}
                                rowsPerPage={detailsRowsPerPage}
                                page={detailsPage}
                                onPageChange={(e, newPage) => setDetailsPage(newPage)}
                            />
                        </>
                    ) : <Typography sx={{mt: 2}}>No details available for this request.</Typography>}
                </Paper>
            )}

            {/* --- Modals --- */}
            <Modal open={isSummaryModalOpen} onClose={() => setIsSummaryModalOpen(false)} closeAfterTransition>
                <Fade in={isSummaryModalOpen}>
                    <Box sx={modalStyle}>
                        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                            <Typography variant="h6" component="h2">Request Summary</Typography>
                            <IconButton onClick={() => setIsSummaryModalOpen(false)}><CloseIcon /></IconButton>
                        </Box>
                        <Box sx={{ mt: 2, maxHeight: '60vh', overflow: 'auto' }}>
                            {summaryLoading ? <CircularProgress /> 
                            : summaryError ? <Typography color="error">{summaryError}</Typography>
                            : summaryData && summaryData.length > 0 ? (
                                <TableContainer component={Paper}>
                                    <Table size="small">
                                        <TableBody>
                                            {Object.entries(summaryData[0]).map(([key, value]) => (
                                                <TableRow key={key}>
                                                    <TableCell component="th" scope="row" sx={{ fontWeight: 'bold' }}>{formatSummaryKey(key)}</TableCell>
                                                    <TableCell align="right">{String(value)}</TableCell>
                                                </TableRow>
                                            ))}
                                        </TableBody>
                                    </Table>
                                </TableContainer>
                            ) : <Typography>No summary data available.</Typography>}
                        </Box>
                    </Box>
                </Fade>
            </Modal>

            <Modal open={isJsonModalOpen} onClose={() => setIsJsonModalOpen(false)} closeAfterTransition>
                <Fade in={isJsonModalOpen}>
                    <Box sx={modalStyle}>
                        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                            <Typography variant="h6" component="h2">JSON Content</Typography>
                            <IconButton onClick={() => setIsJsonModalOpen(false)}><CloseIcon /></IconButton>
                        </Box>
                        <Box component="pre" sx={{ mt: 2, p: 2, backgroundColor: '#f5f5f5', borderRadius: 1, maxHeight: '60vh', overflow: 'auto' }}>
                            {jsonContent}
                        </Box>
                    </Box>
                </Fade>
            </Modal>

            <Modal open={isHtmlModalOpen} onClose={() => setIsHtmlModalOpen(false)} closeAfterTransition>
                <Fade in={isHtmlModalOpen}>
                    <Box sx={htmlModalStyle}>
                        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                            <Typography variant="h6" component="h2">View Summary</Typography>
                            <IconButton onClick={() => setIsHtmlModalOpen(false)}><CloseIcon /></IconButton>
                        </Box>
                        <Paper sx={{ mt: 2, p: 2, maxHeight: '80vh', overflow: 'auto' }} dangerouslySetInnerHTML={{ __html: htmlContent }} />
                    </Box>
                </Fade>
            </Modal>
        </Box>
        </div>
    );
};

export default ClickToCallContainer;