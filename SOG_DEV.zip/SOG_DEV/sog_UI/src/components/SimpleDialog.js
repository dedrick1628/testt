import React, { useState, useEffect, useMemo, Suspense } from 'react';
import PropTypes from 'prop-types';
import { makeStyles } from '@mui/styles';
import Button from '@mui/material/Button';
import Avatar from '@mui/material/Avatar';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemAvatar from '@mui/material/ListItemAvatar';
import ListItemText from '@mui/material/ListItemText';
import DialogTitle from '@mui/material/DialogTitle';
import Dialog from '@mui/material/Dialog';
import axios from 'axios';
import { Box } from '@mui/material';
import { TableHeader, Cell, Table, TableBody, TableRow, TableHead } from '@vds/tables';
import { saveAs} from 'file-saver'
import CircularProgress, {
    CircularProgressProps,
  } from '@mui/material/CircularProgress';
  
import Typography from '@mui/material/Typography';
import { blue } from '@mui/material/colors';


const useStyles = makeStyles({
   
      thead: {
        backgroundColor: '#4caf50',
      },
      Dialog: {
        width: '500px'
      },
      DialogTitle: {
         width: '500px'
      }
});

const SimpleDialog=(props) => {
  const classes = useStyles();
  const { onClose, selectedValue, open, data, processData } = props;
  const [progress, setProgress] = useState(0);
  const [showProgress, setshowProgress] = useState(false)
  console.log("processDataprocessData ==>",processData);
  const handleClose = () => {
    onClose(selectedValue);
  };


  const Continue = () => {
    setshowProgress(true)
    setProgress(0)
    let estimated_time = data[0];
    let [hours,minutes,seconds] = estimated_time.split(":").map(Number)
    let hours_seconds = hours * 60 * 60;
    let minutes_seconds = minutes * 60;
    let total_seconds = hours_seconds+minutes_seconds+seconds
    let progress_ms = 100 / total_seconds;
    
    const timer = setInterval(() => {
        setProgress((prevValue) => {
            if (prevValue >= 100)
            {
                clearInterval(timer);
            } else {
                prevValue = prevValue+progress_ms;
            }
            return prevValue;
        });
        
        //setProgress((prevProgress) => (prevProgress >= 100 ? 0 : prevProgress + progress_ms));
      }, 1000);
    
    let axiosConfig = {
        headers: {
            'Content-Type': 'application/json;charset=UTF-8',
            "Access-Control-Allow-Origin": "*",
        }
      };
      const payload = {
        "processData" : processData["processData"],
        "pageCount": data[1]
    };
    axios.post(`http://localhost:8000/fetchAYSIncident`, payload, axiosConfig, {responseType:'blob'})
    .then(res => {
        saveAs(new Blob([res.data]),'AYS_Inc_report.csv');
     let page_details=[];
     
    })
  }
 

  return (
    <Dialog onClose={handleClose}  open={open} >
      
        
            <Table
            striped={true}
            bottomLine='none'
            padding='compact'
            className={classes.Table}
        >
            <TableHead>
                   
                        <TableHeader>Estimated time : {data[0]}</TableHeader>
                        <TableHeader>Total pages : {data[1]}</TableHeader>
                        <TableHeader>Records per page : {data[2]}</TableHeader>
            </TableHead>
            <TableBody>
                                    <TableRow>
                                        <Cell >Do you like to continue ?</Cell>
                                        <Cell ><Button onClick={() => Continue()}>Yes</Button></Cell>
                                        <Cell ><Button>No</Button></Cell>
                                    </TableRow>
                        </TableBody>
            </Table>
       
     {showProgress ? <Box sx={{ position: 'relative', display: 'inline-flex' }}>
      <CircularProgress variant="determinate" />
      <Box
        sx={{
          top: 0,
          left: 0,
          bottom: 0,
          right: 0,
          position: 'absolute',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        <Typography
          variant="caption"
          component="div"
          sx={{ color: 'text.secondary' }}
        >{`${Math.round(progress)}%`}</Typography>
      </Box>
    </Box>
      :""}
    </Dialog>
  );
}

SimpleDialog.propTypes = {
  onClose: PropTypes.func.isRequired,
  open: PropTypes.bool.isRequired,
  selectedValue: PropTypes.string.isRequired,
};

export default SimpleDialog;