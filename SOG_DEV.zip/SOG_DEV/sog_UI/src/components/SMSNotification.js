import React, { useState} from 'react';
import { TileContainer} from '@vds/tiles';
import { Title } from '@vds/typography';
import { Input,TextArea } from '@vds/inputs';
import { Button } from '@vds/buttons';
import axios from 'axios';
import { Loader } from '@vds/loaders';
import Checkbox from '@mui/material/Checkbox';
import TextField from '@mui/material/TextField';
import Autocomplete from '@mui/material/Autocomplete';
import CheckBoxOutlineBlankIcon from '@mui/icons-material/CheckBoxOutlineBlank';
import WarningIcon from '@mui/icons-material/Warning';
import CheckBoxIcon from '@mui/icons-material/CheckBox';
const SMSNotification=()=>{
    const [phonenumbers, setPhonenumber] = useState()
    const [textsms, setTextsms] = useState()
    const [loader, setLoader] = useState(false)
    const [smsStatus, setSMSStatus] = useState('Send SMS')
    const [numberList, setNumberList]=useState([
        {
            "name": "Uma Raman", "number": "7322891974"
        },
        {
            "name": "Ramesh Ramakrishnan", "number": "9729988496"
        },
        {
            "name": "Ravi Kalavagunta", "number": "4697087284"
        },
        {
            "name": "Yoganand Thulasiraman", "number": "4694008397"
        },
        {
            "name": "Srithar Kaliappan", "number": "4694168665"
        },
        {
            "name": "Parthiban Rajendran", "number": "9724394250"
        },
        {
            "name": "Srinivas Chamarthi", "number": "7326984243"
        },
        {
            "name": "Shahnawaz", "number": "9453046347"
        },
        {
            "name": "Ashish Negi", "number": "4695251219"
        },
        {
            "name": "Thasan", "number": "4695655568"
        }
    ])
    numberList.sort((a, b) => (a.name > b.name) ? 1 : -1)
    const icon = <CheckBoxOutlineBlankIcon fontSize="small" />;
    const checkedIcon = <CheckBoxIcon fontSize="small" />;
    
    
    const numberChange = (event, tags) => {
        let numbers = []
        tags.map((contact) => {numbers.push(contact.number)})
        setPhonenumber(numbers)
    }
    
    const sendSMS = () => {
        console.log("phonenumbers ===>", phonenumbers)
        setLoader(true)
        let axiosConfig = {
            headers: {
                'Content-Type': 'application/json;charset=UTF-8',
                "Access-Control-Allow-Origin": "*",
            }
          };
        let payload = {
            "phone_numbers": phonenumbers,
            "sms_text": textsms
        }
           axios.post(`http://localhost:8000/sendsms`, payload, axiosConfig)
           .then(res => {
            setLoader(false)
            setSMSStatus(res.data)
           })
    }
    return(
        <div>
        {loader ? <Loader fullscreen={true} active={true} surface='dark' />: ""}
        <div style={{height: 'auto', width: '600px', borderRadius: '12px', borderColor: '#d3d3d3', borderStyle: 'solid', textAlign:'center',position: 'absolute', top: '100px', marginLeft: '100px'}}>
        
                <div style={{paddingLeft: '25px'}}>
                <Title color='black' size='TitleMedium'bold={true}> {smsStatus}</Title> <br/>
                
                <Autocomplete
                    multiple
                    id="checkboxes-tags-demo"
                    options={numberList}
                    disableCloseOnSelect
                    getOptionLabel={(option) => option.name}
                    onChange={numberChange}
                    renderOption={(props, option, { selected }) => {
                        const { key, ...optionProps } = props;
                        return (
                        <li key={key} {...optionProps}>
                            <Checkbox
                            icon={icon}
                            checkedIcon={checkedIcon}
                            style={{ marginRight: 8 }}
                            checked={selected}
                            />
                            {option.name}
                        </li>
                        );
                    }}
                    style={{ width: 550, height:'auto' }}
                    
                    renderInput={(params) => (
                        <TextField {...params} label="Number" placeholder="Number" />
                    )}
                    /> <br/>
                     <TextArea 
                    label="Text message"
                    surface="light"
                    width='550px'
                    value = {textsms}
                    required={true}
                    disabled={false}
                    error={false}
                    onChange={(evt) => setTextsms(evt.target.value)}
                    helperTextPlacement="bottom"
                    maxLength={1000} /> <br/>
                <Button 
                size="large"
                width='550px'
                disabled={false}
                onClick={(evt) => sendSMS()}
                use="primary"
                >
                Send
                </Button> <br/>
                
                </div>
            </div>
            <div style={{height: '100px', width: '600px', borderRadius: '12px', borderColor: '#d3d3d3', borderStyle: 'solid', textAlign:'center',position: 'absolute', top: '100px', marginLeft: '800px'}}>
            
            <div style={{height: '50px', backgroundColor:'red', textAlign: 'left', color:'white'}}><div style={{textAlign: 'center', paddingTop: '15px'}}><WarningIcon style={{height: '15px'}}></WarningIcon><span style={{fontWeight: 'bold'}}>Warnings !</span></div></div>
            <div style={{textAlign: 'left'}}><span>As per Verizon policy. Please do not share Confidential / Customer details over the text message</span></div>
            
             </div>
            </div>
            
        
    )
}

export default SMSNotification