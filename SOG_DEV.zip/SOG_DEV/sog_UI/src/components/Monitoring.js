import React, { useState, useEffect, useMemo, Suspense } from 'react';


import '../App.css';
import Box from '@mui/material/Box';
import Paper from '@mui/material/Paper';
import { experimentalStyled as styled } from '@mui/material/styles';
import Grid from '@mui/material/Grid';
import Table from '@mui/material/Table';
import { TableCell, TableHead, TableRow } from '@mui/material';
import { makeStyles } from '@mui/styles';
import axios from 'axios';

const userStyles = makeStyles({
  table: {
    backgroundColor: '#81c784',
  },
  thead: {
    backgroundColor: '#4caf50',
  }
});

const Monitoring = () => {
  const classes = userStyles();

  const [confData, setconfData] = useState({})
  const [isLoading, setisLoading] = useState(false)
  
  useEffect(() => {
    axios
      .get("http://localhost:8000/getConfDetails")
      .then((res) => {
        setconfData(res.data);
        setisLoading(true);
       console.log("resresresresres ===>", res)
      })
  },[])

  const displayReport = () => {
    
    return (
      <Box sx={{ flexGrow: 1 }} style={{"width": '100%'}}>
        <Table aria-label="sticky table" className={classes.table}>
        <TableHead className={classes.thead}>
          <TableRow>
            {
              Object.keys(confData?.category).map((cat,i) => {
                return (
                    <>
                    <TableCell align='left'>{cat}</TableCell>
                    </>
                )
              })
            }
          </TableRow>
          </TableHead>
          <TableRow>
            {
              Object.keys(confData?.category)?.map((cat,i) => {
                return (
                    <>
                    <TableCell style={{ verticalAlign: "top"}}>
                      {
                        confData?.category[cat]?.map((subCat,i) => {
                          if (Number(subCat['measured-value']) != 0) {
                            return (
                              <TableRow>
                                <TableCell style={{"backgroundColor": subCat['bg-color'], "color": subCat['txt-color']}}><bold>{subCat.text}</bold> : <bold>{subCat['measured-value']}</bold></TableCell>
                              </TableRow>
                            )
                          }
                        })
                      }
                    </TableCell>
                    
                    </>
                )
              })
            }
          </TableRow>
        
        </Table>
      </Box>
    )
  }
  const Item = styled(Paper)(({ theme }) => ({
    backgroundColor: '#fff',
    ...theme.typography.body2,
    padding: theme.spacing(2),
    textAlign: 'center',
    color: theme.palette.text.secondary,
    ...theme.applyStyles('dark', {
      backgroundColor: '#FFF',
    }),
  }));
  return(
    <div className="app">
      <header className="header">

      </header>
      <main className="main">
      <div>
      <div className="indicator_box box_green">
       </div>
          Below Threshold 
      </div>
      <div>
      <div className="indicator_box box_yellow">
       </div>
          Less than Threshold 
      </div>
      <div>
      <div className="indicator_box box_orange">
       </div>
          Less than Threshold 
      </div>
      <div>
      <div className="indicator_box box_red">
       </div>
          Above Threshold 
      </div>
      {(isLoading == true) ?
       displayReport() : ''
      }
      </main>
    </div>
  );
}

export default Monitoring;
