import React, { useState, useEffect, useMemo, Suspense } from 'react';
import axios from 'axios';
import "../components/ResponsiveTable1.css"
import "../components/Slide.css"
import TileLayoutTemp1 from './TileLayoutTemp1';
import EntityLayoutTemp1 from './EntityLayoutTemp1';
import { SimpleTreeView } from '@mui/x-tree-view/SimpleTreeView';
import ChannelLayoutTemp1 from './ChannelLayoutTemp2';
import { TreeItem } from '@mui/x-tree-view/TreeItem';
import Table from '@mui/material/Table';
import { TableCell, TableHead, TableRow, Divider } from '@mui/material';

import ChannelTemp1 from './ChannelTemp1';
// import TileLayout from './TileLayout';
// import EntityLayout from './EntityLayout';
import "./EntityStep.css"
const ResponsiveTableTemp1 = (props) => {
    const [transactionData, setTransactionData] = useState([])
    const [channelData, setChannelData] = useState([])
    // const [entityStepData, setentityStepData] = useState([])
    const [channelDetails, setChannelDetails] = useState({})
    const [entityName, setEntityName] = useState("")
    const [channelDetailsKibana, setChannelDetailsKibana] = useState({})
    const [treeExpandedKibana, settreeExpandedKibana] = useState([])
    const [channelDetailsDB, setchannelDetailsDB] = useState({})
    const [treeExpandedDB, settreeExpandedDB] = useState([])
    const [entityChannel, setentityChannel] = useState([])
    const [channelAPI, sethcannelAPI] = useState([])
    const [entityData, setEntityData] = useState([])
    const [transactionId, setTransactionID] = useState(1)
    const [isSlideOpen, setIsSlideOpne] = useState(false)
    const [isApiSlide, setisApiSlide] = useState(false)
    const [channelName, setchannelName] = useState('')
    
    const handleExpandedItemsChangeKibana = (event, itemIds) => {
      settreeExpandedKibana(itemIds);
    };
    const handleExpandedItemsChangeDB = (event, itemIds) => {
      settreeExpandedDB(itemIds);
    }
    const handleToggle1 = (t_id,e_name) => {
      if (setIsSlideOpne) {
      axios
        .get("http://localhost:8000/getChannelDetails/"+t_id+"/"+e_name)
        .then((res) => {
          setEntityName(res.data['ENTITY_NAME'])
          setChannelDetailsKibana(res.data['KIBANA'])
          setchannelDetailsDB(res.data['DB'])
          let dataKibana = Object.keys(res.data['KIBANA']).map((key, index) => index)
          settreeExpandedKibana(dataKibana)
          let dataDb = Object.keys(res.data['DB']).map((key, index) => index)
          settreeExpandedKibana(dataKibana)
          settreeExpandedDB(dataDb);
        })
      }
      setIsSlideOpne(!isSlideOpen)
  }
    
    const closeTreeSlide = () => {
      setIsSlideOpne(false)
    }
    const closeApiSlide = () => {
      setisApiSlide(false)
    }
    
    // channelDetails[key]['count']
    
    return (
            <div className='App'>
            {/* <ChannelLayoutTemp1 entityChannel={props.entityChannel} getChannel={getChannel}></ChannelLayoutTemp1> */}
            <TileLayoutTemp1 transactionData={props.transactionData} callAPIAfterTransaction={props.callAPIAfterTransaction}></TileLayoutTemp1>
            
            {/* <ChannelTemp1 channelData={channelData} ></ChannelTemp1> */}
            <EntityLayoutTemp1 entityData={props.entityData} handleToggle1={handleToggle1}></EntityLayoutTemp1>
            {isSlideOpen &&(
                <div className={`slide ${isSlideOpen? 'open': ''}`} style={{overflow: 'auto'}}>
                    <div className='close-button' onClick={closeTreeSlide}>
                        Close
                    </div><br/><br/><br/><br/>
                    <div style={{ margin: '1rem', width: '100%'}}>
                    <div style={{float:'left', marginLeft: '30%', fontWeight: 'bold'}}>{entityName.toLocaleUpperCase()}</div><br/><br/>
                    {Object.keys(channelDetailsKibana).length > 0 ? <div style={{float: 'left'}}>
                    <span>KIBANA</span>
                    <SimpleTreeView  expandedItems={treeExpandedKibana} onExpandedItemsChange={handleExpandedItemsChangeKibana}>
                     {
                      Object.keys(channelDetailsKibana).map((key, index) => (
                        <TreeItem itemId={index} label={(<a href={"https://peganextgen-kibana.verizon.com/app/discover#/?_g=(filters:!(),query:(language:kuery,query:''),refreshInterval:(pause:!t,value:0),time:(from:now-1h,to:now))&_a=(columns:!(api_subname,exception),filters:!(('$state':(store:appState),meta:(alias:!n,disabled:!f,index:'d06a44f1-18c3-498a-b7be-e39be2eae92d',key:api_subname,negate:!f),query:(match_phrase:(api_subname:'"+key+"'))),('$state':(store:appState),meta:(alias:!n,disabled:!f,index:'d06a44f1-18c3-498a-b7be-e39be2eae92d',key:api_status_code,negate:!t,params:(query:'200'),type:phrase),query:(match_phrase:(api_status_code:'200')))),index:'d06a44f1-18c3-498a-b7be-e39be2eae92d',interval:auto,query:(language:kuery,query:"+channelDetailsKibana[key]['filter']+"),sort:!(!('@timestamp',desc)))"} target="_blank" style={{textDecoration: 'none', fontWeight: channelDetailsKibana[key]['count'] > 50  ? 'bold': '', color: channelDetailsKibana[key]['count'] > 50 ? 'red': 'green'}}>{key+" - "+channelDetailsKibana[key]['count']}</a>)} >
                          {
                            channelDetailsKibana[key]['channel']?.map((key1, index1) => (
                              <TreeItem itemId={key+"_"+key1['channel']} label={channelDetailsKibana[key]['filter']? (<a href={"https://peganextgen-kibana.verizon.com/app/discover#/?_g=(filters:!(),query:(language:kuery,query:''),refreshInterval:(pause:!t,value:0),time:(from:now-1h,to:now))&_a=(columns:!(api_subname,client_id,exception),filters:!(('$state':(store:appState),meta:(alias:!n,disabled:!f,index:'d06a44f1-18c3-498a-b7be-e39be2eae92d',key:api_subname,negate:!f,params:(query:"+key+"),type:phrase),query:(match_phrase:(api_subname:'"+key+"'))),('$state':(store:appState),meta:(alias:!n,disabled:!f,index:'d06a44f1-18c3-498a-b7be-e39be2eae92d',key:api_status_code,negate:!t,params:(query:'200'),type:phrase),query:(match_phrase:(api_status_code:'200'))),('$state':(store:appState),meta:(alias:!n,disabled:!f,index:'d06a44f1-18c3-498a-b7be-e39be2eae92d',key:client_id,negate:!f,type:phrase),query:(bool:(minimum_should_match:1,should:!((match_phrase:(client_id:"+key1['channel']+"))))))),index:'d06a44f1-18c3-498a-b7be-e39be2eae92d',interval:auto,query:(language:kuery,query:''),sort:!(!('@timestamp',desc)))"} target="_blank" style={{textDecoration: 'none'}}>{key1['channel']+" - "+key1['count']}</a>):key1['channel']+" - "+key1['count']}
                              ></TreeItem>
                            ))
                          }
                        </TreeItem>
                      ))
                     }
                         
                    </SimpleTreeView>
                    </div>:''}
                    {/* <div style={{borderLeft: "2px solid grey", height: "100%"}}></div> */}
                    {Object.keys(channelDetailsDB).length > 0 ? <div style={{float: 'right', paddingRight: '64px'}}>
                    <span >DATABASE</span>
                    <SimpleTreeView  expandedItems={treeExpandedDB} onExpandedItemsChange={handleExpandedItemsChangeDB}>
                      {
                      Object.keys(channelDetailsDB).map((key, index) => (
                      <TreeItem itemId={index} label={(<a href={`/monitoring/report/?api=${key}&transactionName=${props.transactionName}`} target="_blank" style={{textDecoration: 'none', wordWrap:'break-word', fontWeight: channelDetailsDB[key]['count'] > 50  ? 'bold': 'bold', color: channelDetailsDB[key]['count'] > 50 ? 'red': 'green'}}>{key+"  -  "+channelDetailsDB[key]['count'] > 50?channelDetailsDB[key]['count']:key}</a>)}>
                        {
                          channelDetailsDB[key]['channel']?.map((key1, index1) => (
                            <TreeItem itemId={key+"_"+key1['channel']} label={key1['channel']+"  -  "+key1['count'] > 20?key1['count']:key1['channel']}
                            ></TreeItem>
                          ))
                        }
                      </TreeItem>
                        ))
                      }
                          
                    </SimpleTreeView>
                    </div>:""}
                    </div>
                </div>
            )}
            
            </div>
    )
}

export default ResponsiveTableTemp1;
