import React, { useState} from 'react';
import { TileContainer} from '@vds/tiles';
import { Title } from '@vds/typography';
import { Input } from '@vds/inputs';
import { Button } from '@vds/buttons';







const Home=()=>{
    const [username, setuserName] = useState('')
    const [pass, setPass] = useState('')
    const authUser = () => {
       if(username == 'CXP_MONITORING' && pass == 'm@_CXP##@495') {
            sessionStorage.setItem('auth', 'true')
            document.location.href = '/anomaly'
       } else if(username == 'CXP_LEADERS' && pass == 'cXP@23J#TY') {
            sessionStorage.setItem('auth', 'true')
            document.location.href = '/sms'
       }
        else {
        sessionStorage.setItem('auth', 'false')
       }
    }
    return(
        <div style={{height: '400px', width: '350px', borderRadius: '12px', borderColor: '#d3d3d3', borderStyle: 'solid', textAlign:'center', margin: '19px auto'}}>
           <TileContainer
            padding='24px'
            aspectRatio='1:1'
            width='168px'
            surface="dark"
            backgroundColor="white"
            >
                <Title color='black' size='TitleMedium'bold={true}> Sign in </Title>
                <div style={{float: 'left', position:'absolute', paddingTop: '50px', width:'300px'}}>
                    <Input 
                    type="username" 
                    label="Username"
                    mask="toggle"
                    readOnly={false}
                    onChange={(evt) => setuserName(evt.target.value)}
                    disabled={false}
                    error={false}
                    />
                </div>
                <div style={{float: 'left', position:'absolute', marginTop: '150px', width:'300px'}}>
                    <Input 
                    type="password" 
                    label="Password"
                    mask="toggle"
                    readOnly={false}
                    onChange={(evt) => setPass(evt.target.value)}
                    disabled={false}
                    error={false}
                    />

                </div>
            <div style={{float: 'left', position:'absolute', marginTop: '250px', width:'300px'}}>
            <Button 
                size="large"
                width='300px'
                disabled={false}
                onClick={(evt) => authUser()}
                use="primary"
                >
                Sign In
                </Button>

            </div>
            </TileContainer>
            </div>
        
        
    )
}

export default Home