import * as React from 'react';
import Box from '@mui/material/Box';
import { SimpleTreeView } from '@mui/x-tree-view/SimpleTreeView';
import { TreeItem } from '@mui/x-tree-view/TreeItem';
import { BarChart } from '@mui/x-charts/BarChart';
export default function TestingTree() {
    let final_data=[]
    
    const [store_details, setStoreDetails] = React.useState([
        {
            "store_loc": "P336701",
            "store_name": "Odessa",
            "call_details": [
                {
                    "call_reason": [
                        "Disconnect"
                    ],
                    "call_counts": 10
                },
                {
                    "call_reason": [
                        "PortCenter"
                    ],
                    "call_counts": 34
                },
                {
                    "call_reason": [
                        "TechSup Connected Device"
                    ],
                    "call_counts": 2
                },
                {
                    "call_reason": [
                        "CARE"
                    ],
                    "call_counts": 294
                },
                {
                    "call_reason": [
                        "Fraud"
                    ],
                    "call_counts": 11
                },
                {
                    "call_reason": [
                        "TechSup LTE Internet"
                    ],
                    "call_counts": 2
                },
                {
                    "call_reason": [
                        "CreditApp Fraud"
                    ],
                    "call_counts": 11
                },
                {
                    "call_reason": [
                        "Other"
                    ],
                    "call_counts": 1
                },
                {
                    "call_reason": [
                        "Activation Failure"
                    ],
                    "call_counts": 51
                },
                {
                    "call_reason": [
                        "TechSup SmartPhone 4G"
                    ],
                    "call_counts": 27
                },
                {
                    "call_reason": [
                        "CreditApp Consumer"
                    ],
                    "call_counts": 17
                },
                {
                    "call_reason": [
                        "TechSup TechGuru"
                    ],
                    "call_counts": 3
                }
            ]
        },
        {
            "store_loc": "0030701",
            "store_name": "King Of Prussia",
            "call_details": [
                {
                    "call_reason": [
                        "PortCenter"
                    ],
                    "call_counts": 18
                },
                {
                    "call_reason": [
                        "Disconnect"
                    ],
                    "call_counts": 11
                },
                {
                    "call_reason": [
                        "TechSup Connected Device"
                    ],
                    "call_counts": 1
                },
                {
                    "call_reason": [
                        "CARE"
                    ],
                    "call_counts": 82
                },
                {
                    "call_reason": [
                        "TechSup NwkExtender"
                    ],
                    "call_counts": 1
                },
                {
                    "call_reason": [
                        "CreditApp Fraud"
                    ],
                    "call_counts": 2
                },
                {
                    "call_reason": [
                        "Activation Failure"
                    ],
                    "call_counts": 24
                },
                {
                    "call_reason": [
                        "CreditApp Consumer"
                    ],
                    "call_counts": 3
                },
                {
                    "call_reason": [
                        "TechSup SmartPhone 4G"
                    ],
                    "call_counts": 3
                }
            ]
        },
        {
            "store_loc": "0315801",
            "store_name": "Springfield PA",
            "call_details": [
                {
                    "call_reason": [
                        "Disconnect"
                    ],
                    "call_counts": 28
                },
                {
                    "call_reason": [
                        "PortCenter"
                    ],
                    "call_counts": 23
                },
                {
                    "call_reason": [
                        "CARE"
                    ],
                    "call_counts": 91
                },
                {
                    "call_reason": [
                        "Fraud"
                    ],
                    "call_counts": 1
                },
                {
                    "call_reason": [
                        "CreditApp Fraud"
                    ],
                    "call_counts": 1
                },
                {
                    "call_reason": [
                        "Activation Failure"
                    ],
                    "call_counts": 40
                },
                {
                    "call_reason": [
                        "TechSup SmartPhone 4G"
                    ],
                    "call_counts": 7
                },
                {
                    "call_reason": [
                        "CreditApp Consumer"
                    ],
                    "call_counts": 4
                }
            ]
        },
        {
            "store_loc": "0363101",
            "store_name": "Downingtown Exton"
        },
        {
            "store_loc": "0444601",
            "store_name": "Ardmore",
            "call_details": [
                {
                    "call_reason": [
                        "Disconnect"
                    ],
                    "call_counts": 24
                },
                {
                    "call_reason": [
                        "PortCenter"
                    ],
                    "call_counts": 1
                },
                {
                    "call_reason": [
                        "TechSup Connected Device"
                    ],
                    "call_counts": 1
                },
                {
                    "call_reason": [
                        "OverrideRequests"
                    ],
                    "call_counts": 4
                },
                {
                    "call_reason": [
                        "CARE"
                    ],
                    "call_counts": 77
                },
                {
                    "call_reason": [
                        "Activation Failure"
                    ],
                    "call_counts": 13
                },
                {
                    "call_reason": [
                        "TechSup SmartPhone 4G"
                    ],
                    "call_counts": 2
                }
            ]
        },
        {
            "store_loc": "D511401",
            "store_name": "Royersford",
            "call_details": [
                {
                    "call_reason": [
                        "Disconnect"
                    ],
                    "call_counts": 11
                },
                {
                    "call_reason": [
                        "PortCenter"
                    ],
                    "call_counts": 3
                },
                {
                    "call_reason": [
                        "TechSup Connected Device"
                    ],
                    "call_counts": 2
                },
                {
                    "call_reason": [
                        "CARE"
                    ],
                    "call_counts": 21
                },
                {
                    "call_reason": [
                        "CreditApp Fraud"
                    ],
                    "call_counts": 2
                },
                {
                    "call_reason": [
                        "Upgrade eligibility Correction"
                    ],
                    "call_counts": 1
                },
                {
                    "call_reason": [
                        "Other"
                    ],
                    "call_counts": 1
                },
                {
                    "call_reason": [
                        "Activation Failure"
                    ],
                    "call_counts": 9
                },
                {
                    "call_reason": [
                        "TechSup SmartPhone 4G"
                    ],
                    "call_counts": 1
                },
                {
                    "call_reason": [
                        "CreditApp Consumer"
                    ],
                    "call_counts": 1
                }
            ]
        },
        {
            "store_loc": "D221701",
            "store_name": "Flemington",
            "call_details": [
                {
                    "call_reason": [
                        "Disconnect"
                    ],
                    "call_counts": 45
                },
                {
                    "call_reason": [
                        "PortCenter"
                    ],
                    "call_counts": 1
                },
                {
                    "call_reason": [
                        "CARE"
                    ],
                    "call_counts": 46
                },
                {
                    "call_reason": [
                        "CreditApp Fraud"
                    ],
                    "call_counts": 2
                },
                {
                    "call_reason": [
                        "Activation Failure"
                    ],
                    "call_counts": 10
                },
                {
                    "call_reason": [
                        "TechSup SmartPhone 4G"
                    ],
                    "call_counts": 6
                },
                {
                    "call_reason": [
                        "CreditApp Consumer"
                    ],
                    "call_counts": 1
                }
            ]
        },
        {
            "store_loc": "D492501",
            "store_name": "Middletown DE",
            "call_details": [
                {
                    "call_reason": [
                        "PortCenter"
                    ],
                    "call_counts": 3
                },
                {
                    "call_reason": [
                        "Disconnect"
                    ],
                    "call_counts": 31
                },
                {
                    "call_reason": [
                        "OverrideRequests"
                    ],
                    "call_counts": 2
                },
                {
                    "call_reason": [
                        "CARE"
                    ],
                    "call_counts": 38
                },
                {
                    "call_reason": [
                        "CreditApp Fraud"
                    ],
                    "call_counts": 4
                },
                {
                    "call_reason": [
                        "Activation Failure"
                    ],
                    "call_counts": 12
                },
                {
                    "call_reason": [
                        "TechSup SmartPhone 4G"
                    ],
                    "call_counts": 5
                }
            ]
        },
        {
            "store_loc": "D228801",
            "store_name": "Bridgewater",
            "call_details": [
                {
                    "call_reason": [
                        "Disconnect"
                    ],
                    "call_counts": 7
                },
                {
                    "call_reason": [
                        "PortCenter"
                    ],
                    "call_counts": 1
                },
                {
                    "call_reason": [
                        "OverrideRequests"
                    ],
                    "call_counts": 1
                },
                {
                    "call_reason": [
                        "CARE"
                    ],
                    "call_counts": 99
                },
                {
                    "call_reason": [
                        "Fraud"
                    ],
                    "call_counts": 1
                },
                {
                    "call_reason": [
                        "Upgrade eligibility Correction"
                    ],
                    "call_counts": 2
                },
                {
                    "call_reason": [
                        "CreditApp Fraud"
                    ],
                    "call_counts": 2
                },
                {
                    "call_reason": [
                        "Activation Failure"
                    ],
                    "call_counts": 20
                },
                {
                    "call_reason": [
                        "TechSup SmartPhone 4G"
                    ],
                    "call_counts": 5
                }
            ]
        }
    ])
    let chart_details={'store_details': [{'store_loc': 'P336701', 'store_name': 'Odessa', 'counts': [0, 7, 0, 0, 2, 1, 3, 4, 1, 0, 1, 0, 0, 1, 1, 1, 1, 0, 1, 4, 2, 5, 2, 3, 1, 1, 2, 1, 4, 0, 2, 0, 0]}, {'store_loc': '0030701', 'store_name': 'King Of Prussia', 'counts': [1, 4, 0, 0, 2, 0, 0, 2, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 2, 2, 0, 0, 2, 3, 0, 0, 0, 1, 0, 3, 0, 0, 0]}, {'store_loc': '0315801', 'store_name': 'Springfield PA', 'counts': [0, 3, 0, 0, 1, 4, 2, 4, 0, 0, 2, 0, 0, 3, 2, 0, 0, 0, 0, 2, 3, 0, 0, 6, 5, 0, 0, 0, 1, 2, 0, 0, 0]}, {'store_loc': '0363101', 'store_name': 'Downingtown Exton', 'counts': [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]}, {'store_loc': '0444601', 'store_name': 'Ardmore', 'counts': [0, 3, 0, 0, 0, 4, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 2, 0, 1, 0, 0, 0, 0, 0, 0, 0]}, {'store_loc': 'D511401', 'store_name': 'Royersford', 'counts': [0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 2, 0, 0, 0, 0, 1, 0, 0, 4, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0]}, {'store_loc': 'D221701', 'store_name': 'Flemington', 'counts': [0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 1, 1, 0, 1, 0, 0, 2, 0, 0, 0, 1, 0]}, {'store_loc': 'D492501', 'store_name': 'Middletown DE', 'counts': [0, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 2, 3, 1, 0, 0, 0, 0]}, {'store_loc': 'D228801', 'store_name': 'Bridgewater', 'counts': [1, 0, 0, 2, 2, 0, 3, 2, 2, 1, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 2, 1, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0]}], 'dates': ['2025-02-01', '2025-02-02', '2025-02-03', '2025-02-04', '2025-02-05', '2025-02-06', '2025-02-07', '2025-02-08', '2025-02-09', '2025-02-10', '2025-02-11', '2025-02-12', '2025-02-13', '2025-02-14', '2025-02-15', '2025-02-16', '2025-02-17', '2025-02-18', '2025-02-19', '2025-02-20', '2025-02-21', '2025-02-22', '2025-02-23', '2025-02-24', '2025-02-25', '2025-02-26', '2025-02-27', '2025-02-28', '2025-03-01', '2025-03-02', '2025-03-03', '2025-03-04', '2025-03-05']}
    let series=[]
    chart_details?.store_details?.map((row,index) => {
      let series_obj={}
      series_obj['data'] = row.counts;
      series.push(series_obj)
    })
  return (
    <Box >
      <div style={{float: "left"}}>
      <SimpleTreeView>
      {store_details?.map((row,index) => (
        <TreeItem itemId={index} label={row['store_loc']+"-"+row['store_name']}>
            {row?.call_details?.map((row1,index1) => (
                
                (row1['call_reason'] == 'Activation Failure')?<TreeItem itemId={row['store_name']+"_"+row1['call_reason']+index1} label={row1['call_reason']+"-"+row1['call_counts']}/>:""
            ))}
         
        </TreeItem>))}
      </SimpleTreeView>
      </div>
      <div style={{float: "left"}}>
      <BarChart
      series={series}
      width={1500}
      height={290}
      xAxis={[{ data: ['FEB-1','FEB-2','FEB-3','FEB-4','FEB-5','FEB-6','FEB-7','FEB-8','FEB-9','FEB-10','FEB-11','FEB-12','FEB-13','FEB-14','FEB-15','FEB-16','FEB-17','FEB-18','FEB-19','FEB-20','FEB-21','FEB-22','FEB-23','FEB-24','FEB-25','FEB-26','FEB-27','FEB-28','MAR-1','MAR-2','MAR-3','MAR-4'], scaleType: 'band' }]}
      margin={{ top: 10, bottom: 30, left: 40, right: 10 }}
    />
      </div>
    </Box>
  );
}
