import React, { useState, useEffect, useMemo, Suspense } from 'react';


import '../App.css';
import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import Box from '@mui/material/Box';
import Paper from '@mui/material/Paper';
import { experimentalStyled as styled } from '@mui/material/styles';
import Button from '@mui/material/Button';
import Menu from '@mui/material/Menu';
import MenuItem from '@mui/material/MenuItem';
import Table from '@mui/material/Table';

import { TableCell, TableHead, TableRow } from '@mui/material';
import { makeStyles } from '@mui/styles';
import axios from 'axios';

const userStyles = makeStyles({
 
 
  table: {
    backgroundColor: 'rgb(246, 246, 246) !important',
    borderCollapse: 'separate !important'
  },
  thead: {
    backgroundColor: 'rgb(246, 246, 246)',
  },
  segmentParent: {
    color: 'black',
    fontSize: '1.1rem !important',
    fontWeight: 'bold !important',
    width: '10%'
  },
  category: {
    color: 'black',
    fontSize: '1.1rem !important',
    fontWeight: 'bold !important'
  },
  categoryTD: {
   borderRadius: '6px',
   padding: '20px',
   border: '1px solid #000',
   marginTop: '5px'
  },
  categorythreshold: {
    fontWeight: 'bold',
    fontSize: '1.1rem',
    
  }
});

const MonitoringNew = () => {
  const classes = userStyles();
  const [tabvalue, setTabValue] = useState('Mobility');
  const [confData, setconfData] = useState({});
  const [textColor, setTextcolor] = useState('red');
  const [segDetails, setsegDetails] = useState({});
  const [isLoading, setisLoading] = useState(false);
  const [anchorEl, setAnchorEl] = React.useState(null);
  const open = Boolean(anchorEl);
  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
    ///displayReport()
  };
  
  useEffect(() => {
    axios
      .get("http://localhost:8000/getConfDetails")
      .then((res) => {
        setconfData(res.data);
        setisLoading(true);
       //console.log("resresresresres ===>", res)
      })
  },[])

  // useEffect(() => {
  //   axios
  //     .get("http://localhost:8080/sog/getAllSegmentsByChannelId/1")
  //     .then((res) => {
  //      setsegDetails(res.data);
  //      setisLoading(true);
  //      console.log("resresresresres ===>", res);
  //     })
  // },[])

  
  const displayReport = () => {
    console.log("segDetailssegDetails ==>",segDetails);
    return (
      <Table aria-label="sticky table" className={classes.table}>
      {
        segDetails?.['sogParentSegmentModel']?.map((segment,i) => {
          return (
            <TableRow key={i}>
            <TableCell align='left' className={classes.segmentParent}>{segment['segmentName']}</TableCell>
            <TableCell align='left' className={classes.category}>
            <div className="container">
            {
              segment?.['sogChildSegmentModel']?.map((segChild,i) => {
                    return (
                     
                      <div className={classes.categoryTD} style={{"backgroundColor": segChild['color'], "color": 'white'}}>
                        <bold>{segChild['segmentName']}</bold> : <bold className={classes.categorythreshold} >{segChild['count']}</bold>
                      </div>
                    )
              })
            }
            </div>
            </TableCell>
            </TableRow>
          )
        })
      }
      
    </Table>
    )
  }

  
  const Item = styled(Paper)(({ theme }) => ({
    backgroundColor: '#fff',
    ...theme.typography.body2,
    padding: theme.spacing(2),
    textAlign: 'center',
    color: theme.palette.text.secondary,
    ...theme.applyStyles('dark', {
      backgroundColor: '#FFF',
    }),
  }));
  return(
    <div className="app">
      <header >
      <Box sx={{ width: '100%' }}>
      <Button
        id="mobility-button"
        aria-controls={open ? 'basic-menu' : undefined}
        aria-haspopup="true"
        aria-expanded={open ? 'true' : undefined}
        onClick={handleClick}
      >
        MOBILITY
      </Button>
      <Button
        id="fwa-button"
        aria-controls={open ? 'basic-menu' : undefined}
        aria-haspopup="true"
        aria-expanded={open ? 'true' : undefined}
        onClick={handleClick}
      >
        FWA
      </Button>
      <Menu
        id="mobility-menu"
        anchorEl={anchorEl}
        open={open}
        onClose={handleClose}
        MenuListProps={{
          'aria-labelledby': 'mobility-button',
        }}
      >
        <MenuItem onClick={handleClose}>Digital</MenuItem>
        
      </Menu>
      <Menu
        id="fwa-menu"
        anchorEl={anchorEl}
        open={open}
        onClose={handleClose}
        MenuListProps={{
          'aria-labelledby': 'fwa-button',
        }}
      >
        <MenuItem onClick={handleClose}>Digital</MenuItem>
        
      </Menu>
      
    </Box>
      </header>
      <main className="main">
      <Box sx={{ flexGrow: 1 }} style={{"width": '100%'}}>
      {(isLoading == true) ?
       displayReport() : ''
      }
      </Box>
      </main>
    </div>
  );
}

export default MonitoringNew;
