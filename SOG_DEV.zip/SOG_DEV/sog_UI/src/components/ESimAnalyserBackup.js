import React, { useState, useEffect, useMemo, Suspense } from 'react';


import '../App.css';
import Box from '@mui/material/Box';
import Paper from '@mui/material/Paper';
import { experimentalStyled as styled } from '@mui/material/styles';
import Grid from '@mui/material/Grid';
import Table from '@mui/material/Table';
import { TableCell, TableHead, TableRow,TableContainer } from '@mui/material';
import { makeStyles } from '@mui/styles';
import axios from 'axios';
import Accordion from '@mui/material/Accordion';
import AccordionActions from '@mui/material/AccordionActions';
import AccordionSummary from '@mui/material/AccordionSummary';
import AccordionDetails from '@mui/material/AccordionDetails';
import Typography from '@mui/material/Typography';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import Button from '@mui/material/Button';
import { Loader } from '@vds/loaders';
import TableBody from '@mui/material/TableBody';


import Stepper from '@mui/material/Stepper';
import Step from '@mui/material/Step';
import StepLabel from '@mui/material/StepLabel';
import StepContent from '@mui/material/StepContent';







const ESimAnalyser = () => {
 const [simData, setsimData] = useState()
 const [analyser_data, setAnalyser]=useState()
 
const [loader, setLoader] = useState(false)
  const getESimData =(e) => {
    setLoader(true)
    const payload={}
    payload["mtn"] = simData;
    axios.post(`http://localhost:8000/esimAnalyser`, payload)
    .then(res => {
        setAnalyser(res.data);
        setLoader(false)
    })
  }
  return(
    <div >
       
     <br></br>
      <main className="app">
      <div >
      {loader ? <Loader fullscreen={true} active={true} surface='dark' />: ""}
      <div style={{marginLeft: '500px'}}>MTN : <input type="text" className="form-control" placeholder="MTN..." aria-describedby="project-search-addon" onChange={(e)=>{setsimData(e.target.value)}}/>
      <button onClick={(e)=>getESimData()}>GO</button>
      </div>
      {(analyser_data?.ORDER_DETAILS) ? <div>   

      <Accordion defaultExpanded>
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel1-content"
          id="panel1-header"
        >
          <Typography component="span">ORDER DETAILS</Typography>
         
        </AccordionSummary>
        <AccordionDetails>
        <TableContainer component={Paper}>
      <Table sx={{ minWidth: 650 }} aria-label="simple table">
        <TableHead>
          <TableRow>
            <TableCell>TIME_STAMP</TableCell>
            <TableCell align="center">ORDER_NUMBER</TableCell>
            <TableCell align="center">LOCATION_CODE</TableCell>
            <TableCell align="center">CART_ID</TableCell>
            <TableCell align="center">SOURCE_IND</TableCell>
            <TableCell align="center">ORDER_TYPE</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {analyser_data?.ORDER_DETAILS?.map((row,index) => (
            <TableRow
              key={index}
              sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
            >
              <TableCell component="th" scope="row">
                {row.ACE_IT_TIMESTAMP}
              </TableCell>
              <TableCell align="center">{row.ACE_IT_ORD_NUM}</TableCell>
              <TableCell align="center">{row.ACE_IT_LOCATION_CODE}</TableCell>
              <TableCell align="center">{row.CART_ID}</TableCell>
              <TableCell align="center">{row.ORDER_SOURCE_ID}</TableCell>
              <TableCell align="center">{row.ORDER_TYPE}</TableCell>
            </TableRow>
          ))}
        </TableBody>
        </Table>
        </TableContainer>
        </AccordionDetails>
      </Accordion><br/>
      <Accordion defaultExpanded>
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel2-content"
          id="panel2-header"
        >
          <Typography component="span">ICCID DETAILS</Typography>
        </AccordionSummary>
        <AccordionDetails>
        <TableContainer component={Paper}>
      <Table sx={{ minWidth: 650 }} aria-label="simple table">
        <TableHead>
          <TableRow>
            <TableCell>TIME_STAMP</TableCell>
            <TableCell align="center">OLD_ICCID</TableCell>
            <TableCell align="center">NEW_ICCID</TableCell>
            <TableCell align="center">MTN</TableCell>
            
          </TableRow>
        </TableHead>
        <TableBody>
          {analyser_data?.ORDER_ICCID?.map((row,index) => (
            <TableRow
              key={index}
              sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
            >
              <TableCell component="th" scope="row">
                {row.CVIS_TIME_STAMP}
              </TableCell>
              <TableCell align="center">{row['OLD ICCID']}</TableCell>
              <TableCell align="center">{row['NEW ICCID']}</TableCell>
              <TableCell align="center">{row.MTN}</TableCell>
              
            </TableRow>
          ))}
        </TableBody>
        </Table>
        </TableContainer>
        </AccordionDetails>
      </Accordion><br/>
      <Accordion defaultExpanded>
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel3-content"
          id="panel3-header"
        >
          <Typography component="span">MLMO DETAILS</Typography>
        </AccordionSummary>
        <AccordionDetails>
        <TableContainer component={Paper}>
      <Table sx={{ minWidth: 650 }} aria-label="simple table">
        <TableHead>
          <TableRow>
            <TableCell>TIME_STAMP</TableCell>
            <TableCell align="center">ORDER_NUMBER</TableCell>
            <TableCell align="center">LOCATION_CODE</TableCell>
            <TableCell align="center">CART_ID</TableCell>
            <TableCell align="center">ENTITY_STEP</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {analyser_data?.MLMO_DETAILS?.map((row,index) => (
            <TableRow
              key={index}
              sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
            >
              <TableCell component="th" scope="row">
                {row.TIME_STAMP}
              </TableCell>
              <TableCell align="center">{row.ORDER_NUMBER}</TableCell>
              <TableCell align="center">{row.LOCATION_CODE}</TableCell>
              <TableCell align="center">{row.CART_ID}</TableCell>
              <TableCell align="center">{row.ENTITYSTEP}</TableCell>
              
            </TableRow>
          ))}
        </TableBody>
        </Table>
        </TableContainer>
        </AccordionDetails>
        
      </Accordion><br/>
      <Accordion defaultExpanded>
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel3-content"
          id="panel3-header"
        >
          <Typography component="span">PERS DETAILS</Typography>
        </AccordionSummary>
        <AccordionDetails>
        <TableContainer component={Paper}>
      <Table sx={{ minWidth: 650 }} aria-label="simple table">
        <TableHead>
          <TableRow>
            <TableCell>TIME_STAMP</TableCell>
            <TableCell align="center">ORDER_NUMBER</TableCell>
            <TableCell align="center">LOCATION_CODE</TableCell>
            <TableCell align="center">CART_ID</TableCell>
            <TableCell align="center">ENTITY_STEP</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {analyser_data?.PERS_DETAILS?.map((row,index) => (
            <TableRow
              key={index}
              sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
            >
              <TableCell component="th" scope="row">
                {row.TIME_STAMP}
              </TableCell>
              <TableCell align="center">{row.ORDER_NUMBER}</TableCell>
              <TableCell align="center">{row.LOCATION_CODE}</TableCell>
              <TableCell align="center">{row.CART_ID}</TableCell>
              <TableCell align="center">{row.ENTITYSTEP}</TableCell>
              
            </TableRow>
          ))}
        </TableBody>
        </Table>
        </TableContainer>
        </AccordionDetails>
        
      </Accordion><br/>
      
      <Accordion defaultExpanded>
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel3-content"
          id="panel3-header"
        >
          <Typography component="span">IVR DETAILS</Typography>
        </AccordionSummary>
        <AccordionDetails>
        <TableContainer component={Paper}>
      <Table sx={{ minWidth: 650 }} aria-label="simple table">
        <TableHead>
          <TableRow>
            {/* <TableCell>TIME_STAMP</TableCell> */}
            <TableCell align="center">CompleteParkedOrder</TableCell>
            <TableCell align="center">AuthenticateUser</TableCell>
            <TableCell align="center">FindParkedOrder</TableCell>
            <TableCell align="center">ICCID</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {analyser_data?.IVR_DETAILS?.map((row,index) => (
            <TableRow
              key={index}
              sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
            >
              <TableCell component="th" scope="row">
                {(row.status !='NA') ? row.TIME_STAMP: '-'}
              </TableCell>
              <TableCell component="th" scope="row">
                {(row.CompleteParkedOrder !='NA') ? 'Yes': 'No'}
              </TableCell>
              <TableCell component="th" scope="row">
                {(row.AuthenticateUser !='NA') ? 'Yes': 'No'}
              </TableCell>
              <TableCell component="th" scope="row">
                {(row.FindParkedOrder !='NA') ? 'Yes': 'No'}
              </TableCell>
              <TableCell component="th" scope="row">
                {row.ICCID}
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
        </Table>
        </TableContainer>
        </AccordionDetails>
        
      </Accordion><br/>
      <Accordion defaultExpanded>
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel3-content"
          id="panel3-header"
        >
          <Typography component="span">SMDP DETAILS</Typography>
        </AccordionSummary>
        <AccordionDetails>
        <TableContainer component={Paper}>
      <Table sx={{ minWidth: 650 }} aria-label="simple table">
        <TableHead>
          <TableRow>
            <TableCell>TIME_STAMP</TableCell>
            <TableCell align="center">MDN</TableCell>
            <TableCell align="center">CASE_ID</TableCell>
            <TableCell align="center">EID</TableCell>
            <TableCell align="center">ICCID</TableCell>
            <TableCell align="center">SMDP_STATE</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {analyser_data?.SMDP_DETAILS?.map((row,index) => (
            <TableRow
              key={index}
              sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
            >
              <TableCell component="th" scope="row">
                {row.TIMESTAMP}
              </TableCell>
              <TableCell align="center">{row.MDN}</TableCell>
              <TableCell align="center">{row.CASE_ID}</TableCell>
              <TableCell align="center">{row.EID}</TableCell>
              <TableCell align="center">{row.ICCID}</TableCell>
              <TableCell align="center">{row.SMDP_STATE}</TableCell>
              
            </TableRow>
          ))}
        </TableBody>
        </Table>
        </TableContainer>
        </AccordionDetails>
        
      </Accordion><br/>
      <Accordion defaultExpanded>
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel3-content"
          id="panel3-header"
        >
          <Typography component="span">REMARKS DETAILS</Typography>
        </AccordionSummary>
        <AccordionDetails>
        <TableContainer component={Paper}>
      <Table sx={{ minWidth: 650 }} aria-label="simple table">
        <TableHead>
          <TableRow>
            <TableCell>TIME_STAMP</TableCell>
            <TableCell align="center">REMARKS</TableCell>
           
          </TableRow>
        </TableHead>
        <TableBody>
          {analyser_data?.REMARKS_DETAILS?.map((row,index) => (
            <TableRow
              key={index}
              sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
            >
              <TableCell component="th" scope="row">
                {row['TIME STAMP']}
              </TableCell>
             
              <TableCell align="left">{row.REMARKS}</TableCell>
              
            </TableRow>
          ))}
        </TableBody>
        </Table>
        </TableContainer>
        </AccordionDetails>
        
      </Accordion>
      </div> :""} 
    </div>
     
      </main>
    </div>
  );
}

export default ESimAnalyser;
