import React, {useState} from "react";
import "./EntityLayout.css"

const ChannelTemp1 = (props) => {
    console.log("propsprops22 ==>", props)
    return(
        <div className="grid-container">
            {props?.channelData?.map((item, index) => (
                <div key={item.CHANNEL_NAME} className={`grid-item`} style={{"backgroundColor" : item['BG_COLOR'], "color": item['TEXT_COLOR']}} onClick={()=>{props.onToggle(item.TRANSACTION_NAME,item.ENTITY_NAME)}}>
                    <div className='grid-item'>
                        <div className="text-wrapper">
                            {item.CHANNEL_NAME}
                        </div>
                    </div>
                    
                            
                </div>
            ))}
        </div>
    )
}
export default ChannelTemp1;