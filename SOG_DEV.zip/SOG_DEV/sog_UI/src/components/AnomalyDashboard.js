import React, { useState, useEffect, useMemo, Suspense } from 'react';
import axios from 'axios';
import "../components/AnomalyDashboard.css"
import { SimpleTreeView } from '@mui/x-tree-view/SimpleTreeView';
import { TreeItem } from '@mui/x-tree-view/TreeItem';



const AnomalyDashborad = (props) => {
  const [trnsactionDetails, SettrnsactionDetails] = useState({})
  const [transactionId, setTransactionID] = useState()
  const [isSlide, setisSlide] = useState(false)
  const [datime, setDatetime] = useState()
  const [entityName, setEntityName] = useState()
  const [channelDetailsKibana, setChannelDetailsKibana] = useState({})
  const [channelDetailsDB, setchannelDetailsDB] = useState({})
  const fetchTransactionData = () => {
    let channel_data={}
    
    axios
      .get("http://localhost:8000/gettransactions")
      .then((res) => {
        SettrnsactionDetails(res.data)
          var currentdate = new Date(); 
          var datetime = "Last Refresh: " + new Date().toLocaleString("en-US")
          setDatetime(datetime)
      })
      .catch(err => {
        console.error("Error fetching data:", err);
      })
      .finally(() => {
        console.error("Error fetching data:");
      });
    }
  const closeEntity = () => {
    setisSlide(false);
  }
  const showEntity = (transaction_id,entity_name) => {
    setTransactionID(transaction_id)
    setEntityName(entity_name)
    axios
    .get("http://localhost:8000/getChannelDetails/"+transaction_id+"/"+entity_name)
    .then((res) => {
          setChannelDetailsKibana(res.data['KIBANA'])
          setchannelDetailsDB(res.data['DB'])
    })
    setisSlide(true);
  }
    // channelDetails[key]['count']
    useEffect(() => {
            fetchTransactionData()
            const interval = setInterval(() => {
                fetchTransactionData()
                //fetchTransactionData_db()
              },10000);
              return () => clearInterval(interval) 
          },[]);
    return (
            <div>
              
              <div style={{width: '98%', height: '50px',backgroundColor: 'black', marginLeft: '10px', marginTop: '12px', borderRadius: '11px'}}>
                  <img src="../../../vz.png" style={{height: '37px', paddingLeft: '18px', paddingTop:'6px'}}></img> <span style={{color: 'white', paddingTop: '15px', position: 'absolute'}}>Live Anomaly Detector</span>
                  <span style={{color: 'white', float: 'right', paddingTop: '15px', paddingRight: "43px"}}>{datime}</span>
              </div>
              <div className="container" id="dashboard">
                {
                  Object.keys(trnsactionDetails).map((tra_key,tra_index) => {
                    return (
                            <>
                              <div className='division'>
                                <div className='division-header'>
                                    <div className='division-title'>
                                        {trnsactionDetails[tra_key]['TRANSACTION_NAME']}
                                    </div>
                                    <div className='health-box-txt'>
                                    Overall Health : 
                                    </div>
                                    <div className='health-box' style={{backgroundColor: trnsactionDetails[tra_key]['TRANSACTION_BG_COLOR']}}>
                                    
                                    </div>
                                </div>
                                <div className='tiles'>
                                  {trnsactionDetails[tra_key]['ENTITY_DETAILS']?.map((ety, ety_ind) =>
                                    <div className='tile' style={{backgroundColor: ety['BG_COLOR'], color: ety['TEXT_COLOR']}}  onClick={(evt) => showEntity(tra_key,ety['ENTITY_NAME'])}>
                                        {ety['ENTITY_NAME']}
                                    </div>
                                  )}
                                  
                                </div>
                            </div>
                           {tra_index< Object.keys(trnsactionDetails).length-1? <div className='divider'></div>:''}
                            </>
                        )
                  })
                }
              </div>
              {isSlide ? <div className={`slide ${isSlide? 'open': ''}`} style={{overflow: 'auto'}}>
                           <div className='modal-header'>
                            <div className='close-button' onClick={(evt)=> closeEntity()}>
                              Close - X
                            </div>
                            <div style={{fontWeight: 'bold'}}>{entityName.toLocaleUpperCase()}</div>
                            </div>
                            <div className='entity-container'>
                              <div className='entity-container-kibana' >Kibana
                                <hr class="entity-horizontal-divider"></hr>
                                {
                                    Object.keys(channelDetailsKibana).length > 0 ?
                                    <SimpleTreeView>
                                      {
                                         Object.keys(channelDetailsKibana).map((key, index) => (
                                            <TreeItem itemId={key+"_"+index+"_"+transactionId+"_"+channelDetailsKibana[key]['api_name']} label={(<a href={"https://peganextgen-kibana.verizon.com/app/discover#/?_g=(filters:!(),query:(language:kuery,query:''),refreshInterval:(pause:!t,value:0),time:(from:now-1h,to:now))&_a=(columns:!(api_subname,exception),filters:!(('$state':(store:appState),meta:(alias:!n,disabled:!f,index:'d06a44f1-18c3-498a-b7be-e39be2eae92d',key:api_subname,negate:!f),query:(match_phrase:(api_subname:'"+channelDetailsKibana[key]['api_name']+"'))),('$state':(store:appState),meta:(alias:!n,disabled:!f,index:'d06a44f1-18c3-498a-b7be-e39be2eae92d',key:api_status_code,negate:!t,params:(query:'200'),type:phrase),query:(match_phrase:(api_status_code:'200')))),index:'d06a44f1-18c3-498a-b7be-e39be2eae92d',interval:auto,query:(language:kuery,query:"+(channelDetailsKibana[key]['filter'] != '' ? channelDetailsKibana[key]['filter']:"''") +"),sort:!(!('@timestamp',desc)))"} target="_blank" style={{textDecoration: 'none', fontWeight: channelDetailsKibana[key]['count'] > 20  ? 'bold': 'bold', color: channelDetailsKibana[key]['count'] > 20 ? 'red': 'green'}}>{key +' ( '+channelDetailsKibana[key]['count']+' ) '}</a>)} >
                                                    {
                                                        channelDetailsKibana[key]['channel']?.map((key1, index1) => (
                                                          <TreeItem itemId={key+"_"+index1+"_"+transactionId+channelDetailsKibana[key]['api_name']} label={(<a href={"https://peganextgen-kibana.verizon.com/app/discover#/?_g=(filters:!(),query:(language:kuery,query:''),refreshInterval:(pause:!t,value:0),time:(from:now-1h,to:now))&_a=(columns:!(api_subname,client_id,exception),filters:!(('$state':(store:appState),meta:(alias:!n,disabled:!f,index:'d06a44f1-18c3-498a-b7be-e39be2eae92d',key:api_subname,negate:!f,params:(query:"+channelDetailsKibana[key]['api_name']+"),type:phrase),query:(match_phrase:(api_subname:'"+channelDetailsKibana[key]['api_name']+"'))),('$state':(store:appState),meta:(alias:!n,disabled:!f,index:'d06a44f1-18c3-498a-b7be-e39be2eae92d',key:api_status_code,negate:!t,params:(query:'200'),type:phrase),query:(match_phrase:(api_status_code:'200'))),('$state':(store:appState),meta:(alias:!n,disabled:!f,index:'d06a44f1-18c3-498a-b7be-e39be2eae92d',key:client_id,negate:!f,type:phrase),query:(bool:(minimum_should_match:1,should:!((match_phrase:(client_id:"+key1['channel']+"))))))),index:'d06a44f1-18c3-498a-b7be-e39be2eae92d',interval:auto,query:(language:kuery,query:''),sort:!(!('@timestamp',desc)))"} target="_blank" style={{textDecoration: 'none'}}>{key1['channel']}</a>)}
                                                          ></TreeItem>
                                                        ))
                                                      }
                                            </TreeItem>
                                          ))
                                      }
                                      
                                    </SimpleTreeView>:''
                                }
                              </div>
                              
                              <div className='entity-container-divider'>
                               
                              </div>
                              <div className='entity-container-db'>Database
                              <hr class="entity-horizontal-divider"></hr>
                              {
                                    Object.keys(channelDetailsDB).length > 0 ?
                                    <SimpleTreeView >
                                      {
                                          Object.keys(channelDetailsDB).map((key, index) => (
                                          <TreeItem itemId={transactionId+"_"+index+"_"+key} label={(<a href={`/monitoring/report/?api=${key}&transactionName=${transactionId}`} target="_blank" style={{textDecoration: 'none', wordWrap:'break-word', fontWeight: channelDetailsDB[key]['count'] > 20  ? 'bold': 'bold', color: channelDetailsDB[key]['count'] > 20 ? 'red': 'green'}}>{key+"  -  "+channelDetailsDB[key]['count'] > 20 ?channelDetailsDB[key]['count']:key+" ( "+channelDetailsDB[key]['count']+" ) "}</a>)}>
                                            {
                                              channelDetailsDB[key]['channel']?.map((key1, index1) => (
                                                <TreeItem itemId={transactionId+"_"+key+"_"+key1['channel']} label={key1['channel']+"  -  "+key1['count'] > 20 ? key1['count']:key1['channel']}
                                                ></TreeItem>
                                              ))
                                            }
                                          </TreeItem>
                                            ))
                                      }
                                                              
                                    </SimpleTreeView>:''
                                }
                              </div>
                            </div>
              </div>:''}
            </div>
    )
}

export default AnomalyDashborad;
