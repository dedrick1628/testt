import React, { useState, useEffect, useMemo, Suspense } from 'react';
import { useSearchParams } from 'react-router-dom'
import { TableCell, TableHead, TableRow,TableContainer } from '@mui/material';
import Paper from '@mui/material/Paper';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import axios from 'axios';
import '../App.css';
import { Loader } from '@vds/loaders';

const DBReport = (props) => {
    const [report, setReport] = useState({})
    const [loader, setLoader] = useState(false)
    const [searchParams, setSearchParams] = useSearchParams();
    const transactionname = searchParams.get('transactionName')
    const apiname = searchParams.get('api')
    const channel = searchParams.get('channel')
    let api_url = "http://localhost:8000/getdbreport"
    if (apiname) {
        api_url += "?transactionName="+transactionname+"&api="+ apiname
    } else {
        api_url += "?transactionName="+transactionname+"&api="+ apiname + "&channel="+channel 
    }
   
    useEffect(() => {
        setLoader(true)
        axios
        .get(api_url)
        .then((res) => {
          setReport(res.data)
          setLoader(false)
        })
          },[api_url]);
   
    
  return(
    <div>
    {loader ? <Loader fullscreen={true} active={true} surface='dark' />: ""}
     <TableContainer component={Paper}>
      <Table sx={{ minWidth: 650 }} aria-label="simple table">
        <TableHead>
          <TableRow>
            {
              report?.columns?.map((row,index) =>(
                <TableCell key={row+index}>{row}</TableCell>
              ))
            }
          </TableRow>
        </TableHead>
        { report?.data?.length > 0 ? <TableBody>
          {report?.data?.map((row,index) => (
            <TableRow
              key={index}
              sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
            >
             {row?.map((value,ind) =>
               <TableCell >{value}</TableCell>
            )}
            </TableRow>
          ))}
        </TableBody>:''}
        </Table>
        </TableContainer>
        { report?.data?.length == 0 && <div>There is no Anomaly / Spike</div>}
    </div>
  );
}

export default DBReport;
