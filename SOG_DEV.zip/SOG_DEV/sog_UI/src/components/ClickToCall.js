import React, { useState, useEffect, useMemo, Suspense } from 'react';


import '../App.css';
import Box from '@mui/material/Box';
import Paper from '@mui/material/Paper';
import { experimentalStyled as styled } from '@mui/material/styles';
import Grid from '@mui/material/Grid';
import Table from '@mui/material/Table';
import { TableCell, TableHead, TableRow,TableContainer } from '@mui/material';
import { makeStyles } from '@mui/styles';
import axios from 'axios';
import Accordion from '@mui/material/Accordion';
import AccordionActions from '@mui/material/AccordionActions';
import AccordionSummary from '@mui/material/AccordionSummary';
import AccordionDetails from '@mui/material/AccordionDetails';
import Typography from '@mui/material/Typography';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import Button from '@mui/material/Button';
import { Loader } from '@vds/loaders';

import TableBody from '@mui/material/TableBody';
import { BarChart } from '@mui/x-charts'

import Stepper from '@mui/material/Stepper';
import Step from '@mui/material/Step';
import StepLabel from '@mui/material/StepLabel';
import StepContent from '@mui/material/StepContent';







const ClickToCall = () => {
 const [simData, setsimData] = useState()
 const [clickTocall_data, setClickToCall]=useState()
 
const [loader, setLoader] = useState(false)
    console.log("asdsadasd111")
    useEffect(() => {
        setLoader(true)
    axios
      .post("http://localhost:8000/clickToCall")
      .then((res) => {
        setClickToCall(res.data);
        setLoader(false)
       console.log("resresresresres ===>", res)
      })
  },[])
  return(
    <div >
       
      <header className="header">
     
      </header><br></br>
      <main className="app">
      <div >
      {loader ? <Loader fullscreen={true} active={true} surface='dark' />: ""}
      
      {(clickTocall_data?.CALL_COUNTS) ? <div>   

        <BarChart
  series={[{ data: clickTocall_data?.CALL_COUNTS }]}
  xAxis={[{ scaleType: 'band', data: clickTocall_data?.CALL_REASON }]}
  height={600}
  width={700}
  leftAxis={null}
/>
<TableContainer component={Paper}>
      <Table sx={{ minWidth: 650 }} aria-label="simple table">
        <TableHead>
          <TableRow>
            <TableCell>CALL_REASON</TableCell>
            <TableCell align="center">COUNTS</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {clickTocall_data?.CALL_COUNTS?.map((row,index) => (
            <TableRow
              key={index}
              sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
            >
              
              <TableCell align="center">{row.call_reason}</TableCell>
              <TableCell align="center">{row.counts}</TableCell>
            </TableRow>
          ))}
        </TableBody>
        </Table>
        </TableContainer>
     
      
      </div> :""} 
    </div>
     
      </main>
    </div>
  );
}

export default ClickToCall;
