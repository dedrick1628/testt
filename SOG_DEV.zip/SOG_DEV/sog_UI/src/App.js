import React, { useState, useEffect, useMemo, Suspense } from 'react';
import logo from './logo.svg';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom'
import { AppProvider } from '@toolpad/core/AppProvider';
import './App.css';
import Box from '@mui/material/Box';
import Paper from '@mui/material/Paper';
import { experimentalStyled as styled } from '@mui/material/styles';
import Grid from '@mui/material/Grid';
import Table from '@mui/material/Table';
import { TableCell, TableHead, TableRow } from '@mui/material';
import { makeStyles } from '@mui/styles';
import axios from 'axios';
import Home from './components/Home';
import AnomalyDashborad from './components/AnomalyDashboard';

const userStyles = makeStyles({
  table: {
    backgroundColor: '#81c784',
  },
  thead: {
    backgroundColor: '#4caf50',
  }
});

const App = () => {
  localStorage.setItem('transactionId',1)
  const classes = userStyles();
  const [confData, setconfData] = useState({})
  const [isLoading, setisLoading] = useState(false)
  const authSession = sessionStorage.getItem('auth')
  let urlPath = window.location.pathname + window.location.search;

  if (!authSession && urlPath != '/' ) {

    document.location.href = '/'
  }
  
 
  const Item = styled(Paper)(({ theme }) => ({
    backgroundColor: '#fff',
    ...theme.typography.body2,
    padding: theme.spacing(2),
    textAlign: 'center',
    color: theme.palette.text.secondary,
    ...theme.applyStyles('dark', {
      backgroundColor: '#FFF',
    }),
  }));
  return(
    <div>
      
    <Router>
      <Routes>
        <Route exact path="/" element={<Home/>}/>
        {<Route exact path="/anomaly" element={<AnomalyDashborad/>}/>}
      </Routes>
    </Router>
 
  </div>
  );
}

export default App;

