from typing import Union
from fastapi.responses import StreamingResponse
from fastapi.responses import HTMLResponse
from fastapi import Request,FastAPI,Response,File,UploadFile
#from fastapi.response import JSONResponse
from starlette.responses import JSONResponse
import oracledb
import json
import urllib.parse
import os
from fastapi.middleware.cors import CORSMiddleware

from fastapi import FastAPI, Request
from starlette.responses import RedirectResponse

import io
import pandas as pd



import asyncio
import httpx
import io
from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from starlette.responses import StreamingResponse





server = FastAPI()

origins = ["*"]

oracledb.defaults.fetch_lobs = False

server.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
# db_jobs = JobScheduler()
# kibana_jobs = KibanaScheduler()
proxy = f'http://vzproxy.verizon.com:9290'
os.environ['http_proxy'] = '' 
os.environ['HTTP_PROXY'] = ''
os.environ['https_proxy'] = ''
os.environ['HTTPS_PROXY'] = ''

db_uname = "CXP_OPS_MONITORING"
db_pass = "QWEqwe##00"
db_host = "tpalpbrhvd00-scan.verizon.com"
db_port = 1532
db_service_name = "cxpopsmon_srv01"

db_dsn=oracledb.makedsn(host=db_host,port=db_port,service_name=db_service_name)
# db_connection=oracledb.connect(user=db_uname,password=db_pass,dsn=db_dsn)
# cursor = db_connection.cursor()

# Define connection pool parameters
pool_min = 2  # Minimum number of connections in the pool
pool_max = 50  # Maximum number of connections in the pool
pool_increment = 1  # Number of connections to add when needed

try:
    pool = oracledb.create_pool(
        user=db_uname,
        password=db_pass,
        dsn=db_dsn,
        min=pool_min,
        max=pool_max,
        increment=pool_increment
    )
    print("Connection pool created successfully.")

    # Acquire a connection from the pool
    connection = pool.acquire()
    print("Connection acquired from the pool.")

    # Perform database operations using the connection
    cursor = connection.cursor()
    

except oracledb.Error as error:
    print(f"Error creating or using connection pool: {error}")
#db_pool = oracledb.create_pool(user=db_uname,password=db_pass,dsn=f"{db_host}:{db_port}/{db_service_name}", min=1, max=5, increment=1)
    




@server.get("/getentitysteps2/{TRANSACTION_ID}/{ENTITY_NAME}")
def get_etitySteps2(TRANSACTION_ID: int, ENTITY_NAME: str):
    try:
        entity_step_list = []
        connection = pool.acquire()
        print("Connection acquired from the pool for entity details")

        # Perform database operations using the connection
        cursor = connection.cursor()
        sql_query = f"""
            select * from CXP_OPS_MONITORING.CXP_TRANSACTION_ENTITY_STEP_KIBANA_DEV WHERE transaction_id={TRANSACTION_ID} AND entity_name='{ENTITY_NAME}' AND BG_COLOR != 'grey'
        """
        
        cursor.execute(sql_query)
        rows = cursor.fetchall()
        print("SQL_query",sql_query)
        for sublist in rows:
            entity_step_obj={}
            entity_step_obj['ENTITY_STEP_NAME'] = sublist[1]
            entity_step_obj['TRANSACTION_NAME'] = sublist[4]
            entity_step_obj['BG_COLOR'] = sublist[9]
            entity_step_obj['TEXT_COLOR'] = sublist[10]
            entity_step_list.append(entity_step_obj)
        pool.release(connection)
        return entity_step_list
    except Exception as err:
        print("Error in ===>", err)

@server.post("/getchannel_db")
async def getchannel_db(request: Request):
    try:
        entity_step_list = []
        connection = pool.acquire()
        print("Connection acquired from the pool for entity details")
        payload_data = await request.json()
        sql_query = f"""
            select CHANNEL_NAME,
            CASE
                    when MAX(case when BG_COLOR = 'red' THEN 1
                    ELSE 0 END) = 1 THEN 'red'
                    ELSE 'green'
            END as bg_color
            from CXP_OPS_MONITORING.CXP_CHANNEL_ENTITY_STEP_DB_DEV  where TRANSACTION_ID = {payload_data['TRANSACTION_ID']} and ENTITY_NAME 
            in {tuple(payload_data['ENTITY_DETAILS'])} AND MEASURED_VALUE > 0 GROUP BY CHANNEL_NAME
        """
        print("sql_query ==>", sql_query)
        cursor.execute(sql_query)
        rows = cursor.fetchall()
        final_results = []
        for row in rows:
            channel_dict={}
            channel_dict[row[0]] = row[1]
            final_results.append(channel_dict)
                
        return final_results
        pool.release(connection)
        
    except Exception as err:
        print("Error in ===>", err)


@server.post("/getchannel2")
async def getchannel2(request: Request):
    try:
        entity_step_list = []
        connection = pool.acquire()
        print("Connection acquired from the pool for entity details")
        payload_data = await request.json()
        sql_query = f"""
            select CHANNEL_NAME,
            CASE
                    when MAX(case when BG_COLOR = 'red' THEN 1
                    ELSE 0 END) = 1 THEN 'red'
                    ELSE 'green'
            END as bg_color
            from CXP_OPS_MONITORING.CXP_CHANNEL_ENTITY_STEP_KIBANA_DEV  where TRANSACTION_ID = {payload_data['TRANSACTION_ID']} and ENTITY_NAME 
            in {tuple(payload_data['ENTITY_DETAILS'])} AND MEASURED_VALUE > 0 GROUP BY CHANNEL_NAME
        """
        print("sql_query ==>", sql_query)
        cursor.execute(sql_query)
        rows = cursor.fetchall()
        final_results = []
        for row in rows:
            channel_dict={}
            channel_dict[row[0]] = row[1]
            final_results.append(channel_dict)
                
        return final_results
        pool.release(connection)
        
    except Exception as err:
        print("Error in ===>", err)
        
@server.get("/getchannel1/{TRANSACTION_ID}")
def get_etitySteps1(TRANSACTION_ID: int):
    try:
        entity_step_list = []
        connection = pool.acquire()
        print("Connection acquired from the pool for entity details")

        # Perform database operations using the connection
        cursor = connection.cursor()
        sql_query = f"""
           select * from CXP_OPS_MONITORING.CXP_CHANNEL_ENTITY_STEP_KIBANA_DEV WHERE TRANSACTION_ID = {TRANSACTION_ID} AND MEASURED_VALUE > 0
        """
        
        cursor.execute(sql_query)
        rows = cursor.fetchall()
        print("SQL_query",sql_query)
        final_results = {}
        for sublist in rows:
            print()
            # channel_dict = {}
            # if sublist[0] in final_results: 
            #     final_results[sublist[0]].append(channel_dict)
            # else:
            #     final_results[sublist[0]] = []
            #     final_results[sublist[0]].append(channel_dict)
        pool.release(connection)
        return final_results
    except Exception as err:
        print("Error in ===>", err)


@server.get("/getentity_channel_DB/{TRANSACTION_ID}/{CHANNEL_NAME}")
def getentity_channel_DB(TRANSACTION_ID: int, CHANNEL_NAME: str):
    try:
        entity_step_list = []
        connection = pool.acquire()
        print("Connection acquired from the pool for entity details")

        # Perform database operations using the connection
        cursor = connection.cursor()
        sql_query = f"""
           select * from CXP_OPS_MONITORING.CXP_CHANNEL_ENTITY_STEP_DB_DEV where transaction_id={TRANSACTION_ID} and channel_name='{CHANNEL_NAME}'  AND MEASURED_VALUE > 0
        """
        print("SQL_query",sql_query)
        cursor.execute(sql_query)
        rows = cursor.fetchall()
        final_results = []
        for sublist in rows:
            channel_dict = {}
            channel_dict['ENTITY_API_NAME'] = sublist[1]
            channel_dict['ENTITY_API'] = sublist[2]
            channel_dict['MEASURED_VALUE'] = sublist[8]
            final_results.append(channel_dict)
        pool.release(connection)
        return final_results
    except Exception as ch_err:
        print("ENTITY_CHANNEL ERROR ==>", ch_err)

@server.get("/getentity_channel1/{TRANSACTION_ID}/{CHANNEL_NAME}")
def getentity_channel1(TRANSACTION_ID: int, CHANNEL_NAME: str):
    try:
        entity_step_list = []
        connection = pool.acquire()
        print("Connection acquired from the pool for entity details")

        # Perform database operations using the connection
        cursor = connection.cursor()
        sql_query = f"""
           select * from CXP_OPS_MONITORING.CXP_CHANNEL_ENTITY_STEP_KIBANA_DEV where transaction_id={TRANSACTION_ID} and channel_name='{CHANNEL_NAME}'  AND MEASURED_VALUE > 0
        """
        print("SQL_query",sql_query)
        cursor.execute(sql_query)
        rows = cursor.fetchall()
        final_results = []
        for sublist in rows:
            channel_dict = {}
            channel_dict['ENTITY_API_NAME'] = sublist[1]
            channel_dict['ENTITY_API'] = sublist[2]
            channel_dict['MEASURED_VALUE'] = sublist[8]
            final_results.append(channel_dict)
        pool.release(connection)
        return final_results
    except Exception as ch_err:
        print("ENTITY_CHANNEL ERROR ==>", ch_err)

@server.get("/getChannelDetails/{TRANSACTION_ID}/{ENTITY_NAME}")
def getChannelDetails(TRANSACTION_ID: int, ENTITY_NAME: str):
    try:
        
        entity_step_list = []
        connection = pool.acquire()
        print("Connection acquired from the pool for entity details")
        # Perform database operations using the connection
        cursor = connection.cursor()
        sql_query_db = f"""
           select ENTITY_API_NAME, CHANNEL_NAME, MEASURED_VALUE from CXP_OPS_MONITORING.CXP_CHANNEL_ENTITY_STEP_DB_DEV
           where transaction_id={TRANSACTION_ID} and entity_name='{ENTITY_NAME}' group by ENTITY_API_NAME, CHANNEL_NAME, MEASURED_VALUE
        """
        cursor.execute(sql_query_db)
        db_rows = cursor.fetchall()
        sql_query_kabana = f"""
            SELECT t1.ENTITY_API_NAME, t1.ENTITY_API,t1.CHANNEL_NAME, t1.MEASURED_VALUE, t2.FILTER FROM (
            SELECT ENTITY_API_NAME, ENTITY_API, CHANNEL_NAME, MEASURED_VALUE FROM CXP_OPS_MONITORING.CXP_CHANNEL_ENTITY_STEP_KIBANA_DEV WHERE transaction_id={TRANSACTION_ID} and entity_name='{ENTITY_NAME}'
            GROUP BY ENTITY_API_NAME, ENTITY_API, CHANNEL_NAME, MEASURED_VALUE
            ) t1
            JOIN CXP_OPS_MONITORING.CXP_CHANNEL_ENTITY_STEP_KIBANA_DEV t2 ON t1.ENTITY_API_NAME = t2.ENTITY_API_NAME AND t1.CHANNEL_NAME = t2.CHANNEL_NAME
            AND t1.MEASURED_VALUE = t2.MEASURED_VALUE
        """


        
        cursor.execute(sql_query_kabana)
        
        kibana_rows = cursor.fetchall()
        final_results = {}
        final_results_db = {} 
        final_results_kibana = {}
        final_results['ENTITY_NAME'] = ENTITY_NAME

        for sublist in kibana_rows:
            channel_count = {}
            channel_dict = {}
            filters_data = ''
            if sublist[4] is not None:
                filters = json.loads(sublist[4])
                if sublist[0] == 'Submit Activation (MLMO)':
                    print("Exception are 333333 ====>", len(filters[3]['values']))
                for filter in filters:
                    if filter['key'] == 'exception':
                        filters_data = f""" '{filter['key']}:"""
                        for index, exception in enumerate(filter['values']):
                            filters_data +=f""" "{exception}" """
                            if index < len(filter['values'])-1:
                                filters_data +=f"""OR exception:"""
                        filters_data = filters_data.strip()+"'"
            
            if sublist[0] in final_results_kibana:
                channel_dict['channel'] = sublist[2]
                channel_dict['count'] = sublist[3]
                channel_dict['filter'] = filters_data
                channel_dict['api_name'] = sublist[1]
                final_results_kibana[sublist[0]]['count'] = final_results_kibana[sublist[0]]['count']+sublist[3]
                final_results_kibana[sublist[0]]['channel'].append(channel_dict)
            else:
                channel_dict['channel'] = sublist[2]
                channel_dict['count'] = sublist[3]
                channel_dict['api_name'] = sublist[1]
                channel_dict['filter'] = filters_data
                final_results_kibana[sublist[0]] = {}
                final_results_kibana[sublist[0]]['channel'] = []
                final_results_kibana[sublist[0]]['count'] = sublist[3]
                final_results_kibana[sublist[0]]['filter'] = filters_data
                final_results_kibana[sublist[0]]['api_name'] = sublist[1]
                final_results_kibana[sublist[0]]['channel'].append(channel_dict)
        final_results['KIBANA'] = final_results_kibana

        for sublist in db_rows:
            channel_count = {}
            channel_dict = {}
            if sublist[0] in final_results_db:
                channel_dict['channel'] = sublist[1]
                channel_dict['count'] = sublist[2]
                final_results_db[sublist[0]]['count'] = final_results_db[sublist[0]]['count']+sublist[2]
                final_results_db[sublist[0]]['channel'].append(channel_dict)
            else:
                channel_dict['channel'] = sublist[1]
                channel_dict['count'] = sublist[2]
                final_results_db[sublist[0]] = {}
                final_results_db[sublist[0]]['channel'] = []
                final_results_db[sublist[0]]['count'] = sublist[2]
                final_results_db[sublist[0]]['channel'].append(channel_dict)
        final_results['DB'] = final_results_db
        return final_results
    except Exception as err:
        print("Error in111 ===>", err)

@server.get("/getentitysteps_DB/{TRANSACTION_ID}/{ENTITY_NAME}")
def get_etitySteps1(TRANSACTION_ID: int, ENTITY_NAME: str):
    try:
        entity_step_list = []
        connection = pool.acquire()
        print("Connection acquired from the pool for entity details")

        # Perform database operations using the connection
        cursor = connection.cursor()
        sql_query = f"""
           select ENTITY_API_NAME, CHANNEL_NAME, MEASURED_VALUE from CXP_OPS_MONITORING.CXP_CHANNEL_ENTITY_STEP_DB_DEV
           where transaction_id={TRANSACTION_ID} and entity_name='{ENTITY_NAME}' AND MEASURED_VALUE > 0 group by ENTITY_API_NAME, CHANNEL_NAME, MEASURED_VALUE
        """
        print("SQL_query",sql_query)
        cursor.execute(sql_query)
        rows = cursor.fetchall()
       
        final_results = {}
        for sublist in rows:
            channel_count = {}
            channel_dict = {}
            if sublist[0] in final_results:
                channel_dict['channel'] = sublist[1]
                channel_dict['count'] = sublist[2]
                final_results[sublist[0]]['count'] = final_results[sublist[0]]['count']+sublist[2]
                final_results[sublist[0]]['channel'].append(channel_dict)
            else:
                channel_dict['channel'] = sublist[1]
                channel_dict['count'] = sublist[2]
                final_results[sublist[0]] = {}
                final_results[sublist[0]]['channel'] = []
                final_results[sublist[0]]['count'] = sublist[2]
                final_results[sublist[0]]['channel'].append(channel_dict)
        pool.release(connection)
        return final_results
    except Exception as err:
        print("Error in111 ===>", err)
@server.get("/getentitysteps1/{TRANSACTION_ID}/{ENTITY_NAME}")
def get_etitySteps1(TRANSACTION_ID: int, ENTITY_NAME: str):
    try:
        entity_step_list = []
        connection = pool.acquire()
        print("Connection acquired from the pool for entity details")
        # Perform database operations using the connection
        cursor = connection.cursor()
        sql_query = f"""
           select ENTITY_API_NAME, CHANNEL_NAME, MEASURED_VALUE from CXP_OPS_MONITORING.CXP_CHANNEL_ENTITY_STEP_KIBANA_DEV
           where transaction_id={TRANSACTION_ID} and entity_name='{ENTITY_NAME}' AND MEASURED_VALUE > 0 group by ENTITY_API_NAME, CHANNEL_NAME, MEASURED_VALUE
        """
        # print("SQL_query",sql_query)
        cursor.execute(sql_query)
        rows = cursor.fetchall()
       
        final_results = {}
        
        for sublist in rows:
            channel_count = {}
            channel_dict = {}
            if sublist[0] in final_results:
                channel_dict['channel'] = sublist[1]
                channel_dict['count'] = sublist[2]
                final_results[sublist[0]]['count'] = final_results[sublist[0]]['count']+sublist[2]
                final_results[sublist[0]]['channel'].append(channel_dict)
            else:
                channel_dict['channel'] = sublist[1]
                channel_dict['count'] = sublist[2]
                final_results[sublist[0]] = {}
                final_results[sublist[0]]['channel'] = []
                final_results[sublist[0]]['count'] = sublist[2]
                final_results[sublist[0]]['channel'].append(channel_dict)
       
        pool.release(connection)
        return final_results
    except Exception as err:
        print("Error in111 ===>", err)
@server.get("/getdbreport/")
async def get_db_report(transactionName: int, api: str):
    try:
        connection = pool.acquire()
        # Perform database operations using the connection
        cursor = connection.cursor()
        condition=""
       
        final_results={}
        
        
       
        reportQuery=f"""
        select source,FILTER_QUERY,REPORT_QUERY from CXP_OPS_MONITORING.ENTITY_STEP_DB1 WHERE ENTITY_STEP_DISP_NAME='{api}' AND TRANSACTION_ID={transactionName}
        """
        cursor.execute(reportQuery)
        report_rows = cursor.fetchall()
        history_list = []
        
        if report_rows[0][0] == 'Audit':
            report_query = f"""
                select distinct OH.*,OS.clientid,CO.NSA_STACK_ID from POJO_DATA.VZCM_DATA_ORDERHISTORY OH
                JOIN POJO_DATA.VZCM_DATA_ORDERSTATUS OS ON OH.CARTID=OS.CARTID AND OS.ENTITY=OH.ENTITY AND OS.CREATEDATETIME >= SYSTIMESTAMP AT TIME ZONE 'PST' - (1/24) AND OS.ENTITYSTEPSTATUS='Failed'
                JOIN VIP_POSDB.CART_ORDER CO ON OH.CARTID=CO.CART_ID AND VZWDB_CREATE_TIMESTAMP >= SYSTIMESTAMP-(1/24)
                where OH.CREATEDATETIME >= SYSTIMESTAMP AT TIME ZONE 'PST' - (1/24) AND OH.ENTITYSTEPSTATUS='Failed' AND OH.ENTITYSTEP = '{api}'
            """
            cursor.execute(report_query)
            audit_rows = cursor.fetchall()
            
            col_names = [row[0] for row in cursor.description]
            final_results['columns'] = col_names
            for row in audit_rows:
                if report_rows[0][1] is not None:
                    exceptions = json.loads(report_rows[0][1])
                    for exception in exceptions:
                        if exception in row[10]:
                            history_list.append(row)
                            break
                else:
                    history_list.append(row)
            final_results['data'] = history_list
        else:
            report_query = report_rows[0][2]
            cursor.execute(report_query)
            audit_rows = cursor.fetchall()
            col_names = [row[0] for row in cursor.description]
            final_results['columns'] = col_names
            for row in audit_rows:
                history_list.append(row)
            final_results['data'] = history_list
            
        return final_results
    except Exception as err:
        print("Exception in getdbreport  ===>", err)
@server.get("/getentitysteps/{TRANSACTION_NAME}/{ENTITY_NAME}")
def get_etitySteps(TRANSACTION_NAME: str, ENTITY_NAME: str):
    try:
        entity_step_list = []
        connection = pool.acquire()
        print("Connection acquired from the pool for entity details")

        # Perform database operations using the connection
        cursor = connection.cursor()
        sql_query = f"""
            select * from CXP_OPS_MONITORING.TRANSACTION_ENTITY_STEP_TEMP WHERE transaction_name='{TRANSACTION_NAME}' AND entity_name='{ENTITY_NAME}' AND BG_COLOR != 'grey'
        """
        
        cursor.execute(sql_query)
        rows = cursor.fetchall()
        print("SQL_query",sql_query)
        for sublist in rows:
            entity_step_obj={}
            entity_step_obj['ENTITY_STEP_NAME'] = sublist[0]
            entity_step_obj['TRANSACTION_NAME'] = sublist[2]
            entity_step_obj['BG_COLOR'] = sublist[5]
            entity_step_obj['TEXT_COLOR'] = sublist[6]
            entity_step_list.append(entity_step_obj)
        pool.release(connection)
        return entity_step_list
    except Exception as err:
        print("Error in ===>", err)

# @server.get("/getentities/{TRANSACTION_ID}")
# def get_transaction(TRANSACTION_ID: int):
    
#     try:
#         entity_list = []
#         connection = pool.acquire()
#         print("Connection acquired from the pool for entity")

#         # Perform database operations using the connection
#         cursor = connection.cursor()
#         sql_query = f"""
#             SELECT e.ENTITY_ID,e.ENTITY_NAME, e.TRANSACTION_NAME,
#             COALESCE(et.BG_COLOR, 'gray') as BG_COLOR
#             FROM CXP_OPS_MONITORING.ENTITY_TEMP e
#             LEFT JOIN (
#             SELECT ENTITY_NAME, TRANSACTION_NAME, BG_COLOR,
#             ROW_NUMBER() OVER (PARTITION BY ENTITY_NAME, TRANSACTION_NAME ORDER BY CASE BG_COLOR
#             WHEN 'red' THEN 1
#             WHEN 'green' THEN 2
#             ELSE 3 END) as color_rank FROM CXP_OPS_MONITORING.TRANSACTION_ENTITY_STEP_TEMP
#             ) et ON e.ENTITY_NAME = et.ENTITY_NAME
#             AND e.TRANSACTION_NAME = et.TRANSACTION_NAME
#             AND et.color_rank = 1 WHERE e.TRANSACTION_ID = '{TRANSACTION_ID}'
#             ORDER BY e.ENTITY_ID
#         """
        
#         cursor.execute(sql_query)
#         rows = cursor.fetchall()
#         print("SQL_query",sql_query)
#         for sublist in rows:
#             entity_obj={}
            
#             entity_obj['ENTITY_ID'] = sublist[0]
#             entity_obj['ENTITY_NAME'] = sublist[1]
#             entity_obj['TRANSACTION_NAME'] = sublist[2]
#             entity_obj['ENTITY_BGCOLOR'] = sublist[3]
#             entity_obj['TRANSACTION_ID'] = TRANSACTION_ID
#             entity_obj['ENTITY_TEXTCOLOR'] = 'white'
#             entity_list.append(entity_obj)
#         pool.release(connection)
#         return entity_list
#     except Exception as err:
#         print("Error in ===>", err)


@server.get("/gettransaction_db")
def get_transaction_db():
       
        transaction_list = []
        try:
            connection = pool.acquire()
            print("Connection acquired from the pool.")

            # Perform database operations using the connection
            cursor = connection.cursor()
            sql_query = """
                SELECT t1.TRANSACTION_ID, t1.TRANSACTION_NAME,
                    CASE
                        when MAX(t2.BG_COLOR) = 'red' THEN 'red'
                        WHEN MAX(t2.BG_COLOR) = 'green' THEN 'green'
                        ELSE 'grey'
                    END as bg_color,
                    CASE
                        when MAX(t2.BG_COLOR) = 'red' THEN 'white'
                        WHEN MAX(t2.BG_COLOR) = 'green' THEN 'white'
                        ELSE 'black'
                    END as bg_color1
                FROM CXP_OPS_MONITORING.TRANSACTION_TEMP1 t1
                LEFT JOIN CXP_OPS_MONITORING.CXP_TRANSATION_ENTITY_STEP_DB_DEV t2 ON t1.TRANSACTION_NAME = t2.TRANSACTION_NAME AND t2.MEASURED_VALUE > 0 
                GROUP BY t1.TRANSACTION_NAME,t1.TRANSACTION_ID
                ORDER BY t1.TRANSACTION_ID asc
            """
            cursor.execute(sql_query)
            rows = cursor.fetchall()
           
            for row in rows:
                transaction_obj={}
                transaction_obj['TRANSACTION_ID'] = row[0]
                transaction_obj['TRANSACTION_NAME'] = row[1]
                transaction_obj['BG_COLOR'] = row[2]
                transaction_obj['TEXT_COLOR'] = row[3]
                print("rowrowrowrowrow ==>", row)
            #     # alert_obj['measured-value'] = sublist[5]
                transaction_list.append(transaction_obj)
            
        except Exception as er1:
            print("Exception is ===>", er1)
            pool.release(connection)
        
        print("DDDDD ==>", transaction_list)
        return transaction_list

@server.get("/gettransaction")
def get_transaction():
       
        transaction_list = []
        try:
            connection = pool.acquire()
            print("Connection acquired from the pool.")

            # Perform database operations using the connection
            cursor = connection.cursor()
            sql_query = """
                SELECT t1.TRANSACTION_ID, t1.TRANSACTION_NAME,
                    CASE
                        when MAX(t2.BG_COLOR) = 'red' OR MAX(t3.BG_COLOR) = 'red' THEN 'red'
                        WHEN MAX(t2.BG_COLOR) = 'green' OR MAX(t3.BG_COLOR) = 'green' THEN 'green'
                        ELSE 'grey'
                    END as bg_color,
                    CASE
                       when MAX(t2.BG_COLOR) = 'red' OR MAX(t3.BG_COLOR) = 'red' THEN 'white'
                       WHEN MAX(t2.BG_COLOR) = 'green' OR MAX(t3.BG_COLOR) = 'green' THEN 'white'
                       ELSE 'black'
                    END as bg_color1
                FROM CXP_OPS_MONITORING.TRANSACTION_TEMP1 t1
                LEFT JOIN CXP_OPS_MONITORING.CXP_TRANSACTION_ENTITY_STEP_KIBANA_DEV t2 ON t1.TRANSACTION_NAME = t2.TRANSACTION_NAME
                LEFT JOIN CXP_OPS_MONITORING.CXP_TRANSATION_ENTITY_STEP_DB_DEV t3 ON t1.TRANSACTION_NAME = t3.TRANSACTION_NAME 
                GROUP BY t1.TRANSACTION_NAME,t1.TRANSACTION_ID
                ORDER BY t1.TRANSACTION_ID asc
            """
            cursor.execute(sql_query)
            rows = cursor.fetchall()
           
            for row in rows:
                transaction_obj={}
                transaction_obj['TRANSACTION_ID'] = row[0]
                transaction_obj['TRANSACTION_NAME'] = row[1]
                transaction_obj['BG_COLOR'] = row[2]
                transaction_obj['TEXT_COLOR'] = row[3]
                print("rowrowrowrowrow ==>", row)
            #     # alert_obj['measured-value'] = sublist[5]
                transaction_list.append(transaction_obj)
            
        except Exception as er1:
            print("Exception is ===>", er1)
            pool.release(connection)
        
        print("DDDDD ==>", transaction_list)
        return transaction_list


@server.get("/getentities_db/{TRANSACTION_ID}")
def get_entities_db(TRANSACTION_ID: int):
    
    try:
        entity_list = []
        connection = pool.acquire()
        print("Connection acquired from the pool for entity")

        # Perform database operations using the connection
        cursor = connection.cursor()
        sql_query = f"""
            SELECT t1.ENTITY_ID, t1.ENTITY_NAME, t1.TRANSACTION_ID, 
                CASE
                    when MAX(t2.BG_COLOR) = 'red' THEN 'red'
                    WHEN MAX(t2.BG_COLOR) = 'green' THEN 'green'
                    ELSE 'grey'
                END as bg_color,
                CASE
                    when MAX(t2.BG_COLOR) = 'red' THEN 'white'
                    WHEN MAX(t2.BG_COLOR) = 'green' THEN 'white'
                    ELSE 'black'
                END as bg_color1
            FROM CXP_OPS_MONITORING.ENTITY_TEMP1 t1
            LEFT JOIN CXP_OPS_MONITORING.CXP_TRANSATION_ENTITY_STEP_DB_DEV t2 ON t1.ENTITY_ID = t2.ENTITY_ID AND t2.MEASURED_VALUE > 0 
            where t1.TRANSACTION_ID = {TRANSACTION_ID}
            GROUP BY t1.ENTITY_NAME,t1.TRANSACTION_ID, t1.ENTITY_ID
            ORDER BY t1.ENTITY_ID
        """
        
        cursor.execute(sql_query)
        rows = cursor.fetchall()
        print("SQL_query",sql_query)
        for sublist in rows:
            entity_obj={}
            entity_obj['ENTITY_ID'] = sublist[0]
            entity_obj['ENTITY_NAME'] = sublist[1]
            entity_obj['TRANSACTION_ID'] = sublist[2]
            entity_obj['BG_COLOR'] = sublist[3]
            entity_obj['TEXT_COLOR'] = sublist[4]
            entity_list.append(entity_obj)
        pool.release(connection)
        return entity_list
    except Exception as err:
        print("Error in ===>", err)

@server.get('/gettransactions')
def gettransactions():
    temp_list = ["Retry", "Click to Call", "Loan Failure /Pending","Sim change","Edge Up","PortIn","Accessory","past fulfillment orders","Shell accounts","Indirect RCOD","Pending order","Rebate","Unexpected return"]

    result_dict={}
    try:
        connection = pool.acquire()
        try:
            
            cursor = connection.cursor()
            sql_query = """
                    SELECT t1.position, t1.ENTITY_ID, t1.ENTITY_NAME, t1.TRANSACTION_ID, t1.TRANSACTION_NAME,
                    CASE
                        WHEN MAX(t2.BG_COLOR) = 'yellow' OR MAX(t3.BG_COLOR) = 'yellow' THEN 'yellow'
                        WHEN MAX(t2.BG_COLOR) = 'red' OR MAX(t3.BG_COLOR) = 'red' THEN 'red'
                        WHEN MAX(t2.BG_COLOR) = 'green' OR MAX(t3.BG_COLOR) = 'green' THEN 'green'
                    
                        ELSE 'grey'
                    END as bg_color,
                    CASE
                        WHEN MAX(t2.BG_COLOR) = 'yellow' OR MAX(t3.BG_COLOR) = 'yellow' THEN 'black'
                        WHEN MAX(t2.BG_COLOR) = 'red' OR MAX(t3.BG_COLOR) = 'red' THEN 'white'
                        WHEN MAX(t2.BG_COLOR) = 'green' OR MAX(t3.BG_COLOR) = 'green' THEN 'white'
                        
                        ELSE 'black'
                    END as txt_color
                FROM CXP_OPS_MONITORING.ENTITY_TEMP1 t1
                LEFT JOIN CXP_OPS_MONITORING.CXP_TRANSACTION_ENTITY_STEP_KIBANA_DEV t2 ON t1.ENTITY_ID = t2.ENTITY_ID
                LEFT JOIN CXP_OPS_MONITORING.CXP_TRANSATION_ENTITY_STEP_DB_DEV t3 ON t1.ENTITY_ID = t3.ENTITY_ID
                GROUP BY t1.ENTITY_NAME,t1.TRANSACTION_ID, t1.ENTITY_ID, t1.position,t1.TRANSACTION_NAME
                ORDER BY t1.position
            """
            cursor.execute(sql_query)
            entity_details = cursor.fetchall()
            for entity in entity_details:
                if entity[5] != 'grey':
                    entity_obj={}
                    entity_obj['ENTITY_ID'] = entity[1]
                    entity_obj['ENTITY_NAME'] = entity[2]
                    entity_obj['TRANSACTION_ID'] = entity[3]
                    entity_obj['BG_COLOR'] = entity[5]
                    entity_obj['TEXT_COLOR'] = entity[6]
                    if entity[3] not in result_dict:
                        result_dict[entity[3]] = {
                            "ENTITY_DETAILS" : [],
                            "TRANSACTION_NAME" : entity[4],
                            "TRANSACTION_BG_COLOR": 'green',
                            "TRANSACTION_TXT_COLOR": 'white'
                        }
                        result_dict[entity[3]]['ENTITY_DETAILS'].append(entity_obj)
                    else:
                        result_dict[entity[3]]['ENTITY_DETAILS'].append(entity_obj)
                    if entity[5] == 'red':
                        result_dict[entity[3]]['TRANSACTION_BG_COLOR'] = 'red'
                        result_dict[entity[3]]['TRANSACTION_TXT_COLOR'] = 'white'
            for item in temp_list:
                value = {
                "ENTITY_ID": 36,
                "ENTITY_NAME": item,
                "TRANSACTION_ID": 2,
                "BG_COLOR": "green",
                "TEXT_COLOR": "white"
                }
                result_dict[1]["ENTITY_DETAILS"].append(value)
        except Exception as err:
            print("Exception in gettransactions() :", str(err))
    finally:
        pool.release(connection)
    return result_dict
@server.get("/getentities/{TRANSACTION_ID}")
def get_entities1(TRANSACTION_ID: int):
    
    try:
        entity_list = []
        connection = pool.acquire()
        print("Connection acquired from the pool for entity")

        # Perform database operations using the connection
        cursor = connection.cursor()
        sql_query = f"""
             SELECT t1.position, t1.ENTITY_ID, t1.ENTITY_NAME, t1.TRANSACTION_ID, 
                CASE
                    when MAX(t2.BG_COLOR) = 'red' OR MAX(t3.BG_COLOR) = 'red' THEN 'red'
                    WHEN MAX(t2.BG_COLOR) = 'green' OR MAX(t3.BG_COLOR) = 'green' THEN 'green'
                    ELSE 'grey'
                END as bg_color,
                CASE
                    when MAX(t2.BG_COLOR) = 'red' OR MAX(t3.BG_COLOR) = 'red' THEN 'white'
                    WHEN MAX(t2.BG_COLOR) = 'green' OR MAX(t3.BG_COLOR) = 'green' THEN 'white'
                    ELSE 'black'
                END as bg_color1
            FROM CXP_OPS_MONITORING.ENTITY_TEMP1 t1
            LEFT JOIN CXP_OPS_MONITORING.CXP_TRANSACTION_ENTITY_STEP_KIBANA_DEV t2 ON t1.ENTITY_ID = t2.ENTITY_ID
            LEFT JOIN CXP_OPS_MONITORING.CXP_TRANSATION_ENTITY_STEP_DB_DEV t3 ON t1.ENTITY_ID = t3.ENTITY_ID
            where t1.TRANSACTION_ID = {TRANSACTION_ID}
            GROUP BY t1.ENTITY_NAME,t1.TRANSACTION_ID, t1.ENTITY_ID, t1.position
            ORDER BY t1.position
        """
        
        cursor.execute(sql_query)
        rows = cursor.fetchall()
        print("SQL_query",sql_query)
        for sublist in rows:
            entity_obj={}
            entity_obj['ENTITY_ID'] = sublist[1]
            entity_obj['ENTITY_NAME'] = sublist[2]
            entity_obj['TRANSACTION_ID'] = sublist[3]
            entity_obj['BG_COLOR'] = sublist[4]
            entity_obj['TEXT_COLOR'] = sublist[5]
            entity_list.append(entity_obj)
        pool.release(connection)
        return entity_list
    except Exception as err:
        print("Error in ===>", err)


@server.get("/channels")
def get_channels():
    
    try:
        channel_list = []
        connection = pool.acquire()
        print("Connection acquired from the pool for entity")

        # Perform database operations using the connection
        cursor = connection.cursor()
        sql_query = f"""
            SELECT t1.CHANNEL_NAME,
                CASE
                    when MAX(t1.BG_COLOR) = 'red' THEN 'red'
                    WHEN MAX(t1.BG_COLOR) = 'green' THEN 'green'
                    ELSE 'grey'
                END as bg_color,
                CASE
                    when MAX(t1.BG_COLOR) = 'red' THEN 'white'
                    WHEN MAX(t1.BG_COLOR) = 'green' THEN 'white'
                    ELSE 'black'
                END as bg_color1
            FROM CXP_OPS_MONITORING.CXP_CHANNEL_ENTITY_STEP_KIBANA_DEV t1
            GROUP BY t1.CHANNEL_NAME
            ORDER BY t1.CHANNEL_NAME asc
        """
        
        cursor.execute(sql_query)
        rows = cursor.fetchall()
        print("SQL_query",sql_query)
        for sublist in rows:
            channel_obj={}
            channel_obj['CHANNEL_NAME'] = sublist[0]
            channel_obj['BG_COLOR'] = sublist[1]
            channel_obj['TEXT_COLOR'] = sublist[2]
            channel_list.append(channel_obj)
        pool.release(connection)
        return channel_list
    except Exception as err:
        print("Error in ===>", err)
# @server.get("/gettransaction")
# def get_transaction():
       
#         category = []
#         try:
#             connection = pool.acquire()
#             print("Connection acquired from the pool.")

#             # Perform database operations using the connection
#             cursor = connection.cursor()
#             sql_query = """
#                 SELECT t1.TRANSACTION_ID, t1.TRANSACTION_NAME,
#                 CASE
#                     when MAX(t2.BG_COLOR) = 'red' THEN 'red,white'
#                     WHEN MAX(t2.BG_COLOR) = 'green' THEN 'green,white'
#                     ELSE 'grey,white'
#                 END as bg_color
#                 FROM CXP_OPS_MONITORING.TRANSACTION_TEMP t1
#                 LEFT JOIN TRANSACTION_ENTITY_STEP_TEMP t2 ON t1.TRANSACTION_NAME = t2.TRANSACTION_NAME
#                 GROUP BY t1.TRANSACTION_NAME,t1.TRANSACTION_ID
#                 ORDER BY t1.TRANSACTION_ID asc
#             """
#             cursor.execute(sql_query)
#             rows = cursor.fetchall()
           
#             for sublist in rows:
#                 transaction_obj={}
#                 transaction_obj['TRANSACTION_ID'] = sublist[0]
#                 transaction_obj['TRANSACTION_NAME'] = sublist[1]
#                 color_text = sublist[2].split(",")
#                 transaction_obj['TRANSACTION_BGCOLOR'] = color_text[0]
#                 transaction_obj['TRANSACTION_TEXTCOLOR'] = color_text[1]
#             #     # alert_obj['measured-value'] = sublist[5]
#                 category.append(transaction_obj)
#         except Exception as er1:
#             print("Exception is ===>", er1)
#         pool.release(connection)
#         return category
   


# @server.get("/start_db_jobs")
# def start_db_jobs():
    
#     print("hello")
#     db_jobs.start_db_jobs()
# @server.get("/stop_db_jobs")
# def stop_db_jobs():
    
#     db_jobs.stop_db_jobs()
# @server.get("/start_kibana_jobs")
# def start_kibana_jobs():
#     kibana_jobs = KibanaScheduler()
#     kibana_jobs.start_jobs()
# @server.get("/stop_kibana_jobs")
# def stop_kibana_jobs():
#     kibana_jobs = KibanaScheduler()
#     kibana_jobs.stop_jobs()

    