#!/usr/bin/env python3
"""
Kibana Scheduler - Refactored from KibanaScheduler.py

A production-ready, modular Kibana monitoring and alerting system with enhanced
error handling, configuration management, and performance optimization.

This is a complete refactoring of the original KibanaScheduler.py file to follow
modern Python best practices and standards.

Author: SOG Team
Version: 2.0.0
"""

import asyncio
import math
import oracledb
import json
import time
import threading
import requests
from urllib3.util import Retry
from requests.adapters import HTTPAdapter
import schedule
import concurrent.futures
from datetime import datetime
from typing import Dict, List, Optional, Tuple, Any, Union
import subprocess
import logging
class KibanaScheduler:
    def __init__(self):
        print("Kibana job started")
        self.count = 0
        self.task = 0
        self.channel_list=[]
        self.entity_list=[]
        self.total_tasks = 0
        self.completed_tasks = 0
        self.db_schedule = schedule
        # Default Channels Configuration
        self.DEFAULT_CHANNELS = [
            {'CHANNEL_NAME': 'CHAT-STORE', 'THRESHOLD_VALUE': 25},
            {'CHANNEL_NAME': 'VZW-MFA', 'THRESHOLD_VALUE': 25},
            {'CHANNEL_NAME': 'VZW-DOTCOM', 'THRESHOLD_VALUE': 25},
            {'CHANNEL_NAME': 'OMNI-CARE', 'THRESHOLD_VALUE': 25},
            {'CHANNEL_NAME': 'OMNI-INDIRECT', 'THRESHOLD_VALUE': 25},
            {'CHANNEL_NAME': 'OMNI-TELESALES', 'THRESHOLD_VALUE': 25},
            {'CHANNEL_NAME': 'OMNI-RETAIL', 'THRESHOLD_VALUE': 25},
            {'CHANNEL_NAME': 'OMNI-B2B', 'THRESHOLD_VALUE': 25},
            {'CHANNEL_NAME': 'OMNI-D2D', 'THRESHOLD_VALUE': 25},
            {'CHANNEL_NAME': 'VZW-ACSS', 'THRESHOLD_VALUE': 25},
            {'CHANNEL_NAME': 'VZW-NR', 'THRESHOLD_VALUE': 25},
            {'CHANNEL_NAME': 'VZW-TS', 'THRESHOLD_VALUE': 25}
        ]
        self.worker_pool_size=200
        self.session = requests.Session()
        self.adapter = HTTPAdapter(max_retries=Retry(total=3, backoff_factor=0.1),pool_connections=self.worker_pool_size,pool_maxsize=self.worker_pool_size)
        self.session.mount("https://", self.adapter)
        self.semaphore = threading.Semaphore(self.worker_pool_size)
        self.headers = {"Accept": "application/json", "Content-Type": "application/json",
                        "Authorization": "ApiKey LXhDeHVKTUJkU0tHbklldWJoMjg6UUw0MHR3OTZSSkN2bGwzeVVoajVIQQ=="}
        self.pega_url = "https://peganextgen-es.verizon.com/onevz_pega_rules_pal_cjcm*/_search?size=2000"
        db_uname = "CXP_OPS_MONITORING"
        db_pass = "QWEqwe##00"
        db_host = "tpalpbrhvd00-scan.verizon.com"
        db_port = 1532
        db_service_name = "cxpopsmon_srv01"
        self.scheduler_thread = None
        self.process_data_dict = {}
        self.task_lock = threading.Lock()
        self.logger = logging.getLogger(__name__)
        try:
            output = subprocess.check_output(['pgrep', '-f', "KibanaScheduler4.py"])
            pids = output.decode().strip().split('\n')
            for pid in pids:
                subprocess.run(["kill", pid])
        except subprocess.CalledProcessError:
            pass
        try:
            db_dsn=oracledb.makedsn(host=db_host,port=db_port,service_name=db_service_name)
            self.pool = oracledb.create_pool(
                user=db_uname,
                password=db_pass,
                dsn=db_dsn,
                min=2,
                max=200,
                increment=1
            )
            print("Connection pool created successfully.")

            # Acquire a connection from the pool
            self.connection = self.pool.acquire()
            print("Connection acquired from the pool.")

            # Perform database operations using the connection
            #self.cursor = connection.cursor()
        except oracledb.Error as error:
            print(f"Error creating or using connection pool: {error}")
        connection = self.pool.acquire()
        
        try:
            cursor = connection.cursor()
            sql_query = """
                select t1.transaction_name,t2.* from CXP_OPS_MONITORING.TRANSACTION_TEMP1 t1
                JOIN CXP_OPS_MONITORING.ENTITY_STEP_TEMP1 t2 on t1.transaction_name = t2.transaction_name
                order by t2.TRANSACTION_NAME asc
            """
            
            cursor.execute(sql_query)
            results = cursor.fetchall()
            
            for row in results:
                if row[0] in self.process_data_dict:
                    self.process_data_dict[row[0]]['API_DETAILS'].append(row[3])
                    self.process_data_dict[row[0]]['ENTITY_DETAILS'].append(row)
                else:
                    self.process_data_dict[row[0]] = {}
                    self.process_data_dict[row[0]]['API_DETAILS'] = [row[3]]
                    self.process_data_dict[row[0]]['ENTITY_DETAILS'] = [row]
            
            self.jobs = self.run_scheduler()
            
            self.start_db_jobs()
        except Exception as err:
            self.pool.release(connection)
            print("Table Error :", str(err))
    def db_operations(self,channels,entities):
        try:
            conn = self.pool.acquire()
            cursor = conn.cursor()
            if not channels:
                return
            
            merge_sql_channel = """
            MERGE INTO CXP_OPS_MONITORING.CXP_CHANNEL_ENTITY_STEP_KIBANA_DEV target
            USING (
                SELECT :CHANNEL_NAME as CHANNEL_NAME,
                    :ENTITY_API_NAME as ENTITY_API_NAME,
                    :ENTITY_API as ENTITY_API,
                    :ENTITY_NAME as ENTITY_NAME,
                    :ENTITY_ID as ENTITY_ID,
                    :TRANSACTION_ID as TRANSACTION_ID,
                    :TRANSACTION_NAME as TRANSACTION_NAME,
                    :THRESHOLD_VALUE as THRESHOLD_VALUE,
                    :MEASURED_VALUE as MEASURED_VALUE,
                    :BG_COLOR as BG_COLOR,
                    :TEXT_COLOR as TEXT_COLOR,
                    :FILTER as FILTER
                FROM dual
            ) source
            ON (target.CHANNEL_NAME = source.CHANNEL_NAME 
                AND target.ENTITY_API_NAME = source.ENTITY_API_NAME 
                AND target.ENTITY_ID = source.ENTITY_ID 
                AND target.TRANSACTION_ID = source.TRANSACTION_ID)
            WHEN MATCHED THEN
                UPDATE SET 
                    target.MEASURED_VALUE = source.MEASURED_VALUE,
                    target.BG_COLOR = source.BG_COLOR,
                    target.TEXT_COLOR = source.TEXT_COLOR,
                    target.FILTER = source.FILTER
            WHEN NOT MATCHED THEN
                INSERT (CHANNEL_NAME, ENTITY_API_NAME, ENTITY_API, ENTITY_NAME, 
                    ENTITY_ID, TRANSACTION_ID, TRANSACTION_NAME, THRESHOLD_VALUE,
                    MEASURED_VALUE, BG_COLOR, TEXT_COLOR, FILTER)
                VALUES (source.CHANNEL_NAME, source.ENTITY_API_NAME, source.ENTITY_API,
                    source.ENTITY_NAME, source.ENTITY_ID, source.TRANSACTION_ID,
                    source.TRANSACTION_NAME, source.THRESHOLD_VALUE, source.MEASURED_VALUE,
                    source.BG_COLOR, source.TEXT_COLOR, source.FILTER)
            """
            
            try:
                cursor.executemany(merge_sql_channel, channels)
                conn.commit()
                self.logger.debug(f"Upserted {len(channels)} channel records")
            except oracledb.Error as e:
                self.logger.error(f"Error upserting channel data: {e}")
                raise
            
            
            if not entities:
                return
            
            merge_sql_entities = """
            MERGE INTO CXP_OPS_MONITORING.CXP_TRANSACTION_ENTITY_STEP_KIBANA_DEV target
            USING (
                SELECT :ENTITY_STEP_ID as ENTITY_STEP_ID,
                    :ENTITY_STEP_NAME as ENTITY_STEP_NAME,
                    :ENTITY_STEP_API_NAME as ENTITY_STEP_API_NAME,
                    :TRANSACTION_ID as TRANSACTION_ID,
                    :TRANSACTION_NAME as TRANSACTION_NAME,
                    :ENTITY_ID as ENTITY_ID,
                    :ENTITY_NAME as ENTITY_NAME,
                    :THRESHOLD_VALUE as THRESHOLD_VALUE,
                    :MEASURED_VALUE as MEASURED_VALUE,
                    :BG_COLOR as BG_COLOR,
                    :TEXT_COLOR as TEXT_COLOR,
                    :IS_ACTIVE as IS_ACTIVE
                FROM dual
            ) source
            ON (target.ENTITY_STEP_ID = source.ENTITY_STEP_ID 
                AND target.TRANSACTION_ID = source.TRANSACTION_ID 
                AND target.ENTITY_ID = source.ENTITY_ID)
            WHEN MATCHED THEN
                UPDATE SET 
                    target.MEASURED_VALUE = source.MEASURED_VALUE,
                    target.BG_COLOR = source.BG_COLOR,
                    target.TEXT_COLOR = source.TEXT_COLOR,
                    target.IS_ACTIVE = source.IS_ACTIVE
            WHEN NOT MATCHED THEN
                INSERT (ENTITY_STEP_ID, ENTITY_STEP_NAME, ENTITY_STEP_API_NAME,
                    TRANSACTION_ID, TRANSACTION_NAME, ENTITY_ID, ENTITY_NAME,
                    THRESHOLD_VALUE, MEASURED_VALUE, BG_COLOR, TEXT_COLOR,
                    IS_ACTIVE)
                VALUES (source.ENTITY_STEP_ID, source.ENTITY_STEP_NAME, source.ENTITY_STEP_API_NAME,
                    source.TRANSACTION_ID, source.TRANSACTION_NAME, source.ENTITY_ID,
                    source.ENTITY_NAME, source.THRESHOLD_VALUE, source.MEASURED_VALUE,
                    source.BG_COLOR, source.TEXT_COLOR, source.IS_ACTIVE)
            """
            
            try:
                cursor.executemany(merge_sql_entities, entities)
                conn.commit()
                self.logger.debug(f"Upserted {len(entities)} entity records")
            except oracledb.Error as e:
                self.logger.error(f"Error upserting entity data: {e}")
                raise
        finally:
            if conn:
                self.pool.release(conn)
    
    def execute_query(self,api_names,transaction,entity_details):
        if entity_details[10] is not None:
            try:
                entity_dict={}
                self.task = self.task +1
                payload_dict={"sort":[{"@timestamp":{"order":"desc","format":"strict_date_optional_time","unmapped_type":"boolean"}},{"_doc":{"order":"desc","unmapped_type":"boolean"}}],"stored_fields":["*"],"track_total_hits":"false","size":99,"fields":[{"field":"*","include_unmapped":"true"},{"field":"@timestamp","format":'strict_date_optional_time'}],"version":"true","_source":"false","runtime_mappings":{},"script_fields":{},"highlight":{"pre_tags":["@kibana-highlighted-field@"],"post_tags":["@/kibana-highlighted-field@"],"fields":{"*":{}}},"query":{"bool":{"filter":[{"range":{"@timestamp":{"format":"strict_date_optional_time","gte":"now-1h","lte":"now"}}}],"must_not":[]}}}
                if entity_details[12] is not None:
                    filters = json.loads(entity_details[12].read())
                    for filter in filters:
                        must_not={}
                        if filter['condition'] == 'is not':
                            must_not['match_phrase']={}
                            must_not['match_phrase'][filter['key']] = filter['values']
                            payload_dict['query']['bool']['must_not'].append(must_not)
                        elif filter['condition'] == 'is':
                            if isinstance(filter['values'], list):
                                bool_dict = {
                                        "bool": {
                                            "should": [],
                                            "minimum_should_match": 1
                                        }
                                    }
                                for doc in filter['values']:
                                    should_dict={
                                        "bool": {
                                            "must": [],
                                            "filter": [
                                                {
                                                    "bool": {
                                                    "minimum_should_match": 1,
                                                    "should": [
                                                        {
                                                            "match_phrase": {
                                                            filter['key']: doc
                                                            }
                                                        }
                                                    ]
                                                    }
                                                }
                                            ]
                                        }
                                    }
                                    bool_dict["bool"]["should"].append(should_dict)
                                payload_dict['query']['bool']['filter'].append(bool_dict)
                            else:
                                key_dict={}
                                key_dict['match_phrase']={}
                                key_dict['match_phrase'][filter['key']] = filter['values']
                                payload_dict['query']['bool']['filter'].append(key_dict)
                else:
                    payload_dict = json.loads(entity_details[11].read())
                resp = self.session.post(entity_details[10], headers=self.headers, json=payload_dict, timeout=10)
                kibana_response = resp.json()
                total_hits = kibana_response['hits']['hits']

                for channel in self.DEFAULT_CHANNELS:
                    channel_dict = {}
                    channel_values = [item for item in total_hits if (item['fields']['api_subname'][0].lower() == entity_details[3].lower() or item['fields']['api_name'][0].lower() == entity_details[3].lower()) and channel['CHANNEL_NAME'] in item['fields']['client_id'][0]]
                    channel_dict["CHANNEL_NAME"] = channel['CHANNEL_NAME']
                    channel_dict["ENTITY_API_NAME"] = entity_details[3]
                    channel_dict["ENTITY_API"] = entity_details[3]
                    channel_dict["ENTITY_NAME"] = entity_details[5]
                    channel_dict["ENTITY_ID"] = entity_details[4]
                    channel_dict["TRANSACTION_ID"] = entity_details[6]
                    channel_dict["TRANSACTION_NAME"] = entity_details[7]
                    channel_dict["THRESHOLD_VALUE"] = int(channel['THRESHOLD_VALUE'])
                    channel_dict["FILTER"] = entity_details[12]
                    
                    channel_dict["MEASURED_VALUE"] = int(len(channel_values))
                    if int(len(channel_values)) > int(channel['THRESHOLD_VALUE']):
                        channel_dict["BG_COLOR"] = 'red'
                        channel_dict["TEXT_COLOR"] = 'white'
                    else:
                        channel_dict["BG_COLOR"] = 'green'
                        channel_dict["TEXT_COLOR"] = 'white'
                    self.channel_list.append(channel_dict)

                api_measured_values = [item for item in total_hits if item['fields']['api_subname'][0].lower() == entity_details[3].lower() or item['fields']['api_name'][0].lower() == entity_details[3].lower()]


                entity_dict['ENTITY_STEP_ID'] = entity_details[1]
                entity_dict['ENTITY_STEP_NAME'] = entity_details[3]
                entity_dict['ENTITY_STEP_API_NAME'] = entity_details[3]
                entity_dict['TRANSACTION_ID'] = entity_details[6]
                entity_dict['TRANSACTION_NAME'] = entity_details[7]
                entity_dict['ENTITY_ID'] = entity_details[4]
                entity_dict['ENTITY_NAME'] = entity_details[5]
                entity_dict['THRESHOLD_VALUE'] = int(entity_details[8])
                if int(len(api_measured_values)) > 20:
                    entity_dict['MEASURED_VALUE'] = len(api_measured_values)
                    entity_dict['BG_COLOR'] = 'red'
                    entity_dict['TEXT_COLOR'] = 'white'
                elif int(len(api_measured_values)) > 10 and int(len(api_measured_values)) < 20:
                    entity_dict['MEASURED_VALUE'] = len(api_measured_values)
                    entity_dict['BG_COLOR'] = 'yellow'
                    entity_dict['TEXT_COLOR'] = 'white'
                else:
                    entity_dict['MEASURED_VALUE'] = len(api_measured_values)
                    entity_dict['BG_COLOR'] = 'green'
                    entity_dict['TEXT_COLOR'] = 'white'
                entity_dict['IS_ACTIVE'] = 'Y'
                self.entity_list.append(entity_dict)
                
            except Exception as err:
                print("Kibana Exception ===>", str(err), "====>", entity_details[3])
    def task_completed_callback(self,future):
        if future.done():
            try:
                self.completed_tasks = self.completed_tasks + 1 
            except Exception as e:
                print("Error {e}")
            finally:
                if self.total_tasks == self.completed_tasks:
                    self.db_operations(self.channel_list, self.entity_list)
                    self.channel_list.clear()
                    self.entity_list.clear()
                    self.completed_tasks = 0
    async def process_kibanadata(self, api_names,transanction,entity_chunck):
        with concurrent.futures.ThreadPoolExecutor(max_workers=10) as executor:
            futures = [executor.submit(self.execute_query,api_names,transanction,chunck) for chunck in entity_chunck]
            for future in futures:
                future.add_done_callback(self.task_completed_callback)
                #results = future.result()
                
    def job(self, chunk_data,transanction,entity_chunck):
        try:
            self.total_tasks = len(chunk_data)
            self.semaphore.acquire()
            start_time = datetime.now()
            asyncio.run(self.process_kibanadata(chunk_data,transanction,entity_chunck))
            end_time = datetime.now()
            time_diff = (end_time-start_time).total_seconds()
            print(f"Time taken: {time_diff:.2f} seconds")
        finally:
            self.semaphore.release()
    def run_scheduler(self):
        chunk_size = 10
        for transanction in self.process_data_dict:
            num_jobs = math.ceil(len(self.process_data_dict[transanction]['API_DETAILS']) / chunk_size)
            for i in range(num_jobs):
                chunk = tuple(self.process_data_dict[transanction]['API_DETAILS'][i * chunk_size:(i + 1) * chunk_size])
                entity_chunck = self.process_data_dict[transanction]['ENTITY_DETAILS'][i * chunk_size:(i + 1) * chunk_size]
                schedule.every(35).seconds.do(self.job, chunk,transanction,entity_chunck)
            
    def start_db_jobs(self):
        try:
            while True:
                schedule.run_pending()
                time.sleep(1)
        except Exception as err:
            print("Error starting jobs: ", str(err))
    def stop_db_jobs(self):
        schedule.clear()
        if self.scheduler_thread:
            self.scheduler_thread.do_run=False
            self.scheduler_thread.join()
            self.scheduler_thread = None
KibanaScheduler()

